function boundary=checkifboundary(po,domains)

    %this simple function checks if the po(1,2) coordinates are 
    %in the range of the wall surface, delimited by limitx, limity
    
    %can be improved in the future, using domain to find the boundary
    
    boundary=0;

    if ( po(1)>domains.limitx1 && po(1)< domains.limitx2 && po(2)>domains.limity1 && po(2)<domains.limity2 )
        boundary=1;
    end
    
end
