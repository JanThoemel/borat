clear all
close all
% web plot digitizer
%%%%%
% web.eecs.utk.edu/~dcostine/personal/PowerDeviceLib/DigiTest/index.html
%%%%%


% Load BORAT solutions

%%%%%%%%%%% No plasma

%load('Side2Side_noPlasma_m16gs_p15mbar_133kW_Mirrored_40GHz_300mm_fine.mat')
%load('Side2Side_noPlasma_m16gs_p15mbar_133kW_Mirrored_37GHz_300mm_fine.mat')
%load('Side2Side_noPlasma_m16gs_p15mbar_133kW_Mirrored_34GHz_300mm_fine.mat')

%%%%%%%%%%% Plasma

%load('Side2Side_m16gs_p15mbar_56kW_Mirrored_34GHz_300mm_fine.mat')
%load('Side2Side_m16gs_p15mbar_56kW_Mirrored_37GHz_300mm_fine.mat')
%load('Side2Side_m16gs_p15mbar_56kW_Mirrored_40GHz_300mm_fine.mat')

load('S2S_testFile.mat')


%pwerLevel = 1;
%pwerLevel = 2;


maxsteps = 3000;
% Transmitted (accepted) power
TxAntennaPower = 0.001; % 0.6*0.01; % [W]
antennaEfficiency = 1;
raysPerDegree = 5;

% Signal characterization method
rayDensityRefinement =1;
rayMethod =0; %not used
rayToWaveTransitionMethod =0;%not used

% Load radiation pattern
if f == 34e9 || f == 33e9 || f == 35e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_34GHzRaw.txt');
    patternRawData = readmatrix('input/AC_without_34GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = patternCoPlanarHorizontalSort;
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = patternCoPlanarVerticalSort;
elseif f == 37e9 || f == 36e9 || f == 38e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_37GHzRaw.txt');
    patternRawData = readmatrix('D:/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_37GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = patternCoPlanarHorizontalSort;
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = patternCoPlanarVerticalSort;
elseif f == 40e9 || f == 39e9
  %  patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_40GHzRaw.txt');
    patternRawData = readmatrix('D:/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_40GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = patternCoPlanarHorizontalSort;
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = patternCoPlanarVerticalSort;
end

% Power pattern [db W/m^2]

rawDataPlotIni = abs(patternCoPlanarHorizontal);

rawDataPlotIni90 = patternCoPlanarVertical;


%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

% Tx boresight direction
dirmainTrans =270;

% MEESST VSWR antenna
VSWR1 = [34e9,37e9,40e9; 1.4276,1.149,1.1794];
VSWR2 = [34e9,37e9,40e9; 1.1925,1.12,1.151];


for i = 1: length(VSWR1)
    if VSWR1(1,i) == f
        txAntenna_VSWR = VSWR1(2,i); % from antenna, mean value
    end
end

%Antenna coordinates, main angle and aperture of each receiving antenna
antenna2_Xpos = 0.786;
antenna2_Ypos = -0.3975;
antenna2_dirmain = 90;
antenna2_antennaApertureY = 0.025;
antenna2_antennaApertureZ = 0.025;
for i = 1: length(VSWR2)
    if VSWR2(1,i) == f
        antenna2_VSWR = VSWR2(2,i); % from antenna, mean value
    end
end

recAntennasPosition = [antenna2_Xpos,antenna2_Ypos,antenna2_dirmain,antenna2_antennaApertureY,antenna2_VSWR,antenna2_antennaApertureZ];

% Antenna gain
antennaGain = 15; % [dBi]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Raw data import (radiation pattern) and sorting the data in any case

rawDataPlotdB = rawDataPlotIni;
rawDataPlot90dB = rawDataPlotIni90;

%rawDataPlotdB = sort(rawDataPlotdB,2);
%rawDataPlot90dB = sort(rawDataPlot90dB,2);


%% Redraw the phi plane radiation pattern for correctness

rawDataPlotRad=deg2rad(rawDataPlot90dB(:,2));
figure;%1 90 deg phi
polarplot(rawDataPlotRad,rawDataPlot90dB(:,1),'Linewidth',1);
if min(rawDataPlot90dB(:,1)) == max(rawDataPlot90dB(:,1))
    rlim([-40 20])
else
    rlim([min(real(rawDataPlot90dB(:,1))) max(real(rawDataPlot90dB(:,1)))])
end


rawDataPlotRad=deg2rad(rawDataPlotdB(:,2));
figure;%2 0 deg phi
polarplot(rawDataPlotRad,rawDataPlotdB(:,1),'Linewidth',1);
if min(rawDataPlotdB(:,1)) == max(rawDataPlotdB(:,1))
    rlim([-40 20])
else
    rlim([min(real(rawDataPlotdB(:,1))) max(real(rawDataPlotdB(:,1)))])
end
pause(1);

%% Convert from dB to real valuse, rotate to boresight, save values for later and plot radaiaion patterns

% Convert dB to real values
patternValuesIni = [rawDataPlotdB(:,1),rawDataPlotdB(:,2)]; % now in real values

patternValuesIni90 = [rawDataPlot90dB(:,1),rawDataPlot90dB(:,2)]; % now in real values

% Rotate to antenna radiation direction
[maxIntensity,maxIntensityIndex] = max(patternValuesIni(:,1));
[maxIntensity90,maxIntensityIndex90] = max(patternValuesIni90(:,1));

IniPatternAntDir = patternValuesIni(maxIntensityIndex,2);
IniPatternAntDir90 = patternValuesIni90(maxIntensityIndex90,2);
ThetaToAdd=dirmainTrans-IniPatternAntDir;
ThetaToAdd90=dirmainTrans-IniPatternAntDir90;

% Make sure angles are between 0 and 360
itdirAnt=patternValuesIni(:,2)+ThetaToAdd;
for i = 1 : length(itdirAnt)
    if itdirAnt(i) > 360
        itdirAnt(i) = itdirAnt(i)-360;
    end
end

itdirAnt90=patternValuesIni90(:,2)+ThetaToAdd90;
for i = 1 : length(itdirAnt90)
    if itdirAnt90(i) > 360
        itdirAnt90(i) = itdirAnt90(i)-360;
    end
end

% Final pattern values of the Tx antenna, normalized (independend from
% distance
patternValues = [patternValuesIni(:,1),itdirAnt ];%/maxIntensity
patternValues90 = [patternValuesIni90(:,1),itdirAnt90 ];%/maxIntensity90

[C,ia,ic] = unique(patternValues(:,1),'rows');
patternValues = patternValues(ia,:);
[C,ia,ic] = unique(patternValues(:,2),'rows');
patternValues = patternValues(ia,:);
[C,ia,ic] = unique(patternValues90(:,1),'rows');
patternValues90 = patternValues90(ia,:);
[C,ia,ic] = unique(patternValues90(:,2),'rows');
patternValues90 = patternValues90(ia,:);
if min(patternValues(:,2)) > 0
    patternValues = [patternValues(1,1),0;patternValues];
end
if max(patternValues(:,2)) < 360
    patternValues = [patternValues;patternValues(end,1),360];
end
% Redraw the phi plane radiation pattern for correctness
rawDataPlotRad=deg2rad(patternValues90(:,2));
figure;%3 90 deg phi in radiation direction
polarplot(rawDataPlotRad,patternValues90(:,1),'Linewidth',1);
if min(patternValues90(:,1)) == max(patternValues90(:,1))
    rlim([-40 20])
else
    rlim([min(real(patternValues90(:,1))) max(real(patternValues90(:,1)))])
end


rawDataPlotRad=deg2rad(patternValues(:,2));
figure;%4 0 deg phi in radiation direction
polarplot(rawDataPlotRad,10*log10(patternValues(:,1)),'Linewidth',1.5,'Color', [0,0,0]);
if min(10*log10(patternValues(:,1))) == max(10*log10(patternValues(:,1)))
    rlim([-40 20])
else
    rlim([min(real(10*log10(patternValues(:,1)))) max(real(10*log10(patternValues(:,1))))])
end
hTxt=text(deg2rad(82),15,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),23,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
pause(1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 3D radiation pattern


%patternFromSlices(rawDataPlotdB(:,1),rawDataPlotdB(:,2),Helper',patternRadAngle);




%% Calculate power

%TxAntenna.Power.Correct = (2*pi/length(intensityAtPosRadPat))*(pi/2)*(sum(intensityAtPosRadPat90'.*sind(patternRadAngle))+sum(intensityAtPosRadPat'.*sind(patternRadAngle)));


%% Get intensities at ray positions

% Values from radiation pattern
minAngle = min(patternValues(:,2));
maxAngle = max(patternValues(:,2));

% Ray directions and angular distance between rays
itdirIni=itdir(1,:);

deltaTheta = (max(itdirIni)-min(itdirIni))/(maxangles);

% Intensity values of rays at phi = 0
intensityAtPos = interp1(patternValues(:,2),patternValues(:,1),itdirIni);

% Intensity values of rays at phi = 90
intensityAtPos90 = interp1(patternValues90(:,2),patternValues90(:,1),itdirIni);

%% Final radiation pattern

% Get rays who leave domain
if length(outside)<maxangles
    outside(maxangles)=0;
end

% Power and final angle of rays, which leave domain
powerPerRayFarfield2=zeros(1,sum(sum(outside)));
Theta1=zeros(1,sum(sum(outside)));

% Get power of rays who leave domain
counter=0;
for i = 1:maxangles
    
    if outside(i)==1
        counter=counter+1;
        Pop1 = itdir(:,i);
        Theta1(counter) = Pop1(find(Pop1,1,'last'));
        if isnan(Theta1(counter))
            Theta1(counter) = Pop1(find(Pop1,1,'last')-1);
        end 
        if Theta1(counter) < 0
            Theta1(counter) = Theta1(counter) +360;
        end
        powerPerRayFarfield2(counter)=intensityAtPos(i);
    else
        Theta2(i)=1; % Test variable
        
    end
end 
% Create matrix of Theta and pwoer per ray, get rid of NaNs and sort the
% array
PatternArrayAngularIntensity=[Theta1;powerPerRayFarfield2];
PatternArrayAngularIntensity = rmmissing(PatternArrayAngularIntensity,2);
[~,idx] = sort(PatternArrayAngularIntensity(1,:));
PatternArraySort2 = PatternArrayAngularIntensity(:,idx);

% Extend array by plcing values of the ray along delta Theta around the ray
% to find overlappings
% not considering interference atc.
ExtendedArrayAngularIntensity(1,:) = PatternArraySort2(1,1)-(deltaTheta/2):deltaTheta/100:PatternArraySort2(1,end)+(deltaTheta/2);

for i = 1:length(PatternArraySort2)
    Indexes = [];
    Indexes = find(ExtendedArrayAngularIntensity(1,:) >=PatternArraySort2(1,i)-(deltaTheta/2) & ExtendedArrayAngularIntensity(1,:) <PatternArraySort2(1,i)+(deltaTheta/2));
    for j = 1:length(Indexes)
        ExtendedArrayAngularIntensity(i+1,Indexes(j))=PatternArraySort2(2,i);
    end
end


ExtendedArraySummed(1,:) = ExtendedArrayAngularIntensity(1,:);
ExtendedArraySummed(2,:) = sum(ExtendedArrayAngularIntensity(2:end,:));
ExtendedArraySummed2 = ExtendedArraySummed;
counter = 0;
for i=1:length(ExtendedArraySummed2)
    if ExtendedArraySummed(2,i)~=0
        counter = counter+1;
        ExtendedArraySummedRed(:,counter) = ExtendedArraySummed2(:,i);
    end
end
ExtendedArraySummed2=ExtendedArraySummedRed;
counts = 0;
for i = 2 : length(ExtendedArraySummed)-1
    if ExtendedArraySummed(2,i) == 0 && ExtendedArraySummed(2,i-1) ~= 0 && ExtendedArraySummed(2,i+1) ~= 0
        counts = counts + 1;
        ExtendedArraySummed2(:,counts) = [];
    end
end
ExtendedArraySummed = ExtendedArraySummed2;
figure; %5
plot(ExtendedArraySummed(1,:),10*log10(abs(ExtendedArraySummed(2,:))),'--')
figure; %6
h = polarplot(deg2rad(ExtendedArraySummed(1,:)),10*log10(abs(ExtendedArraySummed(2,:))));
haxes = get(h,'Parent');
ax=gca;
set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1,'FontSize',9,'TickLength',[0.02, 0.002])
if min(ExtendedArraySummed(2,:)) == max(ExtendedArraySummed(2,:))
    rlim([-40 20])
elseif min(10*log10(abs(ExtendedArraySummed(2,:)))) ==-inf
    rlim([-200 max(10*log10(abs(ExtendedArraySummed(2,:))))]);
else
    rlim([min(10*log10(abs(ExtendedArraySummed(2,:))))-20 max(10*log10(abs(ExtendedArraySummed(2,:))))]);
end
hTxt=text(deg2rad(82),43,'dBi');
hTxt=text(deg2rad(0),43,'\Theta');
legend

%% Set zero values (-inf in dB) to 0.00001 (-100 dB)


ExtendedArraySummed100dBIndex =find(~real(ExtendedArraySummed(2,:)));
ExtendedArraySummed100dB=ExtendedArraySummed;
for i= 1:length(ExtendedArraySummed100dBIndex)
    Index=ExtendedArraySummed100dBIndex(i);
    ExtendedArraySummed100dB(2,Index)=0.00000001;
end

figure; %7
plot(ExtendedArraySummed100dB(1,:),10*log10(ExtendedArraySummed100dB(2,:)))
figure%8
h = polarplot(deg2rad(ExtendedArraySummed100dB(1,:)),10*log10(ExtendedArraySummed100dB(2,:)),'Linewidth',1.5,'Color', [0,0,0]);

haxes = get(h,'Parent');
ax=gca;
%set(gca, 'FontName','Times New Roman','Linewidth',1.5,'Color', [0,0,0])
if min(10*log10(ExtendedArraySummed100dB(2,:))) == max(10*log10(ExtendedArraySummed100dB(2,:)))
    rlim([-40 20])
else
    rlim([min(real(10*log10(ExtendedArraySummed100dB(2,:)))) max(real(10*log10(ExtendedArraySummed100dB(2,:))))]);
end
hTxt=text(deg2rad(82),15.4,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),16.3,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")


%% Ray tube method
 

Initial_Radiation_Angle = maxAngle - minAngle;                                     % For example 180 degrees for half-omnidirectional
Delta_Theta = Initial_Radiation_Angle / (maxangles); 

p_ray_unsrt =[];
gain = max(PatternArrayAngularIntensity(2,:)) / (sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)));
P_ray = PatternArrayAngularIntensity(2,:) * Delta_Theta /( sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)))*TxAntennaPower*0.5/pi();       

cnt=length(PatternArrayAngularIntensity);
p_ray_unsrt(1) = P_ray(1)/((PatternArrayAngularIntensity(1,1)-PatternArrayAngularIntensity(1,2))/2);
p_ray_unsrt(cnt) = P_ray(cnt)/((PatternArrayAngularIntensity(1,cnt)-PatternArrayAngularIntensity(1,cnt-1)));
for i = 1 : cnt-1
Delta_Theta_Pattern_Unsrt = PatternArrayAngularIntensity(1,i)-PatternArrayAngularIntensity(1,i+1);
p_ray_unsrt(i) = P_ray(i)/Delta_Theta_Pattern_Unsrt;
end

[PatternArrayRayTube(1,:),Sortingarray]=sort(PatternArrayAngularIntensity(1,:));

p_ray_unsrt=p_ray_unsrt(Sortingarray);
PatternArrayRayTube(2,:)= p_ray_unsrt;
MagEdB = 10*log10(abs(PatternArrayRayTube(2,:)));


figure; %9
plot(PatternArrayRayTube(1,:),MagEdB);
figure%10
h = polarplot(deg2rad(PatternArrayRayTube(1,:)),MagEdB,'Linewidth',1);

haxes = get(h,'Parent');
ax=gca;
set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1,'FontSize',9,'TickLength',[0.02, 0.002])
if min(MagEdB) == max(MagEdB)
    rlim([-40 20]);
else
    rlim([min(MagEdB) max(MagEdB)]);
end
hTxt=text(deg2rad(82),43,'dBi');
hTxt=text(deg2rad(0),43,'\Theta');
legend


%Export Tx antenna radiation pattern values for later

TxAntenna.Theta = Theta1;
TxAntenna.deltaTheta = deltaTheta;

TxAntenna.Pattern.AngularIntensity = PatternArrayAngularIntensity;

TxAntenna.Pattern.Values = patternValues;
TxAntenna.Pattern.Values90 = patternValues90;
TxAntenna.Pattern.RayTube = PatternArrayRayTube;
TxAntenna.Pattern.RayMethod = ExtendedArraySummed;
TxAntenna.Pattern.RayMethod100dB = ExtendedArraySummed100dB;

TxAntenna.powerPerRayFarfield = powerPerRayFarfield2;

TxAntenna.Power.RayMethod = trapz(ExtendedArraySummed(1,:),ExtendedArraySummed(2,:));
TxAntenna.Power.RayTube = trapz(PatternArrayRayTube(1,:),PatternArrayRayTube(2,:));
TxAntenna.Power.Inital = trapz(itdirIni,intensityAtPos);
%% Signal characterization
%[Sparameters] = CommunicationTestNoPlasma(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,rayMethod,rayToWaveTransitionMethod,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2);
%[Sparameters] = CommunicationMEESST2(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,rayMethod,rayToWaveTransitionMethod,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaGain);
%[Sparameters] = CommunicationMEESST2FR(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,rayMethod,rayToWaveTransitionMethod,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaGain,pwerLevel);
%[Sparameters] = CommunicationMEESST2FRplusI(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,rayMethod,rayToWaveTransitionMethod,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaGain,pwerLevel);
[Sparameters] = CommunicationMEESST2I(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,rayMethod,rayToWaveTransitionMethod,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaGain);

