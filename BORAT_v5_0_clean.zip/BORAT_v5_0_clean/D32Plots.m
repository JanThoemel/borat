close all;
clear all;

%% No plasma CST

yCST = [-18.596;-24.99;-30.68;-36.62];
yRDR = [-18.4;-25.54;-30.72;-34.41];
yRDRplus = [-2.14;-2.07;-2.08;-2.08];
yRDRminus = [-2.34;-2.28;-2.29;-2.3];
yRM = [-22.08;-27.44;-32.17;-37.7];
yRMplus = [-1.91;-1.85;-1.86;-1.86];
yRMminus = [-2.14;-2.07;-2.08;-2.08];

xCST = [0.1;0.2;0.4;0.8];
xRDR = [0.09;0.19;0.39;0.79];
xRM = [0.11;0.21;0.41;0.81];


figure;%1
plot(xCST,yCST, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'r')
hold on

errorbar(xRDR,yRDR,yRDRminus,yRDRplus,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'g')

errorbar(xRM,yRM,yRMminus,yRMplus,'*',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'b')
colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Antenna distance [m]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([0 0.9])
legend('CST Simulation','Ray Density Refinement Method', 'Ray Method')


%% No plasma Side2Side
clear all;

y = [-61.56821019;-59.93029287;-60.29073659];
yPlus = [3.403349061;3.482139084;4.080461557];
yMinus = [3.403349061;3.482139084;4.080461557];

yRDR = [-56.95;-62.26;-62.61];


yRM = [-64.56;-59.62;-58.55];


x = [34;37;40];
xRDR = [33.9;36.9;39.9];
xRM = [34.1;37.1;40.1];


figure;%2
errorbar(x,y,yMinus,yPlus, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'r')
hold on

errorbar(xRDR,yRDR,yRDRminus,yRDRplus,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'g')

errorbar(xRM,yRM,yRMminus,yRMplus,'*',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'b')
colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Radio wave frequency [GHz]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([33 41])
xticks([34 37 40])
ylim([-70 -45])
legend('Experiment','Ray Density Refinement Method', 'Ray Method')

%% 15 mbar, 100 kW, Plasma, Polarizarion Side2Side
clear all;

y = [-60.86934633;-64.36703129;-65.22981752];
yPlus = [4.157500604;4.133969603;4.129519161];
yMinus = [4.157500604;4.133969603;4.129519161];

yRDR = [-56.97;-57.67;-57.06];
yRDRplus = [2.54;2.54;2.55];
yRDRminus = [2.65;2.65;2.64];

yRM = [-58.23;-58.08;-57.05];
yRMplus = [2.54;2.55;2.55];
yRMminus = [2.64;2.65;2.64];

x = [34;37;40];
xRDR = [33.9;36.9;39.9];
xRM = [34.1;37.1;40.1];


figure;%3
errorbar(x,y,yMinus,yPlus, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'r')
hold on

errorbar(xRDR,yRDR,yRDRminus,yRDRplus,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'g')

errorbar(xRM,yRM,yRMminus,yRMplus,'*',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'b')
colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Radio wave frequency [GHz]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([33 41])
xticks([34 37 40])
ylim([-70 -45])
legend('Experiment','Ray Density Refinement Method', 'Ray Method')

%% 15 mbar, 100 kW, Plasma, Polarizarion + Interference Side2Side
clear all;

y = [-60.86934633;-64.36703129;-65.22981752];
yPlus = [4.157500604;4.133969603;4.129519161];
yMinus = [4.157500604;4.133969603;4.129519161];

yRDR = [-63.01;-63.49;-66.28];
yRDRplus = [2.54;2.55;2.55];
yRDRminus = [2.64;2.64;2.64];

yRM = [-64.62;-61.25;-58.43];
yRMplus = [2.55;2.55;2.55];
yRMminus = [2.64;2.64;2.65];

x = [34;37;40];
xRDR = [33.9;36.9;39.9];
xRM = [34.1;37.1;40.1];


figure;%4
errorbar(x,y,yMinus,yPlus, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'r')
hold on

errorbar(xRDR,yRDR,yRDRminus,yRDRplus,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'g')

errorbar(xRM,yRM,yRMminus,yRMplus,'*',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'b')
colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Radio wave frequency [GHz]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([33 41])
xticks([34 37 40])
ylim([-70 -45])
legend('Experiment','Ray Density Refinement Method', 'Ray Method')

%% 15 mbar, 100 kW, Plasma, Polarizarion + Interference +Induction Side2Side
clear all;

y = [-60.86934633;-64.36703129;-65.22981752];
yPlus = [4.157500604;4.133969603;4.129519161];
yMinus = [4.157500604;4.133969603;4.129519161];

yRDR = [-63.05;-63.53;-66.29];
yRDRplus = [2.58;2.57;2.56];
yRDRminus = [2.69;2.67;2.67];

yRM = [-64.65;-61.29;-58.45];
yRMplus = [2.57;2.57;2.56];
yRMminus = [2.69;2.67;2.66];

x = [34;37;40];
xRDR = [33.9;36.9;39.9];
xRM = [34.1;37.1;40.1];


figure;%5
errorbar(x,y,yMinus,yPlus, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'r')
hold on

errorbar(xRDR,yRDR,yRDRminus,yRDRplus,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'g')

errorbar(xRM,yRM,yRMminus,yRMplus,'*',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'b')
colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Radio wave frequency [GHz]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([33 41])
xticks([34 37 40])
ylim([-70 -45])
legend('Experiment','Ray Density Refinement Method', 'Ray Method')

%% 15 mbar, 100 kW, Plasma, Polarizarion +Induction Side2Side
clear all;

y = [-60.86934633;-64.36703129;-65.22981752];
yPlus = [4.157500604;4.133969603;4.129519161];
yMinus = [4.157500604;4.133969603;4.129519161];

yRDR = [-57.01;-57.72;-57.07];
yRDRplus = [2.57;2.57;2.56];
yRDRminus = [2.69;2.67;2.67];

yRM = [-58.26;-58.12;-57.06];
yRMplus = [2.57;2.57;2.56];
yRMminus = [2.7;2.67;2.67];

x = [34;37;40];
xRDR = [33.9;36.9;39.9];
xRM = [34.1;37.1;40.1];


figure;%6
errorbar(x,y,yMinus,yPlus, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'r')
hold on

errorbar(xRDR,yRDR,yRDRminus,yRDRplus,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'g')

errorbar(xRM,yRM,yRMminus,yRMplus,'*',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'b')
colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Radio wave frequency [GHz]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([33 41])
xticks([34 37 40])
ylim([-70 -45])
legend('Experiment','Ray Density Refinement Method', 'Ray Method')


%% 15 mbar, 150 kW, Plasma, Polarizarion +Induction Side2Side
clear all;

y = [-68.58021434];
yPlus = [4.38104469];
yMinus = [4.38104469];



yRDR1 = [-66.39];
yRDRplus1 = [2.66];
yRDRminus1 = [2.8];

yRM1 = [-74.21];
yRMplus1 = [2.66];
yRMminus1 = [2.8];

x = [40];

xRDR1 = [39.95];
xRM1 = [40.05];


figure;%7
errorbar(x,y,yMinus,yPlus, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'r')
hold on



errorbar(xRDR1,yRDR1,yRDRminus1,yRDRplus1,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'g')

errorbar(xRM1,yRM1,yRMminus1,yRMplus1,"*","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', 'b')

colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Radio wave frequency [GHz]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([39 41])
xticks([40])
ylim([-80 -55])
legend('Experiment','Ray Density Refinement Method', 'Ray Method')

%% 15 mbar, 150 kW, Plasma, Polarizarion Side2Side
clear all;

y = [-68.58021434];
yPlus = [4.38104469];
yMinus = [4.38104469];

yRDR = [-66.17];
yRDRplus = [2.54];
yRDRminus = [2.65];

yRM = [-73.99];
yRMplus = [2.55];
yRMminus = [2.65];


x = [40];
xRDR = [39.95];
xRM = [40.05];



figure;%8
errorbar(x,y,yMinus,yPlus, 'o',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', [0,0,0])
hold on

errorbar(xRDR,yRDR,yRDRminus,yRDRplus,"-s","MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', [0.4,0.4,0.4])

errorbar(xRM,yRM,yRMminus,yRMplus,'*',"MarkerSize",10,"LineStyle","none",'LineWidth',1.5,'Color', [0.8,0.8,0.8])


colormap(gray)
hold off
ylabel('S-parameter [dB]');
xlabel('Radio wave frequency [GHz]');
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
xlim([39 41])
xticks([40])
ylim([-80 -55])
legend('Experiment','Ray Density Refinement Method', 'Ray Method')

clear all

rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/Directivity_0deg_360');
rawDataPlotdB = rawDataPlotIni;

rawDataPlotdB = sort(rawDataPlotdB,2);
angles = 0:360;
AECplot = interp1(rawDataPlotdB(:,2),rawDataPlotdB(:,1),angles);
AECplot(1) = AECplot(end);
AECplot(2) = AECplot(3);

rawDataPlotRad=deg2rad(angles);
figure;%2 0 deg phi
polarplot(rawDataPlotRad,10*log10(AECplot),'Linewidth',1.5,'Color', [0,0,0]);
if min(10*log10(AECplot)) == max(10*log10(AECplot))
    rlim([-40 20])
else
    rlim([min(10*log10(AECplot)) max(10*log10(AECplot))])
end


hTxt=text(deg2rad(82),8,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),10,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
%legend()


clear all
rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/0.csv');

for i = 1 : length(rawDataPlotIni)
    if rawDataPlotIni(i,2) <0
        rawDataPlotIni(i,2) = rawDataPlotIni(i,2)+360;
    end
end
rawDataPlotdB = rawDataPlotIni;
rawDataPlotdB = sort(rawDataPlotdB,2);

AECplot = [rawDataPlotdB(1,1),0;rawDataPlotdB;rawDataPlotdB(end,1),360];


rawDataPlotRad=deg2rad(AECplot(:,2));
figure;%2 0 deg phi
polarplot(rawDataPlotRad,AECplot(:,1),'Linewidth',1.5,'Color', [0,0,0]);
if min(AECplot(:,1)) == max(AECplot(:,1))
    rlim([-40 20])
else
    rlim([min(AECplot(:,1)) max(AECplot(:,1))])
end


hTxt=text(deg2rad(82),9,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),12,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
%legend()

clear all
rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/100.csv');

for i = 1 : length(rawDataPlotIni)
    if rawDataPlotIni(i,2) <0
        rawDataPlotIni(i,2) = rawDataPlotIni(i,2)+360;
    end
end
rawDataPlotdB = rawDataPlotIni;
rawDataPlotdB = sort(rawDataPlotdB,2);

AECplot = [rawDataPlotdB(1,1),0;rawDataPlotdB;rawDataPlotdB(end,1),360];


rawDataPlotRad=deg2rad(AECplot(:,2));
figure;%2 0 deg phi
polarplot(rawDataPlotRad,AECplot(:,1),'Linewidth',1.5,'Color', [0,0,0]);
if min(AECplot(:,1)) == max(AECplot(:,1))
    rlim([-40 20])
else
    rlim([min(AECplot(:,1)) max(AECplot(:,1))])
end


hTxt=text(deg2rad(82),9,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),12,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
%legend


clear all
rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/200.csv');

for i = 1 : length(rawDataPlotIni)
    if rawDataPlotIni(i,2) <0
        rawDataPlotIni(i,2) = rawDataPlotIni(i,2)+360;
    end
end
rawDataPlotdB = rawDataPlotIni;
rawDataPlotdB = sort(rawDataPlotdB,2);

AECplot = [rawDataPlotdB(1,1),0;rawDataPlotdB;rawDataPlotdB(end,1),360];


rawDataPlotRad=deg2rad(AECplot(:,2));
figure;%2 0 deg phi
polarplot(rawDataPlotRad,AECplot(:,1),'Linewidth',1.5,'Color', [0,0,0]);
if min(AECplot(:,1)) == max(AECplot(:,1))
    rlim([-40 20])
else
    rlim([min(AECplot(:,1)) max(AECplot(:,1))])
end


hTxt=text(deg2rad(82),9,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),12,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
%legend()


clear all
rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/400.csv');

for i = 1 : length(rawDataPlotIni)
    if rawDataPlotIni(i,2) <0
        rawDataPlotIni(i,2) = rawDataPlotIni(i,2)+360;
    end
end
rawDataPlotdB = rawDataPlotIni;
rawDataPlotdB = sort(rawDataPlotdB,2);

AECplot = [rawDataPlotdB(1,1),0;rawDataPlotdB;rawDataPlotdB(end,1),360];


rawDataPlotRad=deg2rad(AECplot(:,2));
figure;%2 0 deg phi
polarplot(rawDataPlotRad,AECplot(:,1),'Linewidth',1.5,'Color', [0,0,0]);
if min(AECplot(:,1)) == max(AECplot(:,1))
    rlim([-40 20])
else
    rlim([min(AECplot(:,1)) max(AECplot(:,1))])
end


hTxt=text(deg2rad(82),9,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),12,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
%legend()


clear all
rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/800.csv');

for i = 1 : length(rawDataPlotIni)
    if rawDataPlotIni(i,2) <0
        rawDataPlotIni(i,2) = rawDataPlotIni(i,2)+360;
    end
end
rawDataPlotdB = rawDataPlotIni;
rawDataPlotdB = sort(rawDataPlotdB,2);

AECplot = [rawDataPlotdB(1,1),0;rawDataPlotdB;rawDataPlotdB(end,1),360];


rawDataPlotRad=deg2rad(AECplot(:,2));
figure;%2 0 deg phi
polarplot(rawDataPlotRad,AECplot(:,1),'Linewidth',1.5,'Color', [0,0,0]);
if min(AECplot(:,1)) == max(AECplot(:,1))
    rlim([-40 20])
else
    rlim([min(AECplot(:,1)) max(AECplot(:,1))])
end


hTxt=text(deg2rad(82),9,'dBi','FontSize',18,'FontName',"Times New Roman");
hTxt=text(deg2rad(0),12,'\Theta','FontSize',18,'FontName',"Times New Roman");
set(gca,'FontSize',18)
%fontsize(gca,18)
fontname(gca,"Times New Roman")
%legend()