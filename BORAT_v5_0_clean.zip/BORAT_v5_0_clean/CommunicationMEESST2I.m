

function [Sparameters] = CommunicationMEESST2I(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,rayMethod,rayToWaveTransitionMethod,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaGain)
%% RadiationPatternInitailization of Receiving Antenna

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Required for test case

Cablelength1= 3.0; % [m]
Cablelength2= 3.5; % [m]
AdaptorLoss = 0.4; % [dB]
CableLoss = (0.37*(f/(10^9))^0.5)+(0.0071*(f/(10^9))); % [dB/m]; f in GHz
DCBlockLoss = 0.75; % [dB]
AdditionalLoss = 0; % [dB]
Windows = 2.258; % [dB 
%Ptx = 10; % [dBm]

%%%%%%%%%%%%%%%%%%%%%%%%%%%% End required for test case

Gamma_r = (recAntennasPosition(:,5)-1)./(recAntennasPosition(:,5)+1);
Gamma_t = (txAntenna_VSWR-1)./(txAntenna_VSWR+1);


%% Raw data of antenna pattern

rawDataPlotRx = rawDataPlotIni; % Directivity

%rawDataPlotRx = sort(rawDataPlotRx,2);


%% Add min and max angles to raw data & Identify antenna orientation

patternValuesInidBRx = rawDataPlotRx;

patternValuesIniRx = [patternValuesInidBRx(:,1),patternValuesInidBRx(:,2)]; % now in real values

% Rotate to antenna radiation direction
[maxIntensity,maxIntensityIndex] = max(patternValuesIniRx(:,1));
%[maxIntensity90,maxIntensityIndex90] = max(patternValuesIni90(:,1));
patternValuesIniRx(:,1)=patternValuesIniRx(:,1);%/maxIntensity;



IniPatternAntDirRx = patternValuesIniRx(maxIntensityIndex,2);



%% Ray density refinement method


if rayDensityRefinement == 1
    % Get rays who leave domain

    solverEikonal=1;
    solverSnell=0;

    counter=0;
    for i = 1:maxangles
        if outside(i)==1
            counter=counter+1;
            Pop1 = itdir(:,i);
            lastAngleRx(:,counter) = [itdir(1,i);Pop1(find(Pop1,1,'last'))];
            if isnan(lastAngleRx(2,counter))
                lastAngleRx(:,counter) = [itdir(1,i);Pop1(find(Pop1,1,'last')-1)];
            end  
            if lastAngleRx(2,counter) < 0
                lastAngleRx(2,counter) = lastAngleRx(2,counter) +360;
            end
        else
            lastAngle2(i)=1;   
        end
    end 
    
    % Centre position of transmitting antenna
    centreTransAnt = [(pooo1(1)+pooo2(1))/2,(pooo1(2)+pooo2(2))/2,0];

    for numA = 1:length(recAntennasPosition(:,1))

        ThetaToAddRx=recAntennasPosition(numA,3)-IniPatternAntDirRx;

        itdirAntRx=patternValuesIniRx(:,2)+ThetaToAddRx;
        for i = 1 : length(itdirAntRx)
            if itdirAntRx(i) <0
                itdirAntRx(i) = itdirAntRx(i)+360;
            end
            if itdirAntRx(i) > 360
                itdirAntRx(i) = itdirAntRx(i)-360;
            end

        end
        
        patternValuesRx = [patternValuesIniRx(:,1),itdirAntRx ];

        [C,ia,ic] = unique(patternValuesRx(:,1),'rows');
        patternValuesRx = patternValuesRx(ia,:);
        [C,ia,ic] = unique(patternValuesRx(:,2),'rows');
        patternValuesRx = patternValuesRx(ia,:);
        [~,idx] = sort(patternValuesRx(:,2));
        patternValuesRx = patternValuesRx(idx,:);    
        if min(patternValuesRx(:,2)) > 0
            patternValuesRx = [patternValuesRx(1,1),0;patternValuesRx];
        end
        if max(patternValuesRx(:,2)) < 360
            patternValuesRx = [patternValuesRx;patternValuesRx(end,1),360];
        end
        
        
        %% Draw the plot for correctness
        
        
        patternValuesRadRx=deg2rad(patternValuesRx(:,2));
        figure;%11
        polarplot(patternValuesRadRx,10*log10(abs(patternValuesRx(:,1))),'Linewidth',1);
        if min(10*log10(abs(patternValuesRx(:,1)))) == max(10*log10(abs(patternValuesRx(:,1))))
            rlim([-40 20])
        else
            rlim([min(10*log10(abs(patternValuesRx(:,1)))) max(10*log10(abs(patternValuesRx(:,1))))])
        end
        pause(1);

        alphaRxAnt = atan2d(recAntennasPosition(numA,2)-centreTransAnt(2),recAntennasPosition(numA,1)-centreTransAnt(1));
        if alphaRxAnt <0
            alphaRxAnt = alphaRxAnt +360;
        end

        [lastAngleRx(2,:),idxsort] = sort(lastAngleRx(2,:),2);
        lastAngleRx(1,:) = lastAngleRx(1,idxsort);
       % upperLimit = find(lastAngle(2,:) >= alpha1,1,'first');
        upperLimit = find(lastAngleRx(2,:) >= alphaRxAnt+10,1,'first');
        dir1N = lastAngleRx(1,upperLimit);
       % lowerLimit = find(lastAngle(2,:) <= alpha2,1,'last');
        lowerLimit = find(lastAngleRx(2,:) <= alphaRxAnt-10,1,'last');
        dir2N = lastAngleRx(1,lowerLimit);
        
        if isempty(dir1N)
            dir1N=dir1;
        end
        if isempty(dir2N)
            dir2N=dir2;
        end
        dir1=dir1N;
        dir2=dir2N;

        %% 2. Ray-tracing: compute paths of rays at antenna positions
        maxangles = 1* maxangles;
        if solverSnell==1
            if MagneticField==0
                [itdir, itpo,symmetrylineencounter,outside]=raytracing(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,Cartesian,B1,B2,B3,MagneticField,z);
            elseif MagneticField==1
                [itdir, itpo,symmetrylineencounter,Y_int_1,Y_int_2,Y_int_3,YY,outside]=raytracing_Magnetic(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,Cartesian,B1,B2,B3,MagneticField);
            end
%            fprintf('\n %.2f s step 2 - ray-tracing - Snell Law solver ',cputime-initime)
        
        elseif solverEikonal==1
            if MagneticField==0
            [itdir, itpo,symmetrylineencounter,outside]=eikonal2D(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,z);
            elseif MagneticField==1
            [itdir, itpo,symmetrylineencounter,outside]=eikonal2D_Magnetic(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,Cartesian,B1,B2,B3,MagneticField);
            end
         %   fprintf('\n %.2f s step 2 - ray-tracing - Eikonal solver ',cputime-initime)
        
        else
            
            error('Rays integration solver not identified')
            
        end
    %    fprintf('\n %.2f s step 2 - ray-tracing - done',cputime-initime)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        %% Draw ray-tracing to antenna positions
        

  %      fprintf('\n %.2f s step 3 - plot ray-tracing',cputime-initime)
        
        draw_raytracing(domain,plotscdir,scdir,scdir_range,collisionmodel,absorptionlimits,pooo1,pooo2,itpo,maxangles,itdir,symmetrylineencounter,writefig,runFolder)
        
   %     fprintf('\n %.2f s step 3 - plot ray-tracing - done',cputime-initime)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


        %% Assign transmitting antenna values to new rays

        
        itdirIniTx=itdir(1,:);
        
        deltaThetaTx = (max(itdirIniTx)-min(itdirIniTx))/(maxangles);
        
        
        intensityAtPosTx = interp1(TxAntenna.Pattern.Values(:,2),TxAntenna.Pattern.Values(:,1),itdirIniTx);
        
        % Display radiation pattern with rays in dB (Power pattern)
        
        figure;%2
        polarplot(deg2rad(itdirIniTx),10*log10(abs(intensityAtPosTx)),'Linewidth',1);
        
        if min(intensityAtPosTx) == max(intensityAtPosTx)
            rlim([-40 20])
        else
            rlim([min(10*log10(abs(intensityAtPosTx))) max(10*log10(abs(intensityAtPosTx)))]);
        end
        
        
        %% Final radiation pattern
        
        % Get rays who leave domain
        
        if length(outside(:,1))<maxangles
            outside(maxangles,1)=0;
        end
        
        powerPerRayFarfieldTx=zeros(1,sum(outside(:,1)));
        
        Theta1=zeros(1,sum(outside(:,1)));
        
        % Get power of rays who leave domain
        counter=0;
        for i = 1:maxangles
            
            if outside(i,1)==1
                counter=counter+1;
                Pop1 = itdir(:,i);
                Theta1(counter) = Pop1(find(Pop1,1,'last'));
                if isnan(Theta1(counter))
                    Theta1(counter) = Pop1(find(Pop1,1,'last')-1);
                end      
                powerPerRayFarfieldTx(counter)=intensityAtPosTx(i);
                xComponent(counter)=itpo(1,find(Pop1,1,'last'),i);
                yComponent(counter)=itpo(2,find(Pop1,1,'last'),i);
            else
                Theta2(i)=1;
                
            end
        end 
        
        PatternArrayTx=[Theta1;powerPerRayFarfieldTx];
        PatternArrayTx = rmmissing(PatternArrayTx,2);
        [~,idx] = sort(PatternArrayTx(1,:));
        PatternArraySortTx = PatternArrayTx(:,idx);
        

        figure; %5
        plot(PatternArraySortTx(1,:),10*log10(PatternArraySortTx(2,:)))
        figure%6
        h = polarplot(deg2rad(PatternArraySortTx(1,:)),10*log10(PatternArraySortTx(2,:)),'Linewidth',1);
        
        haxes = get(h,'Parent');
        ax=gca;
        set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1,'FontSize',9,'TickLength',[0.02, 0.002])
        if min(10*log10(PatternArraySortTx(2,:))) == max(10*log10(PatternArraySortTx(2,:)))
            rlim([-40 20])
        else
            rlim([min(10*log10(PatternArraySortTx(2,:))) max(10*log10(PatternArraySortTx(2,:)))]);
        end
        hTxt=text(deg2rad(82),43,'dB');
        hTxt=text(deg2rad(0),43,'\Theta');
        legend


        %% Find rays reaching rx antenna
        
        % Initial computations

        wavelenght = physconst('LightSpeed')/f;

        %Effective antenna area

        A_wirk = wavelenght^2*10^(antennaGain/10)/(4*pi());
        if A_wirk <  (recAntennasPosition(numA,6)*recAntennasPosition(numA,4))
            A_wirk = (recAntennasPosition(numA,6)*recAntennasPosition(numA,4));
        end
        yRange = sqrt(A_wirk);
        zRange = yRange;

        deltaX1 = cos(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaX2 = cos(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        deltaY1 = sin(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaY2 = sin(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        antPosX1 = recAntennasPosition(numA,1)+deltaX1;
        antPosX2 = recAntennasPosition(numA,1)+deltaX2;
        antPosY1 = recAntennasPosition(numA,2)+deltaY1;
        antPosY2 = recAntennasPosition(numA,2)+deltaY2;
        antPosZ1 = 0+(zRange/2);
        antPosZ2 = 0-(zRange/2);
        recAntLeft = [antPosX1;antPosY1;antPosZ1];
        recAntRight = [antPosX2;antPosY2;antPosZ2];
        recAntLeftOrigin = recAntLeft - centreTransAnt';
        recAntRightOrigin = recAntRight - centreTransAnt';
        
        alphaRxAntRange(1,1) = atan2d(norm(cross(recAntRightOrigin,[1;0;0])),dot(recAntRightOrigin,[1;0;0]));
        if recAntRightOrigin(2) < 0
            alphaRxAntRange(1,1) = 360 - alphaRxAntRange(1,1);
        end
        alphaRxAntRange(1,2) = mod(atan2d(norm(cross(recAntLeftOrigin,[1;0;0])),dot(recAntLeftOrigin,[1;0;0])),360);
        if recAntLeftOrigin(2) < 0
            alphaRxAntRange(1,2) = 360 - alphaRxAntRange(1,2);
        end
       

        raysReachingRx = find(PatternArraySortTx(1,:)>=min(alphaRxAntRange) & PatternArraySortTx(1,:)<=max(alphaRxAntRange));
        for i = 1 : length(raysReachingRx)
            index = raysReachingRx(i);
            xComponentReach(i) = xComponent(index);
            yComponentReach(i) = yComponent(index);
        end
        %% Find intensity values at rx antenna

        
        itdirRx = zeros(1,length(raysReachingRx));
        for pwr_i=1:length(raysReachingRx)
            indx = raysReachingRx(pwr_i);
            itdirRx(pwr_i) = PatternArraySortTx(1,indx)+180;

            if itdirRx(pwr_i) > 360
            itdirRx(pwr_i)=itdirRx(pwr_i)-360;
            end
        end
        [~,idx] = sort(itdirRx);
        itdirRxSort = itdirRx(idx);

        intensityAtPosRxDensRef = interp1(patternValuesRx(:,2),patternValuesRx(:,1),itdirRxSort);
       
        
        %% Communication

        % Losses of components

        Ltx = AdaptorLoss + (CableLoss*Cablelength1) + DCBlockLoss + AdditionalLoss;
        Lrx = AdaptorLoss + (CableLoss*Cablelength2) + DCBlockLoss + AdditionalLoss + Windows;
        TxAntennaPowerdB = 10*log10(TxAntennaPower);
        TxAntennaPowerLtx = 10^((TxAntennaPowerdB-Ltx)/10);
        Com.Losses=Lrx;
        % Get magnetic field information

        for zonesNumbers = 1 : domain.nozones
            if MagneticField==1 % Check if this works
                Bfield = [domain.(strcat('zone',num2str(zonesNumbers))).variables(domain.nova-5,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(domain.nova-4,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(domain.nova-3,:)'];
                B_vec_mag=zeros(Bfield);
            
                for i=1:length(Bfield)
                    B_vec_mag(i)= sqrt(B_vectors(1,i)^2 +B_vectors(2,i)^2 +B_vectors(3,i)^2)+(50*10^(-6));
                end
            elseif MagneticField==0
                for i=1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables)
                    B_vec_mag(i)= (50*10^(-6));
                end
            end
        
            domain.(strcat('zone',num2str(zonesNumbers))).variables(end+1,:)=B_vec_mag;
        end

        % Calculate Lfs, Nt, FaradayRot using trapez integration
        for ray = 1:maxangles
        
            raylast = find(itdir(:,ray),1,'last');
        
            refractiveIndex(1) = itpo(4,1,ray);
            for pos = 2:raylast
                refractiveIndex(pos) = itpo(4,pos,ray);
                travelDistance(pos-1) = itpo(3,pos,ray)-itpo(3,pos-1,ray);
            end    
            
            for pos1 = 1:raylast-1
                B_average(pos1) = interpolation(domain,itpo(:,pos1,ray)',domain.nova+1);
                N_average(pos1) = interpolation(domain,itpo(:,pos1,ray)',domain.nova-5);
                X_average(pos1) = interpolation(domain,itpo(:,pos1,ray)',domain.nova-3);
            end
    
            TravelDist(ray) = itpo(3,raylast,ray)+1.2; % CDF domain too small
            
            xComponent(ray)=itpo(1,raylast,ray);
            yComponent(ray)=itpo(2,raylast,ray);
    
            for i = 1 : length(travelDistance)
                totalRICount(i) = imag(sqrt(1-X_average(i))) * travelDistance(i);
                totalElectronCount(i) = N_average(i) * travelDistance(i);
            end
            FaradayRot(ray) = (2.36*10^(4)/(f^2))*sum(totalElectronCount)*(sum(B_average)/length(B_average));
            Com.FaradayRot.( strcat('Ray',num2str(ray)) )=sum(FaradayRot); 
            FaradayRotSummed(ray) = Com.FaradayRot.( strcat('Ray',num2str(ray)) );
    
            plasmaAttenuationRay(ray) = 2*pi()*f/physconst('LightSpeed')*sum(totalRICount);
        end
        deltaTravelDist = max(TravelDist)-TravelDist;
        
        %% Calculate transmitted/received power

        Prad_r_ray = zeros(1,length(raysReachingRx));
        for pwr_i=1:length(raysReachingRx)
            indx = raysReachingRx(pwr_i);
            
            deltaR = TravelDist(indx)*tand(deltaThetaTx/2);
            deltaX = deltaR *cosd(PatternArraySortTx(1,indx)-90);
            deltaY = deltaR *sind(PatternArraySortTx(1,indx)-90);


            yMinus(pwr_i) = yComponentReach(pwr_i) - deltaY;
            yPlus(pwr_i) = yComponentReach(pwr_i) + deltaY;
            xMinus(pwr_i) = xComponentReach(pwr_i) - deltaX;
            xPlus(pwr_i) = xComponentReach(pwr_i) + deltaX;
            zMinus(pwr_i) = 0 - deltaR;
            zPlus(pwr_i) = 0 + deltaR;

            if recAntennasPosition(numA,3) == 180 && recAntennasPosition(numA,3) == 360
                if yMinus(pwr_i) < min ([antPosY1,antPosY2])
                    yMinus(pwr_i) = min([antPosY1,antPosY2]);
                end
                if yPlus(pwr_i) > max ([antPosY1,antPosY2])
                    yPlus(pwr_i) = max([antPosY1,antPosY2]);
                end
                deltaAntR(pwr_i) = yPlus(pwr_i) - yMinus(pwr_i);

                if zMinus(pwr_i) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(pwr_i) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(pwr_i) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(pwr_i) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(pwr_i) = zPlus(pwr_i) - zMinus(pwr_i);
            elseif recAntennasPosition(numA,3) == 90 && recAntennasPosition(numA,3) == 270
                if xMinus(pwr_i) < min ([antPosX1,antPosX2])
                    xMinus(pwr_i) = min([antPosX1,antPosX2]);
                end
                if xPlus(pwr_i) > max ([antPosX1,antPosX2])
                    xPlus(pwr_i) = max([antPosX1,antPosX2]);
                end
                deltaAntR(pwr_i) = xPlus(pwr_i) - xMinus(pwr_i);

                if zMinus(pwr_i) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(pwr_i) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(pwr_i) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(pwr_i) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(pwr_i) = zPlus(pwr_i) - zMinus(pwr_i);
            else
                if xPlus(pwr_i) > max ([antPosX1,antPosX2]) && yPlus(pwr_i) > max ([antPosY1,antPosY2])
                    xPlus(pwr_i) = max([antPosX1,antPosX2]);
                    yPlus(pwr_i) = max([antPosY1,antPosY2]);
                end
                if yMinus(pwr_i) < min ([antPosY1,antPosY2]) && xMinus(pwr_i) < min ([antPosX1,antPosX2])
                    xMinus(pwr_i) = min([antPosX1,antPosX2]);
                    yMinus(pwr_i) = min([antPosY1,antPosY2]);
                end
                deltaAntR(pwr_i) = sqrt(yPlus(pwr_i)^2 + xPlus(pwr_i)^2) - sqrt(yMinus(pwr_i)^2 + xMinus(pwr_i)^2);

                if zMinus(pwr_i) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(pwr_i) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(pwr_i) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(pwr_i) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(pwr_i) = zPlus(pwr_i) - zMinus(pwr_i);
            end

            A_hitRay(pwr_i) = abs(deltaAntR(pwr_i)) * abs(deltaZ(pwr_i));
            A_Ray(pwr_i) = (2*TravelDist(pwr_i)*tand(deltaThetaTx/2))^2;

            Prad_r_rayMinus(pwr_i) = ((0.9*0.97*PatternArraySortTx(2,indx)*intensityAtPosRxDensRef(pwr_i)*(wavelenght/(4*pi()*TravelDist(indx)))^2*1*(1-abs(0.98*Gamma_t)^2)*(1-abs(0.98*Gamma_r(numA))^2))*cos(FaradayRotSummed(pwr_i))^2*A_hitRay(pwr_i)/A_Ray(pwr_i))*0.95*TxAntennaPowerLtx*cos((abs(deltaTravelDist(indx))/wavelenght)*2*pi());
            Prad_r_ray(pwr_i) = ((PatternArraySortTx(2,indx)*intensityAtPosRxDensRef(pwr_i)*(wavelenght/(4*pi()*TravelDist(indx)))^2*(1-abs(Gamma_t)^2)*(1-abs(Gamma_r(numA))^2))*cos(FaradayRotSummed(pwr_i))^2*A_hitRay(pwr_i)/A_Ray(pwr_i))*TxAntennaPowerLtx*cos((abs(deltaTravelDist(indx))/wavelenght)*2*pi());
            Prad_r_rayPlus(pwr_i) = ((1.1*1.03*PatternArraySortTx(2,indx)*intensityAtPosRxDensRef(pwr_i)*(wavelenght/(4*pi()*TravelDist(indx)))^2*1*(1-abs(1.02*Gamma_t)^2)*(1-abs(1.02*Gamma_r(numA))^2))*cos(FaradayRotSummed(pwr_i))^2*A_hitRay(pwr_i)/A_Ray(pwr_i))*1.05*TxAntennaPowerLtx*cos((abs(deltaTravelDist(indx))/wavelenght)*2*pi());
        
            plasmaAttenuationRayHit(pwr_i) = plasmaAttenuationRay(indx);
        end
        PlasmaAttenuation = sum(plasmaAttenuationRayHit)/length(plasmaAttenuationRayHit);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        PlasmaAttenuation = 0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Prad_r_rayMinusTotal = 10^((10*log10(sum(Prad_r_rayMinus)/length(Prad_r_rayMinus))-PlasmaAttenuation-(1.1*Com.Losses))/10);
        Prad_r_rayTotal = 10^((10*log10(sum(Prad_r_ray)/length(Prad_r_ray))-PlasmaAttenuation-Com.Losses)/10);
        Prad_r_rayPlusTotal = 10^((10*log10(sum(Prad_r_rayPlus)/length(Prad_r_rayPlus))-PlasmaAttenuation-(0.9*Com.Losses))/10);

        S_x1_rayDensityRefinementMinus(numA) = 20*log10(sqrt(abs(Prad_r_rayMinusTotal/(1.05*TxAntennaPowerLtx))));
        S_x1_rayDensityRefinement(numA) = 20*log10(sqrt(abs(Prad_r_rayTotal/(TxAntennaPowerLtx))));
        S_x1_rayDensityRefinementPlus(numA) = 20*log10(sqrt(abs(Prad_r_rayPlusTotal/(0.95*TxAntennaPowerLtx))));

        
    end
    Sparameters.S_x1_rayDensityRefinementMinus = S_x1_rayDensityRefinementMinus;
    Sparameters.S_x1_rayDensityRefinement = S_x1_rayDensityRefinement;
    Sparameters.S_x1_rayDensityRefinementPlus = S_x1_rayDensityRefinementPlus;

%% Ray method


elseif rayMethod == 1
  
    
    %% Communication

    % Initial computations

    wavelenght = physconst('LightSpeed')/f;

    % Losses of components

    Ltx = AdaptorLoss + (CableLoss*Cablelength1) + DCBlockLoss + AdditionalLoss;
    Lrx = AdaptorLoss + (CableLoss*Cablelength2) + DCBlockLoss + AdditionalLoss + Windows;
    TxAntennaPowerdB = 10*log10(TxAntennaPower);
    TxAntennaPowerLtx = 10^((TxAntennaPowerdB-Ltx)/10);
    Com.Losses=Lrx;
    % Get magnetic field information
    for zonesNumbers = 1 : domain.nozones
        if MagneticField==1 % Check if this works
            Bfield = [domain.(strcat('zone',num2str(zonesNumbers))).variables(domain.nova-5,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(domain.nova-4,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(domain.nova-3,:)'];
            B_vec_mag=zeros(Bfield);
        
            for i=1:length(Bfield)
                B_vec_mag(i)= sqrt(B_vectors(1,i)^2 +B_vectors(2,i)^2 +B_vectors(3,i)^2)+(50*10^(-6));
            end
        elseif MagneticField==0
            for i=1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables)
                B_vec_mag(i)= (50*10^(-6));
            end
        end
    
        domain.(strcat('zone',num2str(zonesNumbers))).variables(end+1,:)=B_vec_mag;
    end


    for ray = 1:maxangles
        
        raylast = find(itdir(:,ray),1,'last');
    
        refractiveIndex(1) = itpo(4,1,ray);
        for pos = 2:raylast
            refractiveIndex(pos) = itpo(4,pos,ray);
            travelDistance(pos-1) = itpo(3,pos,ray)-itpo(3,pos-1,ray);
        end    
        
        for pos1 = 1:raylast-1
            B_average(pos1) = interpolation(domain,itpo(:,pos1,ray)',domain.nova+1);
            N_average(pos1) = interpolation(domain,itpo(:,pos1,ray)',domain.nova-5);
            X_average(pos1) = interpolation(domain,itpo(:,pos1,ray)',domain.nova-3);
        end

        TravelDist(ray) = itpo(3,raylast,ray)+1.2; % CDF domain too small
        
        xComponent(ray)=itpo(1,raylast,ray);
        yComponent(ray)=itpo(2,raylast,ray);

        for i = 1 : length(travelDistance)
            totalRICount(i) = imag(sqrt(1-X_average(i))) * travelDistance(i);
            totalElectronCount(i) = N_average(i) * travelDistance(i);
        end
        FaradayRot(ray) = (2.36*10^(4)/(f^2))*sum(totalElectronCount)*(sum(B_average)/length(B_average));
        Com.FaradayRot.( strcat('Ray',num2str(ray)) )=sum(FaradayRot); 
        FaradayRotSummed(ray) = Com.FaradayRot.( strcat('Ray',num2str(ray)) );

        plasmaAttenuationRay(ray) = 2*pi()*f/physconst('LightSpeed')*sum(totalRICount);
    end
    deltaTravelDist = max(TravelDist)-TravelDist;
    %% Find rays reaching rx antenna and extend the array
    

    % Extended array

    PatternArrayCom=[TxAntenna.Theta;TxAntenna.powerPerRayFarfield;TravelDist;FaradayRotSummed;plasmaAttenuationRay;deltaTravelDist];

    %PatternArrayCom=[TxAntenna.Theta;TxAntenna.powerPerRayFarfield];
    PatternArrayCom = rmmissing(PatternArrayCom,2);
    [~,idx] = sort(PatternArrayCom(1,:));%%%%%%
    PatternArrayComSort = PatternArrayCom(:,idx);%%%%%%
    
    ExtendedArrayCom(1,:) = PatternArrayComSort(1,1)-(TxAntenna.deltaTheta/2):TxAntenna.deltaTheta/101:PatternArrayComSort(1,end)+(TxAntenna.deltaTheta/2);
    
    for i = 1:length(PatternArrayComSort)
        Indexes = [];
        Indexes = find(ExtendedArrayCom(1,:) >=PatternArrayComSort(1,i)-(TxAntenna.deltaTheta/2) & ExtendedArrayCom(1,:) <PatternArrayComSort(1,i)+(TxAntenna.deltaTheta/2));

        ExtendedArrayCom(2,Indexes(1):Indexes(end))=PatternArrayComSort(2,i);
        ExtendedArrayCom(3,Indexes(1):Indexes(end))=PatternArrayComSort(3,i);
        ExtendedArrayCom(4,Indexes(1):Indexes(end))=PatternArrayComSort(4,i);

        ExtendedArrayCom(5,Indexes(1):Indexes(50))=xComponent(i)-tan(abs(PatternArrayComSort(1,i)-ExtendedArrayCom(1,Indexes(1):Indexes(50))))*TravelDist(i);
        ExtendedArrayCom(5,Indexes(51):Indexes(51))=xComponent(i);
        ExtendedArrayCom(5,Indexes(52):Indexes(end))=xComponent(i)+tan(abs(PatternArrayComSort(1,i)-ExtendedArrayCom(1,Indexes(52):Indexes(end))))*TravelDist(i);

        ExtendedArrayCom(6,Indexes(1):Indexes(50))=yComponent(i)-tan(abs(PatternArrayComSort(1,i)-ExtendedArrayCom(1,Indexes(1):Indexes(50))))*TravelDist(i);
        ExtendedArrayCom(6,Indexes(51):Indexes(51))=yComponent(i);
        ExtendedArrayCom(6,Indexes(52):Indexes(end))=yComponent(i)+tan(abs(PatternArrayComSort(1,i)-ExtendedArrayCom(1,Indexes(52):Indexes(end))))*TravelDist(i);
        
        ExtendedArrayCom(7,Indexes(1):Indexes(end))=PatternArrayComSort(5,i);
        ExtendedArrayCom(8,Indexes(1):Indexes(end))=PatternArrayComSort(6,i);
    end
 
    counter = 0;
    for i = 1 : length(ExtendedArrayCom)
        if ExtendedArrayCom(2,i) ~= 0 
            counter = counter+1;
            ExtendedArrayComSummed(:,counter) = ExtendedArrayCom(:,i);
        end
    end
    counter = 0;
    for i=1:length(ExtendedArrayComSummed)
        if ExtendedArrayComSummed(3,i)~=0
            counter = counter+1;
            ExtendedArrayComSummedRed(:,counter) = ExtendedArrayComSummed(:,i);
        end
    end
    ExtendedArrayComSummed=ExtendedArrayComSummedRed;


    % Centre position of transmitting antenna
    centreTransAnt = [(pooo1(1)+pooo2(1))/2,(pooo1(2)+pooo2(2))/2,0];

    %Receiving antenna postion and aperture, power and s-parameter
    for numA = 1:length(recAntennasPosition(:,1))

        ThetaToAddRx=recAntennasPosition(numA,3)-IniPatternAntDirRx;

        itdirAntRx=patternValuesIniRx(:,2)+ThetaToAddRx;
        
        for i = 1 : length(itdirAntRx)
            if itdirAntRx(i) <0
                itdirAntRx(i) = itdirAntRx(i)+360;
            end
            if itdirAntRx(i) > 360
                itdirAntRx(i) = itdirAntRx(i)-360;
            end

        end
        
        patternValuesRx = [patternValuesIniRx(:,1),itdirAntRx ];
        [C,ia,ic] = unique(patternValuesRx(:,1),'rows');
        patternValuesRx = patternValuesRx(ia,:);
        [C,ia,ic] = unique(patternValuesRx(:,2),'rows');
        patternValuesRx = patternValuesRx(ia,:);

        [~,idx] = sort(patternValuesRx(:,2));
        patternValuesRx = patternValuesRx(idx,:);
        if min(patternValuesRx(:,2)) > 0
            patternValuesRx = [patternValuesRx(1,1),0;patternValuesRx];
        end
        if max(patternValuesRx(:,2)) < 360
            patternValuesRx = [patternValuesRx;patternValuesRx(end,1),360];
        end
        %% Draw the plot for correctness
        
        
        patternValuesRadRx=deg2rad(patternValuesRx(:,2));
        figure;%1
        polarplot(patternValuesRadRx,10*log10(abs(patternValuesRx(:,1))),'Linewidth',1);
        if min(10*log10(abs(patternValuesRx(:,1)))) == max(10*log10(abs(patternValuesRx(:,1))))
            rlim([-40 20])
        else
            rlim([min(10*log10(abs(patternValuesRx(:,1)))) max(10*log10(abs(patternValuesRx(:,1))))])
        end
        pause(1);

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Initial computations

        wavelenght = physconst('LightSpeed')/f;

        %Effective antenna area

        A_wirk = wavelenght^2*10^(antennaGain/10)/(4*pi());
        if A_wirk <  (recAntennasPosition(numA,6)*recAntennasPosition(numA,4))
            A_wirk = (recAntennasPosition(numA,6)*recAntennasPosition(numA,4));
        end
        yRange = sqrt(A_wirk);
        zRange = yRange;

        deltaX1 = cos(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaX2 = cos(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        deltaY1 = sin(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaY2 = sin(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        antPosX1 = recAntennasPosition(numA,1)+deltaX1;
        antPosX2 = recAntennasPosition(numA,1)+deltaX2;
        antPosY1 = recAntennasPosition(numA,2)+deltaY1;
        antPosY2 = recAntennasPosition(numA,2)+deltaY2;
        antPosZ1 = 0+(zRange/2);
        antPosZ2 = 0-(zRange/2);
        recAntLeft = [antPosX1;antPosY1;antPosZ1];
        recAntRight = [antPosX2;antPosY2;antPosZ2];
        recAntLeftOrigin = recAntLeft - centreTransAnt';
        recAntRightOrigin = recAntRight - centreTransAnt';
        
        alphaRxAntRange(1,1) = atan2d(norm(cross(recAntRightOrigin,[1;0;0])),dot(recAntRightOrigin,[1;0;0]));
        if recAntRightOrigin(2) < 0
            alphaRxAntRange(1,1) = 360 - alphaRxAntRange(1,1);
        end
        alphaRxAntRange(1,2) = mod(atan2d(norm(cross(recAntLeftOrigin,[1;0;0])),dot(recAntLeftOrigin,[1;0;0])),360);
        if recAntLeftOrigin(2) < 0
            alphaRxAntRange(1,2) = 360 - alphaRxAntRange(1,2);
        end
       

        raysReachingRx = find(ExtendedArrayComSummed(1,:)>=min(alphaRxAntRange) & ExtendedArrayComSummed(1,:)<=max(alphaRxAntRange));
        for i = 1 : length(raysReachingRx)
            index = raysReachingRx(i);
           
            xComponentReach(i) = ExtendedArrayCom(5,index);
            yComponentReach(i) = ExtendedArrayCom(6,index);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


        %% Find intensity values at rx antenna

        itdirRx = zeros(1,length(raysReachingRx));
        for pwr_i=1:length(raysReachingRx)
            indx = raysReachingRx(pwr_i);
            itdirRx(pwr_i) = ExtendedArrayComSummed(1,indx)+180;

            if itdirRx(pwr_i) > 360
            itdirRx(pwr_i)=itdirRx(pwr_i)-360;
            end
        end
        [~,idx] = sort(itdirRx);
        itdirRxSort = itdirRx(idx);

        intensityAtPosRxRayMeth = interp1(patternValuesRx(:,2),patternValuesRx(:,1),itdirRxSort);

        Prad_r_ray = zeros(1,length(raysReachingRx));
        for pwr_i=1:length(raysReachingRx)
            indx = raysReachingRx(pwr_i);
            
            deltaR = ExtendedArrayComSummed(3,indx)*tand(TxAntenna.deltaTheta/101/2);
            deltaX = deltaR *cosd(ExtendedArrayComSummed(1,indx)-90);
            deltaY = deltaR *sind(ExtendedArrayComSummed(1,indx)-90);


            yMinus(pwr_i) = yComponentReach(pwr_i) - deltaY;
            yPlus(pwr_i) = yComponentReach(pwr_i) + deltaY;
            xMinus(pwr_i) = xComponentReach(pwr_i) - deltaX;
            xPlus(pwr_i) = xComponentReach(pwr_i) + deltaX;
            zMinus(pwr_i) = 0 - deltaR;
            zPlus(pwr_i) = 0 + deltaR;

            if recAntennasPosition(numA,3) == 180 && recAntennasPosition(numA,3) == 360
                if yMinus(pwr_i) < min ([antPosY1,antPosY2])
                    yMinus(pwr_i) = min([antPosY1,antPosY2]);
                end
                if yPlus(pwr_i) > max ([antPosY1,antPosY2])
                    yPlus(pwr_i) = max([antPosY1,antPosY2]);
                end
                deltaAntR(pwr_i) = yPlus(pwr_i) - yMinus(pwr_i);

                if zMinus(pwr_i) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(pwr_i) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(pwr_i) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(pwr_i) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(pwr_i) = zPlus(pwr_i) - zMinus(pwr_i);
            elseif recAntennasPosition(numA,3) == 90 && recAntennasPosition(numA,3) == 270
                if xMinus(pwr_i) < min ([antPosX1,antPosX2])
                    xMinus(pwr_i) = min([antPosX1,antPosX2]);
                end
                if xPlus(pwr_i) > max ([antPosX1,antPosX2])
                    xPlus(pwr_i) = max([antPosX1,antPosX2]);
                end
                deltaAntR(pwr_i) = xPlus(pwr_i) - xMinus(pwr_i);

                if zMinus(pwr_i) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(pwr_i) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(pwr_i) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(pwr_i) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(pwr_i) = zPlus(pwr_i) - zMinus(pwr_i);
            else
                if xPlus(pwr_i) > max ([antPosX1,antPosX2]) && yPlus(pwr_i) > max ([antPosY1,antPosY2])
                    xPlus(pwr_i) = max([antPosX1,antPosX2]);
                    yPlus(pwr_i) = max([antPosY1,antPosY2]);
                end
                if yMinus(pwr_i) < min ([antPosY1,antPosY2]) && xMinus(pwr_i) < min ([antPosX1,antPosX2])
                    xMinus(pwr_i) = min([antPosX1,antPosX2]);
                    yMinus(pwr_i) = min([antPosY1,antPosY2]);
                end
                deltaAntR(pwr_i) = sqrt(yPlus(pwr_i)^2 + xPlus(pwr_i)^2) - sqrt(yMinus(pwr_i)^2 + xMinus(pwr_i)^2);

                if zMinus(pwr_i) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(pwr_i) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(pwr_i) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(pwr_i) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(pwr_i) = zPlus(pwr_i) - zMinus(pwr_i);
            end

            A_hitRay(pwr_i) = abs(deltaAntR(pwr_i)) * abs(deltaZ(pwr_i));
            A_Ray(pwr_i) = (2*ExtendedArrayComSummed(3,pwr_i)*tand(TxAntenna.deltaTheta/101/2))^2;
            if A_hitRay(pwr_i) > A_Ray(pwr_i)
                A_hitRay(pwr_i) = A_Ray(pwr_i); % numerical error at very short distances??
            end
            
            Prad_r_rayMinus(pwr_i) = ((0.9*0.97*ExtendedArrayComSummed(2,indx)*intensityAtPosRxRayMeth(pwr_i)*(wavelenght/(4*pi()*ExtendedArrayComSummed(3,indx)))^2*1*(1-abs(0.98*Gamma_t)^2)*(1-abs(0.98*Gamma_r(numA))^2))*cos(ExtendedArrayComSummed(4,indx))^2*A_hitRay(pwr_i)/A_Ray(pwr_i))*0.95*TxAntennaPowerLtx*cos((abs(ExtendedArrayComSummed(8,indx))/wavelenght)*2*pi());
            Prad_r_ray(pwr_i) = ExtendedArrayComSummed(2,indx)*intensityAtPosRxRayMeth(pwr_i)*(wavelenght/(4*pi()*ExtendedArrayComSummed(3,indx)))^2*(1-abs(Gamma_t)^2)*(1-abs(Gamma_r(numA))^2)*cos(ExtendedArrayComSummed(4,indx))^2*A_hitRay(pwr_i)/A_Ray(pwr_i)*TxAntennaPowerLtx*cos((abs(ExtendedArrayComSummed(8,indx))/wavelenght)*2*pi());
            Prad_r_rayPlus(pwr_i) = ((1.1*1.03*ExtendedArrayComSummed(2,indx)*intensityAtPosRxRayMeth(pwr_i)*(wavelenght/(4*pi()*ExtendedArrayComSummed(3,indx)))^2*1*(1-abs(1.02*Gamma_t)^2)*(1-abs(1.02*Gamma_r(numA))^2))*cos(ExtendedArrayComSummed(4,indx))^2*A_hitRay(pwr_i)/A_Ray(pwr_i))*1.05*TxAntennaPowerLtx*cos((abs(ExtendedArrayComSummed(8,indx))/wavelenght)*2*pi());
            plasmaAttenuationRayHit(pwr_i) = ExtendedArrayComSummed(7,indx);
        end
        PlasmaAttenuation = sum(plasmaAttenuationRayHit)/length(plasmaAttenuationRayHit);

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        PlasmaAttenuation = 0;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        Prad_r_rayMinusTotal = 10^((10*log10(sum(Prad_r_rayMinus)/length(Prad_r_rayMinus))-PlasmaAttenuation-(1.1*Com.Losses))/10);
        Prad_r_rayTotal = 10^((10*log10(sum(Prad_r_ray)/length(Prad_r_ray))-PlasmaAttenuation-Com.Losses)/10);
        Prad_r_rayPlusTotal = 10^((10*log10(sum(Prad_r_rayPlus)/length(Prad_r_rayPlus))-PlasmaAttenuation-(0.9*Com.Losses))/10);

        S_x1_rayMethodMinus(numA) = 20*log10(sqrt(abs(Prad_r_rayMinusTotal/(1.05*TxAntennaPowerLtx))));
        S_x1_rayMethod(numA) = 20*log10(sqrt(abs(Prad_r_rayTotal/(TxAntennaPowerLtx))));
        S_x1_rayMethodPlus(numA) = 20*log10(sqrt(abs(Prad_r_rayPlusTotal/(0.95*TxAntennaPowerLtx))));
    end
    
    Sparameters.S_x1_rayMethodMinus = S_x1_rayMethodMinus;
    Sparameters.S_x1_rayMethod = S_x1_rayMethod;
    Sparameters.S_x1_rayMethodPlus = S_x1_rayMethodPlus;


else
    fprintf('Please choose a signal characterization method\n');
end


