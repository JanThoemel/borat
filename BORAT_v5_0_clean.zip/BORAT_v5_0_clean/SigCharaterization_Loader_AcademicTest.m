clear all
close all
% web plot digitizer
%%%%%
% web.eecs.utk.edu/~dcostine/personal/PowerDeviceLib/DigiTest/index.html
%%%%%


% Load BORAT solutions

%%%%%%%%%%% Academic Test cases

%load('antennaTestCase_2ant_Noplasma_100_Eikonal_0dot5rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_100_Eikonal_1rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_100_Eikonal_2rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_100_Eikonal_4rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_100_Eikonal_8rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_100_Eikonal_16rayPerDeg.mat')

%load('antennaTestCase_2ant_Noplasma_200_Eikonal_0dot5rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_200_Eikonal_1rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_200_Eikonal_2rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_200_Eikonal_4rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_200_Eikonal_8rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_200_Eikonal_16rayPerDeg.mat')

%load('antennaTestCase_2ant_Noplasma_400_Eikonal_0dot5rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_400_Eikonal_1rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_400_Eikonal_2rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_400_Eikonal_4rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_400_Eikonal_8rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_400_Eikonal_16rayPerDeg.mat')

%load('antennaTestCase_2ant_Noplasma_800_Eikonal_0dot5rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_800_Eikonal_1rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_800_Eikonal_2rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_800_Eikonal_4rayPerDeg.mat')
%load('antennaTestCase_2ant_Noplasma_800_Eikonal_8rayPerDeg.mat')

load('antennaTestCase_2ant_Noplasma_1600_Eikonal_0dot5rayPerDeg.mat')

domain.angleAlpha = 90;


% Load radiation pattern

%%%%%%%%%%%%%%%%%%%%%%%%%%% Academic test cases


% Power pattern [db W/m^2]

% 100 mm distance pattern
%rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern0_180_ant1_100_360');
%rawDataPlotIni90 = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern90_270_ant1_100_360');

% 200 mm distance pattern
%rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern0_180_ant1_200_360');
%rawDataPlotIni90 = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern90_270_ant1_200_360');

% 400 mm distance pattern
%rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern0_180_ant1_400_360');
%rawDataPlotIni90 = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern90_270_ant1_400_360');

% 800 mm distance pattern
%rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern0_180_ant1_800_360');
%rawDataPlotIni90 = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern90_270_ant1_800_360');

% singel directivity pattern 360
%rawDataPlotIni = readmatrix('D:/OneDrive - University of Luxembourg/Work/PatternTest/Directivity_0deg_360');
%rawDataPlotIni90 = readmatrix('D:/OneDrive - University of Luxembourg/Work/PatternTest/Directivity_0deg_360');
%intensityInputData = readmatrix('D:/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern0_180_ant1_singleAntenna_360');
%rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/Directivity_0deg_360');
%rawDataPlotIni90 = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/Directivity_0deg_360');
%intensityInputData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern0_180_ant1_singleAntenna_360');


% singel directivity pattern 360
rawDataPlotIni = readmatrix('input/energyPattern_singleAntenna_prep.txt');
rawDataPlotIniSelect = [rawDataPlotIni(:,3),rawDataPlotIni(:,1)];
for i = 1 : length(rawDataPlotIniSelect(182:end,2))
    rawDataPlotIniSelect(181+i,2) = 180+i;
end

rawDataPlotIniSelect(:,2) = rawDataPlotIniSelect(:,2)+90;

for i = 1 : length(rawDataPlotIniSelect(:,2))    
    if rawDataPlotIniSelect(i,2) > 360
        rawDataPlotIniSelect(i,2) = rawDataPlotIniSelect(i,2) -360;
    end
end
rawDataPlotIniSelect = sortrows(rawDataPlotIniSelect,2);

%rawDataPlotIniIntensity = rawDataPlotIniSelect(:,1).^2 * length(rawDataPlotIniSelect(:,1)) / sum(rawDataPlotIniSelect(:,1).^2);


rawDataPlotIni = rawDataPlotIniSelect; %[rawDataPlotIniIntensity,rawDataPlotIniSelect(:,2)];

% singel antenna pattern 180
%rawDataPlotIni = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern0_180_ant1_singleAntenna_180');
%rawDataPlotIni90 = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/PatternTest/powerPattern90_270_ant1_singleAntenna_180');


%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

% Tx boresight direction
dirmainTrans = 180;

% Academic test cases VSWR antenna
%txAntenna_VSWR = 3.2198;    % 100, no plasma
%antenna2_VSWR = 3.223;    % 100, no plasma

%txAntenna_VSWR = 4.042;    % 200, no plasma
%antenna2_VSWR = 4.047;    % 200, no plasma

%txAntenna_VSWR = 3.931;    % 400, no plasma
%antenna2_VSWR = 3.926;    % 400, no plasma

%txAntenna_VSWR = 3.93;    % 800, no plasma
%antenna2_VSWR = 3.915;    % 800, no plasma


txAntenna_VSWR = 3.917;    % 1600, no plasma
antenna2_VSWR = 3.928;    % 1600, no plasma


%Receiving antenna coordinates, main angle and aperture of each receiving antenna
antenna2_Xpos = 0;
antenna2_Ypos = 0;
antenna2_dirmain = 360;
antenna2_antennaApertureY = 0.03;
antenna2_antennaApertureZ = 0.038;

% Array of receiving antenna properties
recAntennasPosition = [antenna2_Xpos,antenna2_Ypos,antenna2_dirmain,antenna2_antennaApertureY,antenna2_VSWR,antenna2_antennaApertureZ];

% Transmitted (accepted) power
TxAntennaPower = 0.343; % [W]
antennaEfficiency = 0.35344679;

% Antenna gain
%antennaGain = 15; % [dBi]

% Signal characterization method
rayDensityRefinement =1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Raw data import (radiation pattern) and sorting the data in any case

rawDataPlotdB = rawDataPlotIni;
%rawDataPlot90dB = rawDataPlotIni90;

rawDataPlotdB = sort(rawDataPlotdB,2);
%rawDataPlot90dB = sort(rawDataPlot90dB,2);


%% Redraw the phi plane radiation pattern for correctness

%rawDataPlotRad=deg2rad(rawDataPlot90dB(:,2));
%figure;%1 90 deg phi
%polarplot(rawDataPlotRad,rawDataPlot90dB(:,1),'Linewidth',1);
%if min(rawDataPlot90dB(:,1)) == max(rawDataPlot90dB(:,1))
%    rlim([-40 20])
%else
%    rlim([min(rawDataPlot90dB(:,1)) max(rawDataPlot90dB(:,1))])
%end


rawDataPlotRad=deg2rad(rawDataPlotdB(:,2));
figure;%2 0 deg phi
polarplot(rawDataPlotRad,rawDataPlotdB(:,1),'Linewidth',1);
if min(rawDataPlotdB(:,1)) == max(rawDataPlotdB(:,1))
    rlim([-40 20])
else
    rlim([min(rawDataPlotdB(:,1)) max(rawDataPlotdB(:,1))])
end
pause(1);

%% Convert from dB to real valuse, rotate to boresight, save values for later and plot radaiaion patterns

% Convert dB to real values
patternValuesIni = [rawDataPlotdB(:,1),rawDataPlotdB(:,2)]; % now in real values

%patternValuesIni90 = [10.^(rawDataPlot90dB(:,1)/10),rawDataPlot90dB(:,2)]; % now in real values

% Rotate to antenna radiation direction
[maxIntensity,maxIntensityIndex] = max(patternValuesIni(:,1));
%[maxIntensity90,maxIntensityIndex90] = max(patternValuesIni90(:,1));

IniPatternAntDir = patternValuesIni(maxIntensityIndex,2);
%IniPatternAntDir90 = patternValuesIni90(maxIntensityIndex90,2);
ThetaToAdd=dirmainTrans-IniPatternAntDir;
%ThetaToAdd90=dirmainTrans-IniPatternAntDir90;

% Make sure angles are between 0 and 360
itdirAnt=patternValuesIni(:,2)+ThetaToAdd;
for i = 1 : length(itdirAnt)
    if itdirAnt(i) > 360
        itdirAnt(i) = itdirAnt(i)-360;
    end
end

%itdirAnt90=patternValuesIni90(:,2)+ThetaToAdd90;
%for i = 1 : length(itdirAnt90)
%    if itdirAnt90(i) > 360
%        itdirAnt90(i) = itdirAnt90(i)-360;
%    end
%end

% Final pattern values of the Tx antenna, normalized (independend from
% distance
patternValues = [patternValuesIni(:,1),itdirAnt ];%/maxIntensity
%patternValues90 = [patternValuesIni90(:,1),itdirAnt90 ];%/maxIntensity90

[C,ia,ic] = unique(patternValues(:,1),'rows');
patternValues = patternValues(ia,:);
[C,ia,ic] = unique(patternValues(:,2),'rows');
patternValues = patternValues(ia,:);
%[C,ia,ic] = unique(patternValues90(:,1),'rows');
%patternValues90 = patternValues90(ia,:);
%[C,ia,ic] = unique(patternValues90(:,2),'rows');
%patternValues90 = patternValues90(ia,:);
if min(patternValues(:,2)) > 0
    patternValues = [patternValues(1,1),0;patternValues];
end
if max(patternValues(:,2)) < 360
    patternValues = [patternValues;patternValues(end,1),360];
end

% Redraw the phi plane radiation pattern for correctness
%rawDataPlotRad=deg2rad(patternValues90(:,2));
%figure;%3 90 deg phi in radiation direction
%polarplot(rawDataPlotRad,patternValues90(:,1),'Linewidth',1);
%if min(patternValues90(:,1)) == max(patternValues90(:,1))
%    rlim([-40 20])
%else
%    rlim([min(patternValues90(:,1)) max(patternValues90(:,1))])
%end


rawDataPlotRad=deg2rad(patternValues(:,2));
figure;%4 0 deg phi in radiation direction
polarplot(rawDataPlotRad,patternValues(:,1),'Linewidth',1);
if min(patternValues(:,1)) == max(patternValues(:,1))
    rlim([-40 20])
else
    rlim([min(patternValues(:,1)) max(patternValues(:,1))])
end
pause(1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 3D radiation pattern


%patternFromSlices(rawDataPlotdB(:,1),rawDataPlotdB(:,2),Helper',patternRadAngle);




%% Calculate power

%TxAntenna.Power.Correct = (2*pi/length(intensityAtPosRadPat))*(pi/2)*(sum(intensityAtPosRadPat90'.*sind(patternRadAngle))+sum(intensityAtPosRadPat'.*sind(patternRadAngle)));


%% Get intensities at ray positions

% Values from radiation pattern
minAngle = min(patternValues(:,2));
maxAngle = max(patternValues(:,2));

% Ray directions and angular distance between rays
itdirIni=itdir(1,:);

deltaTheta = (max(itdirIni)-min(itdirIni))/(maxangles);

% Intensity values of rays at phi = 0
intensityAtPos = interp1(patternValues(:,2),patternValues(:,1),itdirIni);

% Intensity values of rays at phi = 90
%intensityAtPos90 = interp1(patternValues90(:,2),patternValues90(:,1),itdirIni);

%% Final radiation pattern

% Get rays who leave domain
if length(outside)<maxangles
    outside(maxangles)=0;
end

% Power and final angle of rays, which leave domain
powerPerRayFarfield2=zeros(1,sum(outside(:,1)));
Theta1=zeros(1,sum(outside(:,1)));

% Get power of rays who leave domain
counter=0;
for i = 1:maxangles
    
    if outside(i,1)==1
        counter=counter+1;
        Pop1 = itdir(:,i);
        Theta1(counter) = Pop1(find(Pop1,1,'last'));
        if isnan(Theta1(counter))
            Theta1(counter) = Pop1(find(Pop1,1,'last')-1);
        end  
        if Theta1(counter) < 0
            Theta1(counter) = Theta1(counter) +360;
        end

        powerPerRayFarfield2(counter)=intensityAtPos(i);
    else
        Theta2(i)=1; % Test variable
        
    end
end 
% Create matrix of Theta and pwoer per ray, get rid of NaNs and sort the
% array
PatternArrayAngularIntensity=[Theta1;powerPerRayFarfield2];
PatternArrayAngularIntensity = rmmissing(PatternArrayAngularIntensity,2);
[~,idx] = sort(PatternArrayAngularIntensity(1,:),"ascend");
PatternArraySort2 = PatternArrayAngularIntensity(:,idx);

% Extend array by plcing values of the ray along delta Theta around the ray
% to find overlappings
% not considering interference atc.
ExtendedArrayAngularIntensity(1,:) = PatternArraySort2(1,1)-(deltaTheta/2):deltaTheta/100:PatternArraySort2(1,end)+(deltaTheta/2);

for i = 1:length(PatternArraySort2)
    Indexes = [];
    Indexes = find(ExtendedArrayAngularIntensity(1,:) >=PatternArraySort2(1,i)-(deltaTheta/2) & ExtendedArrayAngularIntensity(1,:) <PatternArraySort2(1,i)+(deltaTheta/2));
    for j = 1:length(Indexes)
        ExtendedArrayAngularIntensity(i+1,Indexes(j))=PatternArraySort2(2,i);
    end
end


ExtendedArraySummed(1,:) = ExtendedArrayAngularIntensity(1,:);
ExtendedArraySummed(2,:) = sum(ExtendedArrayAngularIntensity(2:end,:));
ExtendedArraySummed2 = ExtendedArraySummed;

for i = 2 : length(ExtendedArraySummed)-1
    if ExtendedArraySummed(2,i) == 0 && ExtendedArraySummed(2,i-1) ~= 0 && ExtendedArraySummed(2,i+1) ~= 0
        ExtendedArraySummed2(:,i) = [];
    end
end
ExtendedArraySummed = ExtendedArraySummed2;

figure; %3
plot(ExtendedArraySummed(1,:),10*log10(abs(ExtendedArraySummed(2,:))),'--')
figure; %4
h = polarplot(deg2rad(ExtendedArraySummed(1,:)),10*log10(abs(ExtendedArraySummed(2,:))));
haxes = get(h,'Parent');
ax=gca;
set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1,'FontSize',9,'TickLength',[0.02, 0.002])
if min(ExtendedArraySummed(2,:)) == max(ExtendedArraySummed(2,:))
    rlim([-40 20])
elseif min(10*log10(abs(ExtendedArraySummed(2,:)))) ==-inf
    rlim([-100 max(10*log10(abs(ExtendedArraySummed(2,:))))]);
else
    rlim([min(10*log10(abs(ExtendedArraySummed(2,:))))-20 max(10*log10(abs(ExtendedArraySummed(2,:))))]);
end
hTxt=text(deg2rad(82),43,'dB');
hTxt=text(deg2rad(0),43,'\Theta');
legend

%% Set zero values (-inf in dB) to 0.00001 (-100 dB)


ExtendedArraySummed100dBIndex =find(~ExtendedArraySummed(2,:));
ExtendedArraySummed100dB=ExtendedArraySummed;
for i= 1:length(ExtendedArraySummed100dBIndex)
    Index=ExtendedArraySummed100dBIndex(i);
    ExtendedArraySummed100dB(2,Index)=0.00001;
end

figure; %5
plot(ExtendedArraySummed100dB(1,:),10*log10(ExtendedArraySummed100dB(2,:)))
figure%6
h = polarplot(deg2rad(ExtendedArraySummed100dB(1,:)),10*log10(ExtendedArraySummed100dB(2,:)),'Linewidth',1);

haxes = get(h,'Parent');
ax=gca;
set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1,'FontSize',9,'TickLength',[0.02, 0.002])
if min(10*log10(ExtendedArraySummed100dB(2,:))) == max(10*log10(ExtendedArraySummed100dB(2,:)))
    rlim([-40 20])
else
    rlim([min(10*log10(ExtendedArraySummed100dB(2,:))) max(10*log10(ExtendedArraySummed100dB(2,:)))]);
end
hTxt=text(deg2rad(82),43,'dB');
hTxt=text(deg2rad(0),43,'\Theta');
legend


%% Ray tube method
 

Initial_Radiation_Angle = maxAngle - minAngle;                                     % For example 180 degrees for half-omnidirectional
Delta_Theta = Initial_Radiation_Angle / (maxangles); 

p_ray_unsrt =[];
gain = 10^(2.56/10);%max(PatternArrayAngularIntensity(2,:)) / (sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)));
P_ray = PatternArrayAngularIntensity(2,:) * Delta_Theta /( sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)))*TxAntennaPower*0.5/pi();       

cnt=length(PatternArrayAngularIntensity);
p_ray_unsrt(1) = P_ray(1)/((PatternArrayAngularIntensity(1,1)-PatternArrayAngularIntensity(1,2))/2);
p_ray_unsrt(cnt) = P_ray(cnt)/((PatternArrayAngularIntensity(1,cnt)-PatternArrayAngularIntensity(1,cnt-1)));
for i = 1 : cnt-1
Delta_Theta_Pattern_Unsrt = PatternArrayAngularIntensity(1,i)-PatternArrayAngularIntensity(1,i+1);
p_ray_unsrt(i) = P_ray(i)/Delta_Theta_Pattern_Unsrt;
end

[PatternArrayRayTube(1,:),Sortingarray]=sort(PatternArrayAngularIntensity(1,:));

p_ray_unsrt=p_ray_unsrt(Sortingarray);
PatternArrayRayTube(2,:)= p_ray_unsrt;
MagEdB = 10*log10(abs(PatternArrayRayTube(2,:)));


figure; %7
plot(PatternArrayRayTube(1,:),MagEdB);
figure%8
h = polarplot(deg2rad(PatternArrayRayTube(1,:)),MagEdB,'Linewidth',1);

haxes = get(h,'Parent');
ax=gca;
set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1,'FontSize',9,'TickLength',[0.02, 0.002])
if min(MagEdB) == max(MagEdB)
    rlim([-40 20]);
else
    rlim([min(MagEdB) max(MagEdB)]);
end
hTxt=text(deg2rad(82),43,'dB');
hTxt=text(deg2rad(0),43,'\Theta');
legend


%Export Tx antenna radiation pattern values for later

TxAntenna.Theta = Theta1;
TxAntenna.deltaTheta = deltaTheta;

TxAntenna.Pattern.AngularIntensity = PatternArraySort2;

TxAntenna.Pattern.Values = patternValues;
%TxAntenna.Pattern.Values90 = patternValues90;
TxAntenna.Pattern.RayTube = PatternArrayRayTube;
TxAntenna.Pattern.RayMethod = ExtendedArraySummed;
TxAntenna.Pattern.RayMethod100dB = ExtendedArraySummed100dB;

TxAntenna.powerPerRayFarfield = powerPerRayFarfield2;

TxAntenna.Power.RayMethod = trapz(ExtendedArraySummed(1,:),ExtendedArraySummed(2,:));
TxAntenna.Power.RayTube = trapz(PatternArrayRayTube(1,:),PatternArrayRayTube(2,:));
TxAntenna.Power.Inital = trapz(itdirIni,intensityAtPos);
%% Signal characterization
%[Sparameters] = CommunicationTestNoPlasma(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaEfficiency);
%[Sparameters] = CommunicationElectricField(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaEfficiency);
[Sparameters] = CommunicationElectricField_2D(recAntennasPosition,maxangles,itdir,pooo1,pooo2,TxAntenna,outside,txAntenna_VSWR,rawDataPlotIni,rayDensityRefinement,f,MagneticField,domain,z,itpo,solverSnell,solverEikonal,maxsteps,absorptionlimits,symmetryline,ss,Cartesian,B1,B2,B3,plotscdir,scdir,scdir_range,collisionmodel,symmetrylineencounter,writefig,runFolder,gain,TxAntennaPower,dir1,dir2,antennaEfficiency);

