function boundary=checkifboundary(po,domains)

    %this simple function checks if the po(1,2) coordinates are 
    %in the range of the wall surface, delimited by limitx, limity
    
    %can be improved in the future, using domain to find the boundary

    if domains.nozones == 1
        xv = domains.zone1.variables(1,domains.zone1.bound);
        yv = domains.zone1.variables(2,domains.zone1.bound);
    else
        xv = domains.zoneX.variables(1,domains.zoneX.bound);
        yv = domains.zoneX.variables(2,domains.zoneX.bound);
    end
    [in,on] = inpolygon(po(1),po(2),xv,yv);
    boundary=0;

    if  po(1)>domains.limitx1 && po(1)< domains.limitx2 && po(2)>domains.limity1 && po(2)<domains.limity2 && (on || not(in))
        boundary=1;
    end
    
end
