%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load case
clear all
close all

%load('MEESST_0T_0kW_34GHz.mat');
load('MEESST_MHD.mat');

%% 6.0 Signal Characterization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   


% Transmitted (accepted) power
TxAntennaPower = 0.001; % 0.6*0.01; % [W]
antennaEfficiency = 1;
raysPerDegree = 20;

% Signal characterization method
rayDensityRefinement =1;
rayMethod =0; %not used
rayToWaveTransitionMethod =0;%not used

% Antenna gain
if f == 34E9
    antennaGain = 14.89740976; % [dBi]
elseif f == 37E9
    antennaGain = 15.393065; % [dBi]
elseif f == 40E9
    antennaGain = 13.56515449; % [dBi]
else
    antennaGain = 15; % [dBi]
end

% Load radiation pattern
if f == 34e9 || f == 33e9 || f == 35e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_34GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_34GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = patternCoPlanarHorizontalSort.*10^(antennaGain/10);
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = patternCoPlanarVerticalSort.*10^(antennaGain/10);
elseif f == 37e9 || f == 36e9 || f == 38e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_37GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_37GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = patternCoPlanarHorizontalSort.*10^(antennaGain/10);
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = patternCoPlanarVerticalSort.*10^(antennaGain/10);
elseif f == 40e9 || f == 39e9
  %  patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_40GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_40GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = patternCoPlanarHorizontalSort.*10^(antennaGain/10);
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = patternCoPlanarVerticalSort.*10^(antennaGain/10);
end

% Power pattern [db W/m^2]

rawDataPlotIni = abs(patternCoPlanarHorizontal);

rawDataPlotIni90 = patternCoPlanarVertical;


%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

% Tx boresight direction
dirmainTrans =180;

% MEESST VSWR antenna
VSWR1 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 1.38,1.48,2.33,3.83,6.00,2.55,1.22,1.35];
VSWR2 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.82,2.03,2.67,3.3,3.36,1.77,2.47,8.39];
VSWR3 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.25,1.27,1.44,1.74,1.33,1.36,1.41,1.51];
VSWR4 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.41,1.24,1.86,1.5,1.56,1.42,2.18,2.08];


for i = 1: length(VSWR1)
    if VSWR1(1,i) == f
        txAntenna_VSWR = VSWR1(2,i); % from antenna, mean value
    end
end

%Antenna coordinates, main angle and aperture of each receiving antenna
antenna2_Xpos = 0.5105;
antenna2_Ypos = 0.15;
antenna2_dirmain = 340.47;
antenna2_antennaApertureY = 0.025;
antenna2_antennaApertureZ = 0.025;
for i = 1: length(VSWR2)
    if VSWR2(1,i) == f
        antenna2_VSWR = VSWR2(2,i); % from antenna, mean value
    end
end

antenna3_Xpos = 0.5135;
antenna3_Ypos = 0.155;
antenna3_dirmain = 360-20.256;
antenna3_antennaApertureY = 0.025;
antenna3_antennaApertureZ = 0.025;
for i = 1: length(VSWR3)
    if VSWR3(1,i) == f
        antenna3_VSWR = VSWR3(2,i); % from antenna, mean value
    end
end

antenna4_Xpos = 0.5135;
antenna4_Ypos = 0.295;
antenna4_dirmain = 360-35.08;
antenna4_antennaApertureY = 0.025;
antenna4_antennaApertureZ = 0.025;
for i = 1: length(VSWR4)
    if VSWR4(1,i) == f
        antenna4_VSWR = VSWR4(2,i); % from antenna, mean value
    end
end

recAntennasPosition = [antenna2_Xpos,antenna2_Ypos,antenna2_dirmain,antenna2_antennaApertureY,antenna2_VSWR,antenna2_antennaApertureZ;antenna3_Xpos,antenna3_Ypos,antenna3_dirmain,antenna3_antennaApertureY,antenna3_VSWR,antenna3_antennaApertureZ;antenna4_Xpos,antenna4_Ypos,antenna4_dirmain,antenna4_antennaApertureY,antenna4_VSWR,antenna4_antennaApertureZ];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Raw data import (radiation pattern) and sorting the data in any case

rawDataPlotdB = rawDataPlotIni;
rawDataPlot90dB = rawDataPlotIni90;

%rawDataPlotdB = sort(rawDataPlotdB,2);
%rawDataPlot90dB = sort(rawDataPlot90dB,2);


%% Redraw the phi plane radiation pattern for correctness




%% Convert from dB to real valuse, rotate to boresight, save values for later and plot radaiaion patterns

% Convert dB to real values
patternValuesIni = [rawDataPlotdB(:,1),rawDataPlotdB(:,2)]; % now in real values

patternValuesIni90 = [rawDataPlot90dB(:,1),rawDataPlot90dB(:,2)]; % now in real values

% Rotate to antenna radiation direction
[maxIntensity,maxIntensityIndex] = max(patternValuesIni(:,1));
[maxIntensity90,maxIntensityIndex90] = max(patternValuesIni90(:,1));

IniPatternAntDir = patternValuesIni(maxIntensityIndex,2);
IniPatternAntDir90 = patternValuesIni90(maxIntensityIndex90,2);
ThetaToAdd=dirmainTrans-IniPatternAntDir;
ThetaToAdd90=dirmainTrans-IniPatternAntDir90;

% Make sure angles are between 0 and 360
itdirAnt=patternValuesIni(:,2)+ThetaToAdd;
for i = 1 : length(itdirAnt)
    if itdirAnt(i) > 360
        itdirAnt(i) = itdirAnt(i)-360;
    end
end

itdirAnt90=patternValuesIni90(:,2)+ThetaToAdd90;
for i = 1 : length(itdirAnt90)
    if itdirAnt90(i) > 360
        itdirAnt90(i) = itdirAnt90(i)-360;
    end
end

% Final pattern values of the Tx antenna, normalized (independend from
% distance
patternValues = [patternValuesIni(:,1),itdirAnt ];%/maxIntensity
patternValues90 = [patternValuesIni90(:,1),itdirAnt90 ];%/maxIntensity90

[C,ia,ic] = unique(patternValues(:,1),'rows');
patternValues = patternValues(ia,:);
[C,ia,ic] = unique(patternValues(:,2),'rows');
patternValues = patternValues(ia,:);
[C,ia,ic] = unique(patternValues90(:,1),'rows');
patternValues90 = patternValues90(ia,:);
[C,ia,ic] = unique(patternValues90(:,2),'rows');
patternValues90 = patternValues90(ia,:);
if min(patternValues(:,2)) > 0
    patternValues = [patternValues(1,1),0;patternValues];
end
if max(patternValues(:,2)) < 360
    patternValues = [patternValues;patternValues(end,1),360];
end
% Redraw the phi plane radiation pattern for correctness
rawDataPlotRad=deg2rad(patternValues90(:,2));



rawDataPlotRad=deg2rad(patternValues(:,2));

pause(1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 3D radiation pattern


%patternFromSlices(rawDataPlotdB(:,1),rawDataPlotdB(:,2),Helper',patternRadAngle);




%% Calculate power

%TxAntenna.Power.Correct = (2*pi/length(intensityAtPosRadPat))*(pi/2)*(sum(intensityAtPosRadPat90'.*sind(patternRadAngle))+sum(intensityAtPosRadPat'.*sind(patternRadAngle)));


%% Get intensities at ray positions

% Values from radiation pattern
minAngle = min(patternValues(:,2));
maxAngle = max(patternValues(:,2));

% Ray directions and angular distance between rays
itdirIni=itdir(1,:);

deltaTheta = (max(itdirIni)-min(itdirIni))/(maxangles);

% Intensity values of rays at phi = 0
intensityAtPos = interp1(patternValues(:,2),patternValues(:,1),itdirIni);

% Intensity values of rays at phi = 90
intensityAtPos90 = interp1(patternValues90(:,2),patternValues90(:,1),itdirIni);

%% Final radiation pattern

% Get rays who leave domain
if length(outside)<maxangles
    outside(maxangles)=0;
end

% Power and final angle of rays, which leave domain
powerPerRayFarfield2=zeros(1,sum(sum(outside)));
Theta1=zeros(1,sum(sum(outside)));

% Get power of rays who leave domain
counter=0;
for i = 1:maxangles
    reflectionCeck = find(reflectionPoint(:,i),1,'last');
    if isempty(reflectionCeck)
        reflectionCeck = 0;
    end
    if outside(i)==1 || reflectionCeck >2 
        counter=counter+1;
        Pop1 = itdir(:,i);
        Theta1(counter) = Pop1(find(Pop1,1,'last'));
        if isnan(Theta1(counter))
            Theta1(counter) = Pop1(find(Pop1,1,'last')-1);
        end 
        if Theta1(counter) < 0
            Theta1(counter) = Theta1(counter) +360;
        end
        powerPerRayFarfield2(counter)=intensityAtPos(i);
    else
        Theta2(i)=1; % Test variable
        
    end
end 
% Create matrix of Theta and pwoer per ray, get rid of NaNs and sort the
% array
PatternArrayAngularIntensity=[Theta1;powerPerRayFarfield2];
PatternArrayAngularIntensity = rmmissing(PatternArrayAngularIntensity,2);
[~,idx] = sort(PatternArrayAngularIntensity(1,:));
PatternArraySort2 = PatternArrayAngularIntensity(:,idx);

% Extend array by plcing values of the ray along delta Theta around the ray
% to find overlappings
% not considering interference atc.
ExtendedArrayAngularIntensity(1,:) = PatternArraySort2(1,1)-(deltaTheta/2):deltaTheta/100:PatternArraySort2(1,end)+(deltaTheta/2);

for i = 1:length(PatternArraySort2(1,:))
    Indexes = [];
    Indexes = find(ExtendedArrayAngularIntensity(1,:) >=PatternArraySort2(1,i)-(deltaTheta/2) & ExtendedArrayAngularIntensity(1,:) <PatternArraySort2(1,i)+(deltaTheta/2));
    for j = 1:length(Indexes)
        ExtendedArrayAngularIntensity(i+1,Indexes(j))=PatternArraySort2(2,i);
    end
end


ExtendedArraySummed(1,:) = ExtendedArrayAngularIntensity(1,:);
ExtendedArraySummed(2,:) = sum(ExtendedArrayAngularIntensity(2:end,:));
ExtendedArraySummed2 = ExtendedArraySummed;
counter = 0;
for i=1:length(ExtendedArraySummed2)
    if ExtendedArraySummed(2,i)~=0
        counter = counter+1;
        ExtendedArraySummedRed(:,counter) = ExtendedArraySummed2(:,i);
    end
end
ExtendedArraySummed2=ExtendedArraySummedRed;
counts = 0;
for i = 2 : length(ExtendedArraySummed)-1
    if ExtendedArraySummed(2,i) == 0 && ExtendedArraySummed(2,i-1) ~= 0 && ExtendedArraySummed(2,i+1) ~= 0
        counts = counts + 1;
        ExtendedArraySummed2(:,counts) = [];
    end
end
ExtendedArraySummed = ExtendedArraySummed2;


%% Set zero values (-inf in dB) to 0.00001 (-100 dB)


ExtendedArraySummed100dBIndex =find(~real(ExtendedArraySummed(2,:)));
ExtendedArraySummed100dB=ExtendedArraySummed;
for i= 1:length(ExtendedArraySummed100dBIndex)
    Index=ExtendedArraySummed100dBIndex(i);
    ExtendedArraySummed100dB(2,Index)=0.00000001;
end




%% Ray tube method
 

Initial_Radiation_Angle = maxAngle - minAngle;                                     % For example 180 degrees for half-omnidirectional
Delta_Theta = Initial_Radiation_Angle / (maxangles); 

p_ray_unsrt =[];
gain = max(PatternArrayAngularIntensity(2,:)) / (sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)));
P_ray = PatternArrayAngularIntensity(2,:) * Delta_Theta /( sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)))*TxAntennaPower*0.5/pi();       

cnt=length(PatternArrayAngularIntensity);
p_ray_unsrt(1) = P_ray(1)/((PatternArrayAngularIntensity(1,1)-PatternArrayAngularIntensity(1,2))/2);
p_ray_unsrt(cnt) = P_ray(cnt)/((PatternArrayAngularIntensity(1,cnt)-PatternArrayAngularIntensity(1,cnt-1)));
for i = 1 : cnt-1
Delta_Theta_Pattern_Unsrt = PatternArrayAngularIntensity(1,i)-PatternArrayAngularIntensity(1,i+1);
p_ray_unsrt(i) = P_ray(i)/Delta_Theta_Pattern_Unsrt;
end

[PatternArrayRayTube(1,:),Sortingarray]=sort(PatternArrayAngularIntensity(1,:));

p_ray_unsrt=p_ray_unsrt(Sortingarray);
PatternArrayRayTube(2,:)= p_ray_unsrt;
MagEdB = 10*log10(abs(PatternArrayRayTube(2,:)));





%Export Tx antenna radiation pattern values for later

TxAntenna.Theta = Theta1;
TxAntenna.deltaTheta = deltaTheta;

TxAntenna.Pattern.AngularIntensity = PatternArrayAngularIntensity;

TxAntenna.Pattern.Values = patternValues;
TxAntenna.Pattern.Values90 = patternValues90;
TxAntenna.Pattern.RayTube = PatternArrayRayTube;
TxAntenna.Pattern.RayMethod = ExtendedArraySummed;
TxAntenna.Pattern.RayMethod100dB = ExtendedArraySummed100dB;

TxAntenna.powerPerRayFarfield = powerPerRayFarfield2;

TxAntenna.Power.RayMethod = trapz(ExtendedArraySummed(1,:),ExtendedArraySummed(2,:));
TxAntenna.Power.RayTube = trapz(PatternArrayRayTube(1,:),PatternArrayRayTube(2,:));
TxAntenna.Power.Inital = trapz(itdirIni,intensityAtPos);
%% Signal characterization



%%%%%%%%%%%%%%%%%%%%%%%%%%%% Required for test case

Cablelength1= 6.0;% 3.0; % [m]
Cablelength2= 5.0;% 3.5; % [m]
AdaptorLoss = 0.4; % [dB]
CableLoss = (0.37*(f/(10^9))^0.5)+(0.0071*(f/(10^9))); % [dB/m]; f in GHz
DCBlockLoss = 0.75; % [dB]
AdditionalLoss = 0; % [dB]
Windows = 0;% 2.258; % [dB]
%Ptx = 10; % [dBm]

%%%%%%%%%%%%%%%%%%%%%%%%%%%% End required for test case

Gamma_r = (recAntennasPosition(:,5)-1)./(recAntennasPosition(:,5)+1);
Gamma_t = (txAntenna_VSWR-1)./(txAntenna_VSWR+1);


%% Raw data of antenna pattern

rawDataPlotRx = TxAntenna.Pattern.Values; %rawDataPlotIni;

rawDataPlotRx = sort(rawDataPlotRx,2);


%% Add min and max angles to raw data & Identify antenna orientation

patternValuesInidBRx = rawDataPlotRx;

patternValuesIniRx = [patternValuesInidBRx(:,1),patternValuesInidBRx(:,2)]; % now in real values

% Rotate to antenna radiation direction
[maxIntensity,maxIntensityIndex] = max(patternValuesIniRx(:,1));
%[maxIntensity90,maxIntensityIndex90] = max(patternValuesIni90(:,1));
patternValuesIniRx(:,1)=patternValuesIniRx(:,1);%/maxIntensity;



IniPatternAntDirRx = patternValuesIniRx(maxIntensityIndex,2);


if MagneticField == 1
    
    %% Ray density refinement methoditdir
    
    
    %if rayDensityRefinement == 1
    % Get rays who leave domain
    if length(outsideLHCP(:,1))==1
        outsideLHCP = outsideLHCP';
    end
    
    counter=0;
    for i = 1:maxangles
        reflectionCeck = find(reflectionPointLHCP(:,i),1,'last');
         if isempty(reflectionCeck)
             reflectionCeck = 0;
         end
        if outsideLHCP(i,1)==1  || reflectionCeck >2 
            counter=counter+1;
            Pop1 = itdirLHCP(:,i);
            lastAngleRx(:,counter) = [itdirLHCP(1,i);Pop1(find(Pop1,1,'last'))];
            lastPosRx(:,counter) = [itpoLHCP(1:2,find(Pop1,1,'last'),i)];
            if isnan(lastAngleRx(2,counter))
                lastAngleRx(:,counter) = [itdirLHCP(1,i);Pop1(find(Pop1,1,'last')-1)];
                lastPosRx(:,counter) = [itpoLHCP(1:2,find(Pop1,1,'last')-1,i)];
            elseif lastAngleRx(2,counter) <0 
                lastAngleRx(2,counter) = lastAngleRx(2,counter)+360;
    
            end      
        else
            lastAngle2(i)=1;   
        end
    end 
    % Centre position of transmitting antenna
    centreTransAnt = [(pooo1(1)+pooo2(1))/2,(pooo1(2)+pooo2(2))/2,0];
    
    itdirMaster = itdirLHCP;
    itpoMaster = itpoLHCP;
    maxanglesMaster = maxangles;
    
    S_x1=zeros(1,length(recAntennasPosition(:,1)));
    S_x1_5=zeros(1,length(recAntennasPosition(:,1)));
    S_x2=zeros(1,length(recAntennasPosition(:,1)));
    S_x3=zeros(1,length(recAntennasPosition(:,1)));
    S_x4=zeros(1,length(recAntennasPosition(:,1)));
    raysReachingRx1 = zeros(length(recAntennasPosition(:,1)),1);
    for numA = 1:length(recAntennasPosition(:,1))
    
        ThetaToAddRx=recAntennasPosition(numA,3)-IniPatternAntDirRx;
    
        itdirAntRx=patternValuesIniRx(:,2)+ThetaToAddRx;
        for i = 1 : length(itdirAntRx)
            if itdirAntRx(i) <0
                itdirAntRx(i) = itdirAntRx(i)+360;
            end
            if itdirAntRx(i) > 360
                itdirAntRx(i) = itdirAntRx(i)-360;
            end
    
        end
        
        patternValuesRx = [patternValuesIniRx(:,1),itdirAntRx ];
    
        [C,ia,ic] = unique(patternValuesRx(:,1),'rows');
        patternValuesRx = patternValuesRx(ia,:);
        [C,ia,ic] = unique(patternValuesRx(:,2),'rows');
        patternValuesRx = patternValuesRx(ia,:);
        [~,idx] = sort(patternValuesRx(:,2));
        patternValuesRx = patternValuesRx(idx,:);  
        patternValuesRx(:,2) = real(patternValuesRx(:,2));
        if min(patternValuesRx(:,2)) > 0
            patternValuesRx = [patternValuesRx(1,1),0;patternValuesRx];
        end
        if max(patternValuesRx(:,2)) < 360
            patternValuesRx = [patternValuesRx;patternValuesRx(end,1),360];
        end
       
        
        
        %% Find rays reaching rx antenna
        
        % Initial computations
    
        wavelenght = physconst('LightSpeed')/f;
    
        %Effective antenna area
    
        A_wirk = wavelenght^2*10^(antennaGain/10)/(4*pi());
        %A_wirk2 = wavelenght^2/(4*pi())*(max(rawDataPlotIni(:,1).^2/(2*sqrt((1.25663706212*10^(-6))/(1*(8.8541878128*10^(-12)))))))*antennaEfficiency/TxAntennaPower;
        if A_wirk <  (recAntennasPosition(numA,6)*recAntennasPosition(numA,4))
            A_wirk = (recAntennasPosition(numA,6)*recAntennasPosition(numA,4));
        end
        yRange = sqrt(A_wirk);%/(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));
        zRange = sqrt(A_wirk);%(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));
    
        deltaX1 = cos(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaX2 = cos(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        deltaY1 = sin(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaY2 = sin(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        antPosX1(numA,1) = recAntennasPosition(numA,1)+deltaX1;
        antPosX2(numA,1) = recAntennasPosition(numA,1)+deltaX2;
        antPosY1(numA,1) = recAntennasPosition(numA,2)+deltaY1;
        antPosY2(numA,1) = recAntennasPosition(numA,2)+deltaY2;
        antPosZ1(numA,1) = 0+(zRange/2);
        antPosZ2(numA,1) = 0-(zRange/2);
        recAntLeft(numA,:) = [antPosX1(numA,1);antPosY1(numA,1);antPosZ1(numA,1)];
        recAntRight(numA,:) = [antPosX2(numA,1);antPosY2(numA,1);antPosZ2(numA,1)];
        recAntLeftOrigin(numA,:) = recAntLeft(numA,:) - centreTransAnt;
        recAntRightOrigin(numA,:) = recAntRight(numA,:) - centreTransAnt;
        
        alphaRxAntRange(1,1) = atan2d(norm(cross(recAntRightOrigin(numA,:),[1;0;0])),dot(recAntRightOrigin(numA,:),[1;0;0]));
        if recAntRightOrigin(numA,2) < 0
            alphaRxAntRange(1,1) = 360 - alphaRxAntRange(1,1);
        end
        alphaRxAntRange(1,2) = mod(atan2d(norm(cross(recAntLeftOrigin(numA,:),[1;0;0])),dot(recAntLeftOrigin(numA,:),[1;0;0])),360);
        if recAntLeftOrigin(2) < 0
            alphaRxAntRange(1,2) = 360 - alphaRxAntRange(1,2);
        end
       
    
        %raysReachingRx = find(real(PatternArraySortTx(1,:))>=min(alphaRxAntRange) & real(PatternArraySortTx(1,:))<=max(alphaRxAntRange));
        
        counting = 1;
        for k = 1 : maxanglesMaster
            rayRx = find(itdirMaster(:,k),1,'last');
            for l = 1: rayRx
                if itpoMaster(1,l,k)>=min([antPosX1(numA,1)*0.99,antPosX2(numA,1)*0.99]) && itpoMaster(1,l,k)<=max([antPosX1(numA,1)*1.01,antPosX2(numA,1)*1.01]) && itpoMaster(2,l,k)>=min([antPosY1(numA,1)*0.99,antPosY2(numA,1)*0.99]) && itpoMaster(2,l,k)<=max([antPosY1(numA,1)*1.01,antPosY2(numA,1)*1.01])
                    raysReachingRx1(numA,counting) = k; 
                    counting = counting+1;
                end
            end
        end
        %raysReachingRx1 = unique(raysReachingRx1);
        if (raysReachingRx1(numA,:)) == 0 %|| isempty(raysReachingRx1(numA,:))
            alphaRxAnt = atan2d(recAntennasPosition(numA,2)-centreTransAnt(2),recAntennasPosition(numA,1)-centreTransAnt(1));
            if alphaRxAnt < 0
                alphaRxAnt = alphaRxAnt+360;
            end
            [lastAngleRx(2,:),idxsort] = sort(lastAngleRx(2,:),2);
            lastAngleRx(1,:) = lastAngleRx(1,idxsort);
        % upperLimit = find(lastAngle(2,:) >= alpha1,1,'first');
            upperLimit = find(lastAngleRx(2,:) >= alphaRxAnt+1,1,'first');
            %dir1N(numA,1) = lastAngleRx(1,upperLimit);
        % lowerLimit = find(lastAngle(2,:) <= alpha2,1,'last');
            lowerLimit = find(lastAngleRx(2,:) <= alphaRxAnt-1,1,'last');
            %dir2N(numA,1) = lastAngleRx(1,lowerLimit);
            
            if isempty(upperLimit)
                dir1N(numA,1)=dir1;
            else
                dir1N(numA,1) = lastAngleRx(1,upperLimit);
            end
            if isempty(lowerLimit)
                dir2N(numA,1)=dir2;
            else
                dir2N(numA,1) = lastAngleRx(1,lowerLimit);
            end
        else
            caseDir = raysReachingRx1(numA,:);
            
            dir1N(numA,1) = itdirMaster(1,min(caseDir(caseDir>0)));
            while dir1N(numA,1) >180
                greater = min(caseDir(caseDir>0));
                dir1N(numA,1) = itdirMaster(1,min(caseDir(caseDir>greater)));
            end
            dir2N(numA,1) = itdirMaster(1,max(caseDir));
    
        end
    end
    if abs(max(dir1N)-min(dir2N)) < 16 || (abs(max(dir1N)-min(dir2N)) > 16 && abs(max(dir1N)-min(dir2N)) < 80)
        MidDir = abs(max(dir1N)-min(dir2N))/2+min(max(dir1N),min(dir2N));
        dir1N = MidDir + 8;
        dir2N = MidDir - 8;
    end
    dir1=round(max(dir1N(:,1)));
    dir2=round(min(dir2N(:,1)));
    
    
    
    
    %maxangles = round(1 * maxangles);
    maxangles = round(abs(dir1-dir2)*raysPerDegree);
    if maxangles >200
        maxangles = 200;
    end
    
    %% 2. Ray-tracing: compute paths of rays at antenna positions
    
    if solverSnell==1
        if MagneticField==0
            [itdir, itpo,symmetrylineencounter,outside]=raytracing(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,Cartesian,B1,B2,B3,MagneticField,z);
        elseif MagneticField==1
            [itdir, itpo,symmetrylineencounter,Y_int_1,Y_int_2,Y_int_3,YY,outside]=raytracing_Magnetic(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,Cartesian,B1,B2,B3,MagneticField);
        end
       % fprintf('\n %.2f s step 2 - ray-tracing - Snell Law solver ',cputime-initime)
    
        
    elseif solverEikonal==1
        if MagneticField==0
            [itdir, itpo,symmetrylineencounter,outside,reflectionPoint,domain]=eikonal2D_events(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f);
        elseif MagneticField==1
        %   [itdir, itpo,symmetrylineencounter,outside]=eikonal2D_Magnetic_2(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,z,Cartesian,B1,B2,B3,MagneticField);
        %    [itdir, itpo,symmetrylineencounter,outside,reflectionPoint,domain]=eikonal2D_MHD_Para_3(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,z,Cartesian,B1,B2,B3,MagneticField);
            [itdirLHCP,itpoLHCP,symmetrylineencounterLHCP,outsideLHCP,reflectionPointLHCP,domain]=eikonal2D_MHD_Para_3LHCP(domain,pooo1,pooo2,dir1,dir2,maxsteps,maxangles, absorptionlimits(2)-10,symmetryline,ss,f,z,Cartesian,B1,B2,B3,MagneticField);
        end
    
    else       
        error('Rays integration solver not identified')        
    end
    save('MEESST_MHD_RTSparamXO.mat', '-v7.3');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    


end

