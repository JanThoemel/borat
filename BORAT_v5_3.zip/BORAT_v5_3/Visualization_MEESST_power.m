%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load Solution
clear all
close all
%load('MHD_Solutions/MEESST_MHD_025T_125kW_34GHz_05rpd_correct.mat');
load('MEESST_MHD.mat');

%% 6.0 Signal Characterization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   


% Transmitted (accepted) power
TxAntennaPower = 0.001; % 0.6*0.01; % [W]
antennaEfficiency = 1;
raysPerDegree = 5;

% Signal characterization method
rayDensityRefinement =1;
rayMethod =0; %not used
rayToWaveTransitionMethod =0;%not used

% Antenna gain
if f == 34E9
    antennaGain = 14.89740976; % [dBi]
elseif f == 37E9
    antennaGain = 15.393065; % [dBi]
elseif f == 40E9
    antennaGain = 13.56515449; % [dBi]
else
    antennaGain = 15; % [dBi]
end

% Load radiation pattern
if f == 34e9 || f == 33e9 || f == 35e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_34GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_34GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [patternCoPlanarHorizontalSort(:,1).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [patternCoPlanarVerticalSort(:,1).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 37e9 || f == 36e9 || f == 38e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_37GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_37GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [patternCoPlanarHorizontalSort(:,1).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [patternCoPlanarVerticalSort(:,1).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 40e9 || f == 39e9
  %  patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_40GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_40GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [patternCoPlanarHorizontalSort(:,1).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [patternCoPlanarVerticalSort(:,1).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
end

% Power pattern [db W/m^2]

rawDataPlotIni = abs(patternCoPlanarHorizontal);

rawDataPlotIni90 = patternCoPlanarVertical;


%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

% Tx boresight direction
dirmainTrans =180;

% MEESST VSWR antenna
VSWR1 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 1.38,1.48,2.33,3.83,6.00,2.55,1.22,1.35];
VSWR2 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.82,2.03,2.67,3.3,3.36,1.77,2.47,8.39];
VSWR3 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.25,1.27,1.44,1.74,1.33,1.36,1.41,1.51];
VSWR4 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.41,1.24,1.86,1.5,1.56,1.42,2.18,2.08];


for i = 1: length(VSWR1)
    if VSWR1(1,i) == f
        txAntenna_VSWR = VSWR1(2,i); % from antenna, mean value
    end
end

%Antenna coordinates, main angle and aperture of each receiving antenna
antenna2_Xpos = 0.5105;
antenna2_Ypos = 0.15;
antenna2_dirmain = 340.47;
antenna2_antennaApertureY = 0.025;
antenna2_antennaApertureZ = 0.025;
for i = 1: length(VSWR2)
    if VSWR2(1,i) == f
        antenna2_VSWR = VSWR2(2,i); % from antenna, mean value
    end
end

antenna3_Xpos = 0.5135;
antenna3_Ypos = 0.155;
antenna3_dirmain = 360-20.256;
antenna3_antennaApertureY = 0.025;
antenna3_antennaApertureZ = 0.025;
for i = 1: length(VSWR3)
    if VSWR3(1,i) == f
        antenna3_VSWR = VSWR3(2,i); % from antenna, mean value
    end
end

antenna4_Xpos = 0.5135;
antenna4_Ypos = 0.295;
antenna4_dirmain = 360-35.08;
antenna4_antennaApertureY = 0.025;
antenna4_antennaApertureZ = 0.025;
for i = 1: length(VSWR4)
    if VSWR4(1,i) == f
        antenna4_VSWR = VSWR4(2,i); % from antenna, mean value
    end
end

recAntennasPosition = [antenna2_Xpos,antenna2_Ypos,antenna2_dirmain,antenna2_antennaApertureY,antenna2_VSWR,antenna2_antennaApertureZ;antenna3_Xpos,antenna3_Ypos,antenna3_dirmain,antenna3_antennaApertureY,antenna3_VSWR,antenna3_antennaApertureZ;antenna4_Xpos,antenna4_Ypos,antenna4_dirmain,antenna4_antennaApertureY,antenna4_VSWR,antenna4_antennaApertureZ];




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Raw data import (radiation pattern) and sorting the data in any case

rawDataPlotdB = rawDataPlotIni;
rawDataPlot90dB = rawDataPlotIni90;

%rawDataPlotdB = sort(rawDataPlotdB,2);
%rawDataPlot90dB = sort(rawDataPlot90dB,2);


%% Redraw the phi plane radiation pattern for correctness




%% Convert from dB to real valuse, rotate to boresight, save values for later and plot radaiaion patterns

% Convert dB to real values
patternValuesIni = [rawDataPlotdB(:,1),rawDataPlotdB(:,2)]; % now in real values

patternValuesIni90 = [rawDataPlot90dB(:,1),rawDataPlot90dB(:,2)]; % now in real values

% Rotate to antenna radiation direction
[maxIntensity,maxIntensityIndex] = max(patternValuesIni(:,1));
[maxIntensity90,maxIntensityIndex90] = max(patternValuesIni90(:,1));

IniPatternAntDir = patternValuesIni(maxIntensityIndex,2);
IniPatternAntDir90 = patternValuesIni90(maxIntensityIndex90,2);
ThetaToAdd=dirmainTrans-IniPatternAntDir;
ThetaToAdd90=dirmainTrans-IniPatternAntDir90;

% Make sure angles are between 0 and 360
itdirAnt=patternValuesIni(:,2)+ThetaToAdd;
for i = 1 : length(itdirAnt)
    if itdirAnt(i) > 360
        itdirAnt(i) = itdirAnt(i)-360;
    end
end

itdirAnt90=patternValuesIni90(:,2)+ThetaToAdd90;
for i = 1 : length(itdirAnt90)
    if itdirAnt90(i) > 360
        itdirAnt90(i) = itdirAnt90(i)-360;
    end
end

% Final pattern values of the Tx antenna, normalized (independend from
% distance
patternValues = [patternValuesIni(:,1),itdirAnt ];%/maxIntensity
patternValues90 = [patternValuesIni90(:,1),itdirAnt90 ];%/maxIntensity90

[C,ia,ic] = unique(patternValues(:,1),'rows');
patternValues = patternValues(ia,:);
[C,ia,ic] = unique(patternValues(:,2),'rows');
patternValues = patternValues(ia,:);
[C,ia,ic] = unique(patternValues90(:,1),'rows');
patternValues90 = patternValues90(ia,:);
[C,ia,ic] = unique(patternValues90(:,2),'rows');
patternValues90 = patternValues90(ia,:);
if min(patternValues(:,2)) > 0
    patternValues = [patternValues(1,1),0;patternValues];
end
if max(patternValues(:,2)) < 360
    patternValues = [patternValues;patternValues(end,1),360];
end
% Redraw the phi plane radiation pattern for correctness
rawDataPlotRad=deg2rad(patternValues90(:,2));



rawDataPlotRad=deg2rad(patternValues(:,2));

pause(1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 3D radiation pattern


%patternFromSlices(rawDataPlotdB(:,1),rawDataPlotdB(:,2),Helper',patternRadAngle);




%% Calculate power

%TxAntenna.Power.Correct = (2*pi/length(intensityAtPosRadPat))*(pi/2)*(sum(intensityAtPosRadPat90'.*sind(patternRadAngle))+sum(intensityAtPosRadPat'.*sind(patternRadAngle)));


%% Get intensities at ray positions

% Values from radiation pattern
minAngle = min(patternValues(:,2));
maxAngle = max(patternValues(:,2));

% Ray directions and angular distance between rays
itdirIni=itdir(1,:);

deltaTheta = (max(itdirIni)-min(itdirIni))/(maxangles);

% Intensity values of rays at phi = 0
intensityAtPos = interp1(patternValues(:,2),patternValues(:,1),itdirIni);

% Intensity values of rays at phi = 90
intensityAtPos90 = interp1(patternValues90(:,2),patternValues90(:,1),itdirIni);

%% Final radiation pattern

% Get rays who leave domain
if length(outside)<maxangles
    outside(maxangles)=0;
end

% Power and final angle of rays, which leave domain
powerPerRayFarfield2=zeros(1,sum(sum(outside)));
Theta1=zeros(1,sum(sum(outside)));

% Get power of rays who leave domain
counter=0;
for i = 1:maxangles
    reflectionCeck = find(reflectionPoint(:,i),1,'last');
    if isempty(reflectionCeck)
        reflectionCeck = 0;
    end
    if outside(i)==1 || reflectionCeck >2 
        counter=counter+1;
        Pop1 = itdir(:,i);
        Theta1(counter) = Pop1(find(Pop1,1,'last'));
        if isnan(Theta1(counter))
            Theta1(counter) = Pop1(find(Pop1,1,'last')-1);
        end 
        if Theta1(counter) < 0
            Theta1(counter) = Theta1(counter) +360;
        end
        powerPerRayFarfield2(counter)=intensityAtPos(i);
    else
        Theta2(i)=1; % Test variable
        
    end
end 
% Create matrix of Theta and pwoer per ray, get rid of NaNs and sort the
% array
PatternArrayAngularIntensity=[Theta1;powerPerRayFarfield2];
PatternArrayAngularIntensity = rmmissing(PatternArrayAngularIntensity,2);
[~,idx] = sort(PatternArrayAngularIntensity(1,:));
PatternArraySort2 = PatternArrayAngularIntensity(:,idx);

% Extend array by plcing values of the ray along delta Theta around the ray
% to find overlappings
% not considering interference atc.
ExtendedArrayAngularIntensity(1,:) = PatternArraySort2(1,1)-(deltaTheta/2):deltaTheta/100:PatternArraySort2(1,end)+(deltaTheta/2);

for i = 1:length(PatternArraySort2(1,:))
    Indexes = [];
    Indexes = find(ExtendedArrayAngularIntensity(1,:) >=PatternArraySort2(1,i)-(deltaTheta/2) & ExtendedArrayAngularIntensity(1,:) <PatternArraySort2(1,i)+(deltaTheta/2));
    for j = 1:length(Indexes)
        ExtendedArrayAngularIntensity(i+1,Indexes(j))=PatternArraySort2(2,i);
    end
end


ExtendedArraySummed(1,:) = ExtendedArrayAngularIntensity(1,:);
ExtendedArraySummed(2,:) = sum(ExtendedArrayAngularIntensity(2:end,:));
ExtendedArraySummed2 = ExtendedArraySummed;
counter = 0;
for i=1:length(ExtendedArraySummed2)
    if ExtendedArraySummed(2,i)~=0
        counter = counter+1;
        ExtendedArraySummedRed(:,counter) = ExtendedArraySummed2(:,i);
    end
end
ExtendedArraySummed2=ExtendedArraySummedRed;
counts = 0;
for i = 2 : length(ExtendedArraySummed)-1
    if ExtendedArraySummed(2,i) == 0 && ExtendedArraySummed(2,i-1) ~= 0 && ExtendedArraySummed(2,i+1) ~= 0
        counts = counts + 1;
        ExtendedArraySummed2(:,counts) = [];
    end
end
ExtendedArraySummed = ExtendedArraySummed2;


%% Set zero values (-inf in dB) to 0.00001 (-100 dB)


ExtendedArraySummed100dBIndex =find(~real(ExtendedArraySummed(2,:)));
ExtendedArraySummed100dB=ExtendedArraySummed;
for i= 1:length(ExtendedArraySummed100dBIndex)
    Index=ExtendedArraySummed100dBIndex(i);
    ExtendedArraySummed100dB(2,Index)=0.00000001;
end




%% Ray tube method
 

Initial_Radiation_Angle = maxAngle - minAngle;                                     % For example 180 degrees for half-omnidirectional
Delta_Theta = Initial_Radiation_Angle / (maxangles); 

p_ray_unsrt =[];
gain = max(PatternArrayAngularIntensity(2,:)) / (sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)));
P_ray = PatternArrayAngularIntensity(2,:) * Delta_Theta /( sum(PatternArrayAngularIntensity(2,:))/length(PatternArrayAngularIntensity(2,:)))*TxAntennaPower*0.5/pi();       

cnt=length(PatternArrayAngularIntensity);
p_ray_unsrt(1) = P_ray(1)/((PatternArrayAngularIntensity(1,1)-PatternArrayAngularIntensity(1,2))/2);
p_ray_unsrt(cnt) = P_ray(cnt)/((PatternArrayAngularIntensity(1,cnt)-PatternArrayAngularIntensity(1,cnt-1)));
for i = 1 : cnt-1
Delta_Theta_Pattern_Unsrt = PatternArrayAngularIntensity(1,i)-PatternArrayAngularIntensity(1,i+1);
p_ray_unsrt(i) = P_ray(i)/Delta_Theta_Pattern_Unsrt;
end

[PatternArrayRayTube(1,:),Sortingarray]=sort(PatternArrayAngularIntensity(1,:));

p_ray_unsrt=p_ray_unsrt(Sortingarray);
PatternArrayRayTube(2,:)= p_ray_unsrt;
MagEdB = 10*log10(abs(PatternArrayRayTube(2,:)));





%Export Tx antenna radiation pattern values for later

TxAntenna.Theta = Theta1;
TxAntenna.deltaTheta = deltaTheta;

TxAntenna.Pattern.AngularIntensity = PatternArrayAngularIntensity;

TxAntenna.Pattern.Values = patternValues;
TxAntenna.Pattern.Values90 = patternValues90;
TxAntenna.Pattern.RayTube = PatternArrayRayTube;
TxAntenna.Pattern.RayMethod = ExtendedArraySummed;
TxAntenna.Pattern.RayMethod100dB = ExtendedArraySummed100dB;

TxAntenna.powerPerRayFarfield = powerPerRayFarfield2;

TxAntenna.Power.RayMethod = trapz(ExtendedArraySummed(1,:),ExtendedArraySummed(2,:));
TxAntenna.Power.RayTube = trapz(PatternArrayRayTube(1,:),PatternArrayRayTube(2,:));
TxAntenna.Power.Inital = trapz(itdirIni,intensityAtPos);
%% Signal characterization



%%%%%%%%%%%%%%%%%%%%%%%%%%%% Required for test case

Cablelength1= 6.0;% 3.0; % [m]
Cablelength2= 5.0;% 3.5; % [m]
AdaptorLoss = 0.4; % [dB]
CableLoss = (0.37*(f/(10^9))^0.5)+(0.0071*(f/(10^9))); % [dB/m]; f in GHz
DCBlockLoss = 0.75; % [dB]
AdditionalLoss = 0; % [dB]
Windows = 0;% 2.258; % [dB]
%Ptx = 10; % [dBm]

%%%%%%%%%%%%%%%%%%%%%%%%%%%% End required for test case

Gamma_r = (recAntennasPosition(:,5)-1)./(recAntennasPosition(:,5)+1);
Gamma_t = (txAntenna_VSWR-1)./(txAntenna_VSWR+1);


%% Raw data of antenna pattern

rawDataPlotRx = TxAntenna.Pattern.Values; %rawDataPlotIni;

rawDataPlotRx = sort(rawDataPlotRx,2);


%% Add min and max angles to raw data & Identify antenna orientation

patternValuesInidBRx = rawDataPlotRx;

patternValuesIniRx = [patternValuesInidBRx(:,1),patternValuesInidBRx(:,2)]; % now in real values

% Rotate to antenna radiation direction
[maxIntensity,maxIntensityIndex] = max(patternValuesIniRx(:,1));
%[maxIntensity90,maxIntensityIndex90] = max(patternValuesIni90(:,1));
patternValuesIniRx(:,1)=patternValuesIniRx(:,1);%/maxIntensity;



IniPatternAntDirRx = patternValuesIniRx(maxIntensityIndex,2);



%% Ray density refinement methoditdir


%if rayDensityRefinement == 1
% Get rays who leave domain
if length(outside(:,1))==1
    outside = outside';
end

counter=0;
for i = 1:maxangles
    reflectionCeck = find(reflectionPoint(:,i),1,'last');
    if isempty(reflectionCeck)
        reflectionCeck = 0;
    end
    if outside(i,1)==1  || reflectionCeck >2 
        counter=counter+1;
        Pop1 = itdir(:,i);
        lastAngleRx(:,counter) = [itdir(1,i);Pop1(find(Pop1,1,'last'))];
        lastPosRx(:,counter) = [itpo(1:2,find(Pop1,1,'last'),i)];
        if isnan(lastAngleRx(2,counter))
            lastAngleRx(:,counter) = [itdir(1,i);Pop1(find(Pop1,1,'last')-1)];
            lastPosRx(:,counter) = [itpo(1:2,find(Pop1,1,'last')-1,i)];
        elseif lastAngleRx(2,counter) <0 
            lastAngleRx(2,counter) = lastAngleRx(2,counter)+360;

        end      
    else
        lastAngle2(i)=1;   
    end
end 
% Centre position of transmitting antenna
centreTransAnt = [(pooo1(1)+pooo2(1))/2,(pooo1(2)+pooo2(2))/2,0];

itdirMaster = itdir;
itpoMaster = itpo;
maxanglesMaster = maxangles;

S_x1=zeros(1,length(recAntennasPosition(:,1)));
S_x1_5=zeros(1,length(recAntennasPosition(:,1)));
S_x2=zeros(1,length(recAntennasPosition(:,1)));
S_x3=zeros(1,length(recAntennasPosition(:,1)));
S_x4=zeros(1,length(recAntennasPosition(:,1)));

for numA = 1:1%length(recAntennasPosition(:,1))

    ThetaToAddRx=recAntennasPosition(numA,3)-IniPatternAntDirRx;

    itdirAntRx=patternValuesIniRx(:,2)+ThetaToAddRx;
    for i = 1 : length(itdirAntRx)
        if itdirAntRx(i) <0
            itdirAntRx(i) = itdirAntRx(i)+360;
        end
        if itdirAntRx(i) > 360
            itdirAntRx(i) = itdirAntRx(i)-360;
        end

    end
    
    patternValuesRx = [patternValuesIniRx(:,1),itdirAntRx ];

    [C,ia,ic] = unique(patternValuesRx(:,1),'rows');
    patternValuesRx = patternValuesRx(ia,:);
    [C,ia,ic] = unique(patternValuesRx(:,2),'rows');
    patternValuesRx = patternValuesRx(ia,:);
    [~,idx] = sort(patternValuesRx(:,2));
    patternValuesRx = patternValuesRx(idx,:);  
    patternValuesRx(:,2) = real(patternValuesRx(:,2));
    if min(patternValuesRx(:,2)) > 0
        patternValuesRx = [patternValuesRx(1,1),0;patternValuesRx];
    end
    if max(patternValuesRx(:,2)) < 360
        patternValuesRx = [patternValuesRx;patternValuesRx(end,1),360];
    end
   
    
    
    %% Find rays reaching rx antenna
    
    % Initial computations

    wavelenght = physconst('LightSpeed')/f;

    %Effective antenna area

    A_wirk = wavelenght^2*10^(antennaGain/10)/(4*pi());
    %A_wirk2 = wavelenght^2/(4*pi())*(max(rawDataPlotIni(:,1).^2/(2*sqrt((1.25663706212*10^(-6))/(1*(8.8541878128*10^(-12)))))))*antennaEfficiency/TxAntennaPower;
    if A_wirk <  (recAntennasPosition(numA,6)*recAntennasPosition(numA,4))
        A_wirk = (recAntennasPosition(numA,6)*recAntennasPosition(numA,4));
    end
    yRange = sqrt(A_wirk);%/(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));
    zRange = sqrt(A_wirk);%(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));

    deltaX1 = cos(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
    deltaX2 = cos(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
    deltaY1 = sin(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
    deltaY2 = sin(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
    antPosX1(numA,1) = recAntennasPosition(numA,1)+deltaX1;
    antPosX2(numA,1) = recAntennasPosition(numA,1)+deltaX2;
    antPosY1(numA,1) = recAntennasPosition(numA,2)+deltaY1;
    antPosY2(numA,1) = recAntennasPosition(numA,2)+deltaY2;
    antPosZ1(numA,1) = 0+(zRange/2);
    antPosZ2(numA,1) = 0-(zRange/2);
    recAntLeft(numA,:) = [antPosX1(numA,1);antPosY1(numA,1);antPosZ1(numA,1)];
    recAntRight(numA,:) = [antPosX2(numA,1);antPosY2(numA,1);antPosZ2(numA,1)];
    recAntLeftOrigin(numA,:) = recAntLeft(numA,:) - centreTransAnt;
    recAntRightOrigin(numA,:) = recAntRight(numA,:) - centreTransAnt;
    
    alphaRxAntRange(1,1) = atan2d(norm(cross(recAntRightOrigin(numA,:),[1;0;0])),dot(recAntRightOrigin(numA,:),[1;0;0]));
    if recAntRightOrigin(numA,2) < 0
        alphaRxAntRange(1,1) = 360 - alphaRxAntRange(1,1);
    end
    alphaRxAntRange(1,2) = mod(atan2d(norm(cross(recAntLeftOrigin(numA,:),[1;0;0])),dot(recAntLeftOrigin(numA,:),[1;0;0])),360);
    if recAntLeftOrigin(2) < 0
        alphaRxAntRange(1,2) = 360 - alphaRxAntRange(1,2);
    end
   

    %raysReachingRx = find(real(PatternArraySortTx(1,:))>=min(alphaRxAntRange) & real(PatternArraySortTx(1,:))<=max(alphaRxAntRange));
    %raysReachingRx1 = [];
%     counting = 1;
%     for k = 1 : maxanglesMaster
%         rayRx = find(itdirMaster(:,k),1,'last');
%         for l = 1: rayRx
%             if itpoMaster(1,l,k)>=min([antPosX1(numA,1)*0.99,antPosX2(numA,1)*0.99]) && itpoMaster(1,l,k)<=max([antPosX1(numA,1)*1.01,antPosX2(numA,1)*1.01]) && itpoMaster(2,l,k)>=min([antPosY1(numA,1)*0.99,antPosY2(numA,1)*0.99]) && itpoMaster(2,l,k)<=max([antPosY1(numA,1)*1.01,antPosY2(numA,1)*1.01])
%                 raysReachingRx1(numA,counting) = k; 
%                 counting = counting+1;
%             end
%         end
%     end
%     %raysReachingRx1 = unique(raysReachingRx1);
%     if isempty(raysReachingRx1(numA,:))
%         alphaRxAnt = atan2d(recAntennasPosition(numA,2)-centreTransAnt(2),recAntennasPosition(numA,1)-centreTransAnt(1));
%         if alphaRxAnt < 0
%             alphaRxAnt = alphaRxAnt+360;
%         end
%         [lastAngleRx(2,:),idxsort] = sort(lastAngleRx(2,:),2);
%         lastAngleRx(1,:) = lastAngleRx(1,idxsort);
%        % upperLimit = find(lastAngle(2,:) >= alpha1,1,'first');
%         upperLimit = find(lastAngleRx(2,:) >= alphaRxAnt+1,1,'first');
%         dir1N(numA,1) = lastAngleRx(1,upperLimit);
%        % lowerLimit = find(lastAngle(2,:) <= alpha2,1,'last');
%         lowerLimit = find(lastAngleRx(2,:) <= alphaRxAnt-1,1,'last');
%         dir2N(numA,1) = lastAngleRx(1,lowerLimit);
%         
%         if isempty(dir1N(numA,1))
%             dir1N(numA,1)=dir1;
%         end
%         if isempty(dir2N(numA,1))
%             dir2N(numA,1)=dir2;
%         end
%     else
%         caseDir = raysReachingRx1(numA,:);
%         
%         dir1N(numA,1) = itdirMaster(1,min(caseDir(caseDir>0)));
%         while dir1N(numA,1) >180
%             greater = min(caseDir(caseDir>0));
%             dir1N(numA,1) = itdirMaster(1,min(caseDir(caseDir>greater)));
%         end
%         dir2N(numA,1) = itdirMaster(1,max(caseDir));
% 
%     end
end
% if abs(max(dir1N)-min(dir2N)) < 16 %|| abs(max(dir1N)-min(dir2N)) > 16
%     MidDir = abs(max(dir1N)-min(dir2N))/2+min(max(dir1N),min(dir2N));
%     dir1N = MidDir + 8;
%     dir2N = MidDir - 8;
% end


itdirIniTx=itdir(1,:);

deltaThetaTx = (max(itdirIniTx)-min(itdirIniTx))/(maxangles);


intensityAtPosTx = interp1(TxAntenna.Pattern.Values(:,2),TxAntenna.Pattern.Values(:,1),itdirIniTx);

% Display radiation pattern with rays in dB (Power pattern)




%% Ray area, arc length and Jacobian

% wavelength = physconst('LightSpeed')/f;
% radiusStart = 0.000001*wavelength;
% initialRayArea = 4*(norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]))^2*sind(deltaThetaTx/2)^2;
% omega = 2*pi()*f;
%c0 = physconst('LightSpeed');

%% Arc length
arcLength = zeros(maxsteps,maxangles);
for k = 1: maxangles
    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);

    arcLength(1,k) = norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]);

    for l = 2 : lastNonZero
        arcLength(l,k) = norm([itpo(1,l,k),itpo(2,l,k),0]-[itpo(1,l-1,k),itpo(2,l-1,k),0]);
    end
end

%% Ray distance/area
rayDistance = zeros(maxsteps,maxangles);
rayArea = zeros(maxsteps,maxangles);
rayDistanceEnd = zeros(1,maxangles);
for k = 1: maxangles-1
    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
    lastNonZeroPlus = find(itdir(:,k+1),1,'last');
    rayDistance(1,k) = 2*(norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]))*sind(deltaThetaTx/2);
    rayArea(1,k) = rayDistance(1,k)^2;
    for l = 2 : lastNonZero
        rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(l,k+1)))*sum(arcLength(1:l,k));
        rayArea(l,k) = rayDistance(l,k)^2;
        if lastNonZero > lastNonZeroPlus
            rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(lastNonZeroPlus,k+1)))*sum(arcLength(1:l,k));
            rayArea(l,k) = rayDistance(l,k)^2;
        end
    end
    rayDistanceEnd(1,k) = abs(rayDistance(lastNonZero,k));
end
rayArea(1,maxangles) = rayDistance(1,maxangles-1)^2;


for k = maxangles
    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
    lastNonZeroPlus = find(itdir(:,k-1),1,'last');
    rayDistance(1,k) = 2*(norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]))*sind(deltaThetaTx/2);
    rayArea(1,k) = rayDistance(1,k)^2;
    for l = 2 : lastNonZero

        rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(l,k-1)))*sum(arcLength(1:l,k));
        rayArea(l,k) = rayDistance(l,k)^2;
        if lastNonZero > lastNonZeroPlus
            rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(lastNonZeroPlus,k-1)))*sum(arcLength(1:l,k));
            rayArea(l,k) = rayDistance(l,k)^2;
        end
    end
    rayDistanceEnd(1,k) = abs(rayDistance(lastNonZero,k));
end


%% Final radiation pattern

% Get rays who leave domain

if length(outside(:,1))<maxangles
    outside(maxangles)=0;
end

% powerPerRayFarfieldTx=zeros(1,sum(outside(:,1)));

%Theta1=zeros(1,sum(outside(:,1)));

% Get power of rays who leave domain
xComponent = zeros(1,maxangles);
yComponent = zeros(1,maxangles);
 counter=0;
 for i = 1:maxangles
     reflectionCeck = find(reflectionPoint(:,i),1,'last');
     if isempty(reflectionCeck)
         reflectionCeck = 0;
     end
     if outside(i,1)==1  || reflectionCeck >2 
         counter=counter+1;
         Pop1 = itdir(:,i);
%             Theta1(counter) = Pop1(find(Pop1,1,'last'));
%             if isnan(Theta1(counter))
%                 Theta1(counter) = Pop1(find(Pop1,1,'last')-1);
%             end      
%             powerPerRayFarfieldTx(counter)=intensityAtPosTx(i);
         xComponent(i)=itpo(1,find(Pop1,1,'last'),i);
         yComponent(i)=itpo(2,find(Pop1,1,'last'),i);
%         else
%             Theta2(i)=1;
%             
%         end
%         if counter~=0 && Theta1(counter) <0
%             Theta1(counter)=Theta1(counter)+360;
     end
 end 
ThetaEnd=zeros(1,maxangles);
for i = 1:maxangles
   
    Pop1 = itdir(:,i);
    ThetaEnd(1,i) = Pop1(find(Pop1,1,'last'));
    if isnan(ThetaEnd(1,i))
        ThetaEnd(1,i) = Pop1(find(Pop1,1,'last')-1);
    end      

    if ThetaEnd(1,i) <0
        ThetaEnd(1,i)=ThetaEnd(1,i)+360;
    end
end

%     PatternArrayTx=[Theta1;powerPerRayFarfieldTx];
%     PatternArrayTx = rmmissing(PatternArrayTx,2);
%     [~,idx] = sort(real(PatternArrayTx(1,:)));
%     PatternArraySortTx = PatternArrayTx(:,idx);
%     for oo = 1 : length(PatternArraySortTx(2,:))
%         PatternArraySortTxNew(2,oo) = PatternArraySortTx(2,oo) * exp(1i*omega/c0 * arcLength(1,oo))/(exp(1i*omega/c0)*arcLength(1,oo));
%     end






%% Find rays reaching rx antenna

% Initial computations

% wavelenght = physconst('LightSpeed')/f;
% 
% %Effective antenna area
% 
% A_wirk = wavelenght^2*10^(antennaGain/10)/(4*pi());
% %A_wirk2 = wavelenght^2/(4*pi())*(max(rawDataPlotIni(:,1).^2/(2*sqrt((1.25663706212*10^(-6))/(1*(8.8541878128*10^(-12)))))))*antennaEfficiency/TxAntennaPower;
% if A_wirk <  (recAntennasPosition(numA,6)*recAntennasPosition(numA,4))
%     A_wirk = (recAntennasPosition(numA,6)*recAntennasPosition(numA,4));
% end
%yRange = sqrt(A_wirk);%/(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));
%zRange = sqrt(A_wirk);%(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));


%% New signal characterization approach

reflectionPoints = zeros(maxsteps,maxangles);

for k = 1 : maxangles
    reflectionPos = 0;
    for ii = 1:length(find(reflectionPoint(:,k)~=0))
        reflectionPos = reflectionPos+ reflectionPoint(ii,k);
        reflectionPoints(reflectionPos,k) = 1;
    end
end

% reflectionPoint = zeros(maxsteps,maxangles);


%itdirIni=itdir(1,:);
if itdir(1,:) == 0
    %itdirIni = itdir(2,:);
    itdir2 = itdir(2:end,:);
    itdir = itdir2;
end
for k = 1 :maxangles
    for l = 1:maxsteps
        if itdir(l,k) <0
            itdir(l,k) = itdir(l,k) +360;
        end
    end
end

%deltaTheta = (max(itdirIni)-min(itdirIni))/(maxangles);

%% Communication

% Losses of components

Ltx = AdaptorLoss + (CableLoss*Cablelength1) + DCBlockLoss + AdditionalLoss;
Lrx = AdaptorLoss + (CableLoss*Cablelength2) + DCBlockLoss + AdditionalLoss + Windows;
TxAntennaPowerdB = 10*log10(TxAntennaPower);
TxAntennaPowerLtx = 10^((TxAntennaPowerdB-Ltx)/10);
Com.Losses=Lrx;
% Get magnetic field information

for zonesNumbers = 1 : domain.nozones
    if MagneticField==1 % Check if this works
        Bfield = [domain.(strcat('zone',num2str(zonesNumbers))).variables(3,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(4,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(5,:)'];
        B_vec_mag=zeros(domain.nozones,length(Bfield));
    
        for i=1:length(Bfield)
            B_vec_mag(zonesNumbers,i)= sqrt(Bfield(i,1)^2 +Bfield(i,2)^2 +Bfield(i,3)^2)+(50*10^(-6));
        end
    elseif MagneticField==0
        for i=1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables)
            B_vec_mag(zonesNumbers,i)= (50*10^(-6));
        end
    end
    
    domain.(strcat('zone',num2str(zonesNumbers))).variables(end+1,:)=B_vec_mag(zonesNumbers,1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables));

end
B_average1 = zeros(maxsteps,maxangles);
N_average1 = zeros(maxsteps,maxangles);
totalElectronCount1 = zeros(maxsteps,maxangles);
if MagneticField==0
    parfor k = 1: maxangles
        B_average1For = zeros(maxsteps,1);
        N_average1For = zeros(maxsteps,1);
        totalElectronCount1For = zeros(maxsteps,1);
        lastNonZero = find(itdir(:,k),1,'last');
        lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        for l = 1: lastNonZero
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova+1))
                B_average1For(l,1) = 0;
            else
                B_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova+3);
            end
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova-5))
                N_average1For(l,1) = 0;
            else
                N_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova-5);
            end
           
            totalElectronCount1For(l,1) = N_average1For(l,1) * arcLength(l,k);
        end
        B_average1(:,k) = B_average1For(:,1);
        N_average1(:,k) = N_average1For(:,1);
        totalElectronCount1(:,k) = totalElectronCount1For(:,1);
    end
elseif MagneticField==1
    parfor k = 1: maxangles
        B_average1For = zeros(maxsteps,1);
        N_average1For = zeros(maxsteps,1);
        totalElectronCount1For = zeros(maxsteps,1);
        lastNonZero = find(itdir(:,k),1,'last');
        lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        for l = 1: lastNonZero
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova+1))
                B_average1For(l,1) = 0;
            else
                B_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova+15);
            end
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova-5))
                N_average1For(l,1) = 0;
            else
                N_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova-5);
            end
           
            totalElectronCount1For(l,1) = N_average1For(l,1) * arcLength(l,k);
        end
        B_average1(:,k) = B_average1For(:,1);
        N_average1(:,k) = N_average1For(:,1);
        totalElectronCount1(:,k) = totalElectronCount1For(:,1);
    end
end

%% Calculate energy along rays

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

omega = 2*pi()*f;
c0 = physconst('LightSpeed');
deltaRay = zeros(maxsteps,maxangles);
chi = zeros(3,maxsteps,maxangles);
chi2 = zeros(3,maxsteps,maxangles);
dirFinal = zeros(1,maxangles);


for k = 1: maxangles
    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
    dirFinal(1,k) = lastNonZero;
    deltaRay(1,k) = 0;
    for l = 2 : lastNonZero
        deltaRay(l,k) = norm([itpo(1,l,k),itpo(2,l,k),0]-[itpo(1,l-1,k),itpo(2,l-1,k),0]);

        chi(:,l,k) = ([itpo(1,l,k),itpo(2,l,k),0]-[itpo(1,l-1,k),itpo(2,l-1,k),0])/deltaRay(l,k);
        chi2(:,l,k) = ([itpo(1,l,k),itpo(2,l,k),0]-[itpo(1,l-1,k),itpo(2,l-1,k),0])/deltaRay(l,k)*itpo(4,l-1,k);

    end
   
end


%% Amplitude evolution along ray

 polarizationEvolutionTotal = zeros(1,maxangles);
 powerTransmittedBORAT8End = zeros(1,maxangles);
 powerOut = zeros(maxsteps,maxangles);
 refractiveIndexEnd = zeros(1,maxangles);

 parfor k = 1: maxangles
    powerTransmittedBORATS = zeros(maxsteps,maxangles);
    powerTransmittedBORATP = zeros(maxsteps,maxangles);
    powerTransmittedBORAT8 = zeros(maxsteps,maxangles);
    polVector = zeros(2,maxsteps,maxangles);
    polVectorGlobal = zeros(3,maxsteps,maxangles);
    FarRot = zeros(maxsteps,maxangles);
    reflectionLossS = zeros(maxsteps,maxangles);
    reflectionLossP = zeros(maxsteps,maxangles);
    absorption = zeros(maxsteps,maxangles);
    phaseShift = zeros(maxsteps,maxangles);
    spreadFactor = zeros(maxsteps,maxangles);
    deltaRay = zeros(maxsteps,maxangles);

    itpos = itpo;

    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpos(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpos(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpos(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
    polVector(1:2,1,k) = [sqrt(cosd(itdir(1,k)+90)^2 + sind(itdir(1,k)+90)^2),0];
    polVector(:,1,k) = 1/norm(polVector(:,1,k)) * polVector(:,1,k);
    polVectorGlobal(1:3,1,k) = [cosd(itdir(1,k)+90), sind(itdir(1,k)+90), 0];
    polVectorGlobal(:,1,k) = 1/norm(polVectorGlobal(:,1,k)) * polVectorGlobal(:,1,k);

    powerTransmittedBORAT8(1,k) = TxAntennaPower * (abs(dir1-dir2)/maxangles/360)* intensityAtPosTx(k).^2*length(TxAntenna.Pattern.Values(:,1))./sum(TxAntenna.Pattern.Values(:,1).^2);
    powerTransmittedBORATS(1,k) = powerTransmittedBORAT8(1,k) * polVector(2,1,k);
    powerTransmittedBORATP(1,k) = powerTransmittedBORAT8(1,k) * polVector(1,1,k);
    powerTransmittedBORAT8(1,k) = sqrt(powerTransmittedBORATP(1,k)^2 + powerTransmittedBORATS(1,k)^2);

    for l = 2 : lastNonZero

        if reflectionPoints(l,k) == 0

            FarRot(l,k) = (2.36*10^(4)/(f^2))*totalElectronCount1(l,k)*(B_average1(l,k));
            angleOutOfPlane = atan2(real(polVector(1,l-1,k)),real(polVector(2,l-1,k)))+FarRot(l,k);
            polVector(2,l,k) = sin(angleOutOfPlane);
            polVector(1,l,k) = cos(angleOutOfPlane);
            polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);

    
            if itdir(l-1,k) < itdir(l,k)
                reflectionAngle = round(abs((itdir(l-1,k) + 180 - itdir(l,k)) / 2),1);
            elseif itdir(l-1,k) >= itdir(l,k)
                reflectionAngle = round(abs((itdir(l-1,k) - 180 - itdir(l,k))) / 2,1);
            end

            reflectionCoeffS = ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle)) - (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2)))) / ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle)) + (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2))));
            reflectionCoeffP = ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle)) - (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2)))) / ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle)) + (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2))));

            if isnan(reflectionCoeffS)
            reflectionCoeffS = 0;
            end
            if isnan(reflectionCoeffP)
                reflectionCoeffP = 0;
            end

            reflectionLossS(l,k) = (1 - abs(reflectionCoeffS)^2);
            reflectionLossP(l,k) = (1 - abs(reflectionCoeffP)^2);

            if round(abs(reflectionCoeffP)) == 1
                reflectionLossP(l,k) =1;
            end
            if round(abs(reflectionCoeffS)) == 1
                reflectionLossS(l,k) =1;
            end
            absorption(l,k) = exp(-abs((2*pi*f/physconst('LightSpeed'))*itpos(5,l,k))*arcLength(l,k));
            deltaRay(l,k) = norm([itpos(1,l,k),itpos(2,l,k),0]-[itpos(1,l-1,k),itpos(2,l-1,k),0]);
            phaseShift(l,k) = exp(-1i*(2*pi*f*(itpos(4,l,k)-1)*deltaRay(l,k)/physconst('LightSpeed')));
            spreadFactor(l,k) = sqrt((2*sqrt((1.25663706212*10^(-6))/(itpos(4,l,k)^2*(8.8541878128*10^(-12)))))/(2*sqrt((1.25663706212*10^(-6))/(itpos(4,l-1,k)^2*(8.8541878128*10^(-12))))) * (rayArea(l-1,k)./rayArea(l,k)));

            powerTransmittedBORAT8(l,k) = abs(powerTransmittedBORAT8(l-1,k) * absorption(l,k) * spreadFactor(l,k) * phaseShift(l,k));

            powerTransmittedBORATS(l,k) = powerTransmittedBORAT8(l,k) * polVector(2,l,k) * reflectionLossS(l,k);
            powerTransmittedBORATP(l,k) = powerTransmittedBORAT8(l,k) * polVector(1,l,k) * reflectionLossP(l,k);

            powerTransmittedBORAT8(l,k) = sqrt(powerTransmittedBORATP(l,k)^2 + powerTransmittedBORATS(l,k)^2);

            if powerTransmittedBORAT8(l,k) == 0 || isnan(powerTransmittedBORAT8(l,k))
                    hi=1;
            end

            if powerTransmittedBORAT8(l,k) == 0 && k>1
                hi=1;
            end

            polVector(:,l,k) = [powerTransmittedBORATP(l,k),powerTransmittedBORATS(l,k)];
            polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);

            polVectorGlobal(1,l,k) = powerTransmittedBORATP(l,k) * cosd(itdir(l,k)+90);
            polVectorGlobal(2,l,k) = powerTransmittedBORATP(l,k) * sind(itdir(l,k)+90);
            polVectorGlobal(3,l,k) = powerTransmittedBORATS(l,k);
            polVectorGlobal(:,l,k) = 1/norm(polVectorGlobal(:,l,k)) * polVectorGlobal(:,l,k);
            

        elseif reflectionPoints(l,k) ~= 0

            if itpos(4,l,k) > itpos(4,l-1,k)

                if reflectionAngle < atand(real(itpos(4,l,k)/itpos(4,l-1,k)))
                    phaseShiftReflP = 1;
                    phaseShiftReflS = exp(1i*pi());

                elseif reflectionAngle > atand(real(itpos(4,l,k)/itpos(4,l-1,k)))

                    phaseShiftReflP = exp(1i*pi());
                    phaseShiftReflS = exp(1i*pi());

                end

            else

                if reflectionAngle < atand(real(itpos(4,l,k)/itpos(4,l-1,k)))

                    phaseShiftReflP = exp(1i*pi());
                    phaseShiftReflS = 1;

                elseif (atand(real(itpos(4,l,k)/itpos(4,l-1,k))) < reflectionAngle) && reflectionAngle < asind(real(itpos(4,l,k)/itpos(4,l-1,k)))

                    phaseShiftReflP = 1;
                    phaseShiftReflS = 1;


                elseif reflectionAngle > asind(real(itpos(4,l,k)/itpos(4,l-1,k)))

                    phaseShiftReflP = exp(1i*2*(atand(itpos(4,l-1,k)^2/(itpos(4,l,k)^2*cosd(reflectionAngle)))*sqrt((sind(reflectionAngle))^2 - (itpos(4,l,k)/itpos(4,l-1,k)^2))));
                    phaseShiftReflS = exp(1i*2*(atan(1/(cosd(reflectionAngle)))*sqrt((sind(reflectionAngle))^2 - (itpos(4,l,k)/itpos(4,l-1,k)^2)))) ;

                end
            end


            FarRot(l,k) = (2.36*10^(4)/(f^2))*totalElectronCount1(l,k)*(B_average1(l,k));
            angleOutOfPlane = atan2(real(polVector(1,l-1,k)),real(polVector(2,l-1,k)))+FarRot(l,k);
            polVector(2,l,k) = sin(angleOutOfPlane);
            polVector(1,l,k) = cos(angleOutOfPlane);
            polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);

    
            if itdir(l-1,k) < itdir(l,k)
                reflectionAngle = round(abs((itdir(l-1,k) + 180 - itdir(l,k)) / 2),1);
            elseif itdir(l-1,k) >= itdir(l,k)
                reflectionAngle = round(abs((itdir(l-1,k) - 180 - itdir(l,k))) / 2,1);
            end

            reflectionCoeffS = ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle)) - (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2)))) / ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle)) + (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2))));
            reflectionCoeffP = ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle)) - (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2)))) / ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle)) + (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle))^2))));

            if isnan(reflectionCoeffS)
                reflectionCoeffS = 0;
            end
            if isnan(reflectionCoeffP)
                reflectionCoeffP = 0;
            end

            reflectionLossS(l,k) = (1);
            reflectionLossP(l,k) = (1);
            absorption(l,k) = exp(-abs((2*pi*f/physconst('LightSpeed'))*itpos(5,l,k))*arcLength(l,k));
            deltaRay(l,k) = norm([itpos(1,l,k),itpos(2,l,k),0]-[itpos(1,l-1,k),itpos(2,l-1,k),0]);
            phaseShift(l,k) = exp(-1i*(2*pi*f*(itpos(4,l,k)-1)*deltaRay(l,k)/physconst('LightSpeed')));
            spreadFactor(l,k) = sqrt((2*sqrt((1.25663706212*10^(-6))/(itpos(4,l,k)^2*(8.8541878128*10^(-12)))))/(2*sqrt((1.25663706212*10^(-6))/(itpos(4,l-1,k)^2*(8.8541878128*10^(-12))))) * (rayArea(l-1,k)./rayArea(l,k)));

            powerTransmittedBORAT8(l,k) = abs(powerTransmittedBORAT8(l-1,k) * absorption(l,k) * spreadFactor(l,k) * phaseShift(l,k)); % losses from Point n-1 to Point n

            powerTransmittedBORATS(l,k) = powerTransmittedBORAT8(l,k) * polVector(2,l,k) * reflectionLossS(l,k) * phaseShiftReflS; % losses at Point n perpendicular
            powerTransmittedBORATP(l,k) = powerTransmittedBORAT8(l,k) * polVector(1,l,k) * reflectionLossP(l,k) * phaseShiftReflP; % losses at Point n parallel

            powerTransmittedBORAT8(l,k) = sqrt(powerTransmittedBORATP(l,k)^2 + powerTransmittedBORATS(l,k)^2); % total power after all losses at point n

            if powerTransmittedBORAT8(l,k) == 0 || isnan(powerTransmittedBORAT8(l,k))
                    hi=1;
            end

            polVector(:,l,k) = [powerTransmittedBORATP(l,k),powerTransmittedBORATS(l,k)]; % polarization vector local on ray in perpendicular (2) and parallel direction(1)
            polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);

            polVectorGlobal(1,l,k) = powerTransmittedBORATP(l,k) * cosd(itdir(l,k)+90); % polarization vector gobal
            polVectorGlobal(2,l,k) = powerTransmittedBORATP(l,k) * sind(itdir(l,k)+90);
            polVectorGlobal(3,l,k) = powerTransmittedBORATS(l,k);
            polVectorGlobal(:,l,k) = 1/norm(polVectorGlobal(:,l,k)) * polVectorGlobal(:,l,k);





        end

    end
    powerTransmittedBORAT8End(1,k) = powerTransmittedBORAT8(l,k);
    powerOut(:,k) = powerTransmittedBORAT8(:,k);
    refractiveIndexEnd(1,k) = itpos(4,l,k);
    polarizationEvolutionTotal(1,k) = atan2d(real(polVector(1,l,k)),real(polVector(2,l,k)))-atan2d(real(polVector(1,1,k)),real(polVector(2,1,k)));
end

if MagneticField == 1




    
    %% Ray density refinement methoditdir
    
    
    %if rayDensityRefinement == 1
    % Get rays who leave domain
    if length(outsideLHCP(:,1))==1
        outsideLHCP = outsideLHCP';
    end
    
    counter=0;
    for i = 1:maxangles
        reflectionCeck = find(reflectionPointLHCP(:,i),1,'last');
         if isempty(reflectionCeck)
             reflectionCeck = 0;
         end
        if outsideLHCP(i,1)==1  || reflectionCeck >2 
            counter=counter+1;
            Pop1 = itdirLHCP(:,i);
            lastAngleRx(:,counter) = [itdirLHCP(1,i);Pop1(find(Pop1,1,'last'))];
            lastPosRx(:,counter) = [itpoLHCP(1:2,find(Pop1,1,'last'),i)];
            if isnan(lastAngleRx(2,counter))
                lastAngleRx(:,counter) = [itdirLHCP(1,i);Pop1(find(Pop1,1,'last')-1)];
                lastPosRx(:,counter) = [itpoLHCP(1:2,find(Pop1,1,'last')-1,i)];
            elseif lastAngleRx(2,counter) <0 
                lastAngleRx(2,counter) = lastAngleRx(2,counter)+360;
    
            end      
        else
            lastAngle2(i)=1;   
        end
    end 
    % Centre position of transmitting antenna
    centreTransAnt = [(pooo1(1)+pooo2(1))/2,(pooo1(2)+pooo2(2))/2,0];
    
    itdirMaster = itdirLHCP;
    itpoMaster = itpoLHCP;
    maxanglesMaster = maxangles;
    
    S_x1=zeros(1,length(recAntennasPosition(:,1)));
    S_x1_5=zeros(1,length(recAntennasPosition(:,1)));
    S_x2=zeros(1,length(recAntennasPosition(:,1)));
    S_x3=zeros(1,length(recAntennasPosition(:,1)));
    S_x4=zeros(1,length(recAntennasPosition(:,1)));
    
    for numA = 1:1%length(recAntennasPosition(:,1))
    
        ThetaToAddRx=recAntennasPosition(numA,3)-IniPatternAntDirRx;
    
        itdirAntRx=patternValuesIniRx(:,2)+ThetaToAddRx;
        for i = 1 : length(itdirAntRx)
            if itdirAntRx(i) <0
                itdirAntRx(i) = itdirAntRx(i)+360;
            end
            if itdirAntRx(i) > 360
                itdirAntRx(i) = itdirAntRx(i)-360;
            end
    
        end
        
        patternValuesRx = [patternValuesIniRx(:,1),itdirAntRx ];
    
        [C,ia,ic] = unique(patternValuesRx(:,1),'rows');
        patternValuesRx = patternValuesRx(ia,:);
        [C,ia,ic] = unique(patternValuesRx(:,2),'rows');
        patternValuesRx = patternValuesRx(ia,:);
        [~,idx] = sort(patternValuesRx(:,2));
        patternValuesRx = patternValuesRx(idx,:);  
        patternValuesRx(:,2) = real(patternValuesRx(:,2));
        if min(patternValuesRx(:,2)) > 0
            patternValuesRx = [patternValuesRx(1,1),0;patternValuesRx];
        end
        if max(patternValuesRx(:,2)) < 360
            patternValuesRx = [patternValuesRx;patternValuesRx(end,1),360];
        end
       
        
        
        %% Find rays reaching rx antenna
        
        % Initial computations
    
        wavelenght = physconst('LightSpeed')/f;
    
        %Effective antenna area
    
        A_wirk = wavelenght^2*10^(antennaGain/10)/(4*pi());
        %A_wirk2 = wavelenght^2/(4*pi())*(max(rawDataPlotIni(:,1).^2/(2*sqrt((1.25663706212*10^(-6))/(1*(8.8541878128*10^(-12)))))))*antennaEfficiency/TxAntennaPower;
        if A_wirk <  (recAntennasPosition(numA,6)*recAntennasPosition(numA,4))
            A_wirk = (recAntennasPosition(numA,6)*recAntennasPosition(numA,4));
        end
        yRange = sqrt(A_wirk);%/(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));
        zRange = sqrt(A_wirk);%(2 * norm([recAntennasPosition(1,1)-itpo(1,1,1),recAntennasPosition(numA,2)-itpo(2,1,1),0]) * sin(deltaThetaTx/2));
    
        deltaX1 = cos(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaX2 = cos(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        deltaY1 = sin(deg2rad(recAntennasPosition(numA,3)-90))*(yRange/2);
        deltaY2 = sin(deg2rad(recAntennasPosition(numA,3)+90))*(yRange/2);
        antPosX1(numA,1) = recAntennasPosition(numA,1)+deltaX1;
        antPosX2(numA,1) = recAntennasPosition(numA,1)+deltaX2;
        antPosY1(numA,1) = recAntennasPosition(numA,2)+deltaY1;
        antPosY2(numA,1) = recAntennasPosition(numA,2)+deltaY2;
        antPosZ1(numA,1) = 0+(zRange/2);
        antPosZ2(numA,1) = 0-(zRange/2);
        recAntLeft(numA,:) = [antPosX1(numA,1);antPosY1(numA,1);antPosZ1(numA,1)];
        recAntRight(numA,:) = [antPosX2(numA,1);antPosY2(numA,1);antPosZ2(numA,1)];
        recAntLeftOrigin(numA,:) = recAntLeft(numA,:) - centreTransAnt;
        recAntRightOrigin(numA,:) = recAntRight(numA,:) - centreTransAnt;
        
        alphaRxAntRange(1,1) = atan2d(norm(cross(recAntRightOrigin(numA,:),[1;0;0])),dot(recAntRightOrigin(numA,:),[1;0;0]));
        if recAntRightOrigin(numA,2) < 0
            alphaRxAntRange(1,1) = 360 - alphaRxAntRange(1,1);
        end
        alphaRxAntRange(1,2) = mod(atan2d(norm(cross(recAntLeftOrigin(numA,:),[1;0;0])),dot(recAntLeftOrigin(numA,:),[1;0;0])),360);
        if recAntLeftOrigin(2) < 0
            alphaRxAntRange(1,2) = 360 - alphaRxAntRange(1,2);
        end
       
   
    end

    %% Assign transmitting antenna values to new rays
    
    
    itdirIniTx=itdirLHCP(1,:);
    
    deltaThetaTx = (max(itdirIniTx)-min(itdirIniTx))/(maxangles);
    
    
    intensityAtPosTx = interp1(TxAntenna.Pattern.Values(:,2),TxAntenna.Pattern.Values(:,1),itdirIniTx);
    
    % Display radiation pattern with rays in dB (Power pattern)
    

    
    %% Arc length
    arcLength = zeros(maxsteps,maxangles);
    for k = 1: maxangles
        lastNonZero = find(itdirLHCP(:,k),1,'last');
        lastNonZeroPo1 = find(itpoLHCP(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpoLHCP(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpoLHCP(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
    
        arcLength(1,k) = norm([itpoLHCP(1,2,k),itpoLHCP(2,2,k),0]-[itpoLHCP(1,1,k),itpoLHCP(2,1,k),0]);
    
        for l = 2 : lastNonZero
            arcLength(l,k) = norm([itpoLHCP(1,l,k),itpoLHCP(2,l,k),0]-[itpoLHCP(1,l-1,k),itpoLHCP(2,l-1,k),0]);
        end
    end
    
    %% Ray distance/area
    rayDistance = zeros(maxsteps,maxangles);
    rayArea = zeros(maxsteps,maxangles);
    rayDistanceEnd = zeros(1,maxangles);
    for k = 1: maxangles-1
        lastNonZero = find(itdirLHCP(:,k),1,'last');
        lastNonZeroPo1 = find(itpoLHCP(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpoLHCP(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpoLHCP(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        lastNonZeroPlus = find(itdirLHCP(:,k+1),1,'last');
        rayDistance(1,k) = 2*(norm([itpoLHCP(1,2,k),itpoLHCP(2,2,k),0]-[itpoLHCP(1,1,k),itpoLHCP(2,1,k),0]))*sind(deltaThetaTx/2);
        rayArea(1,k) = rayDistance(1,k)^2;
        for l = 2 : lastNonZero
            rayDistance(l,k) = sind(abs(itdirLHCP(l,k)-itdirLHCP(l,k+1)))*sum(arcLength(1:l,k));
            rayArea(l,k) = rayDistance(l,k)^2;
            if lastNonZero > lastNonZeroPlus
                rayDistance(l,k) = sind(abs(itdirLHCP(l,k)-itdirLHCP(lastNonZeroPlus,k+1)))*sum(arcLength(1:l,k));
                rayArea(l,k) = rayDistance(l,k)^2;
            end
        end
        rayDistanceEnd(1,k) = abs(rayDistance(lastNonZero,k));
    end
    rayArea(1,maxangles) = rayDistance(1,maxangles-1)^2;
    
    
    for k = maxangles
        lastNonZero = find(itdirLHCP(:,k),1,'last');
        lastNonZeroPo1 = find(itpoLHCP(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpoLHCP(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpoLHCP(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        lastNonZeroPlus = find(itdirLHCP(:,k-1),1,'last');
        rayDistance(1,k) = 2*(norm([itpoLHCP(1,2,k),itpoLHCP(2,2,k),0]-[itpoLHCP(1,1,k),itpoLHCP(2,1,k),0]))*sind(deltaThetaTx/2);
        rayArea(1,k) = rayDistance(1,k)^2;
        for l = 2 : lastNonZero
    
            rayDistance(l,k) = sind(abs(itdirLHCP(l,k)-itdirLHCP(l,k-1)))*sum(arcLength(1:l,k));
            rayArea(l,k) = rayDistance(l,k)^2;
            if lastNonZero > lastNonZeroPlus
                rayDistance(l,k) = sind(abs(itdirLHCP(l,k)-itdirLHCP(lastNonZeroPlus,k-1)))*sum(arcLength(1:l,k));
                rayArea(l,k) = rayDistance(l,k)^2;
            end
        end
        rayDistanceEnd(1,k) = abs(rayDistance(lastNonZero,k));
    end
    
    
    %% Final radiation pattern
    
    % Get rays who leave domain
    
    if length(outsideLHCP(:,1))<maxangles
        outsideLHCP(maxangles)=0;
    end
    
 
    
    % Get power of rays who leave domain
    xComponent = zeros(1,maxangles);
    yComponent = zeros(1,maxangles);
     counter=0;
     for i = 1:maxangles
         reflectionCeck = find(reflectionPointLHCP(:,i),1,'last');
         if isempty(reflectionCeck)
             reflectionCeck = 0;
         end
         if outsideLHCP(i,1)==1 || reflectionCeck >2 
             counter=counter+1;
             Pop1 = itdirLHCP(:,i);

             xComponent(i)=itpoLHCP(1,find(Pop1,1,'last'),i);
             yComponent(i)=itpoLHCP(2,find(Pop1,1,'last'),i);

         end
     end 
    ThetaEnd=zeros(1,maxangles);
    for i = 1:maxangles
       
        Pop1 = itdirLHCP(:,i);
        ThetaEnd(1,i) = Pop1(find(Pop1,1,'last'));
        if isnan(ThetaEnd(1,i))
            ThetaEnd(1,i) = Pop1(find(Pop1,1,'last')-1);
        end      
    
        if ThetaEnd(1,i) <0
            ThetaEnd(1,i)=ThetaEnd(1,i)+360;
        end
    end
    

    %% New signal characterization approach
    
    reflectionPoints = zeros(maxsteps,maxangles);
    
    for k = 1 : maxangles
        reflectionPos = 0;
        for ii = 1:length(find(reflectionPointLHCP(:,k)~=0))
            reflectionPos = reflectionPos+ reflectionPointLHCP(ii,k);
            reflectionPoints(reflectionPos,k) = 1;
        end
    end
    

    if itdirLHCP(1,:) == 0
     
        itdir2 = itdirLHCP(2:end,:);
        itdirLHCP = itdir2;
    end
    for k = 1 :maxangles
        for l = 1:maxsteps
            if itdirLHCP(l,k) <0
                itdirLHCP(l,k) = itdirLHCP(l,k) +360;
            end
        end
    end
    

    
    %% Communication
    
    % Losses of components
    
    Ltx = AdaptorLoss + (CableLoss*Cablelength1) + DCBlockLoss + AdditionalLoss;
    Lrx = AdaptorLoss + (CableLoss*Cablelength2) + DCBlockLoss + AdditionalLoss + Windows;
    TxAntennaPowerdB = 10*log10(TxAntennaPower);
    TxAntennaPowerLtx = 10^((TxAntennaPowerdB-Ltx)/10);
    Com.Losses=Lrx;
    % Get magnetic field information
    
    for zonesNumbers = 1 : domain.nozones
        if MagneticField==1 % Check if this works
            Bfield = [domain.(strcat('zone',num2str(zonesNumbers))).variables(3,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(4,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(5,:)'];
            B_vec_mag=zeros(domain.nozones,length(Bfield));
        
            for i=1:length(Bfield)
                B_vec_mag(zonesNumbers,i)= sqrt(Bfield(i,1)^2 +Bfield(i,2)^2 +Bfield(i,3)^2)+(50*10^(-6));
            end
        elseif MagneticField==0
            for i=1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables)
                B_vec_mag(zonesNumbers,i)= (50*10^(-6));
            end
        end
        
        domain.(strcat('zone',num2str(zonesNumbers))).variables(end+1,:)=B_vec_mag(zonesNumbers,1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables));
    
    end
    B_average1 = zeros(maxsteps,maxangles);
    N_average1 = zeros(maxsteps,maxangles);
    totalElectronCount1 = zeros(maxsteps,maxangles);
    parfor k = 1: maxangles
        B_average1For = zeros(maxsteps,1);
        N_average1For = zeros(maxsteps,1);
        totalElectronCount1For = zeros(maxsteps,1);
        lastNonZero = find(itdirLHCP(:,k),1,'last');
        lastNonZeroPo1 = find(itpoLHCP(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpoLHCP(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpoLHCP(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        for l = 1: lastNonZero
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova+1))
                B_average1For(l,1) = 0;
            else
                B_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova+15);
            end
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova-5))
                N_average1For(l,1) = 0;
            else
                N_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova-5);
            end
           
            totalElectronCount1For(l,1) = N_average1For(l,1) * arcLength(l,k);
        end
        B_average1(:,k) = B_average1For(:,1);
        N_average1(:,k) = N_average1For(:,1);
        totalElectronCount1(:,k) = totalElectronCount1For(:,1);
    end
    
    %% Calculate energy along rays
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    omega = 2*pi()*f;
    c0 = physconst('LightSpeed');
    deltaRay = zeros(maxsteps,maxangles);
    chi = zeros(3,maxsteps,maxangles);
    chi2 = zeros(3,maxsteps,maxangles);
    dirFinal = zeros(1,maxangles);
    
    
    for k = 1: maxangles
        lastNonZero = find(itdirLHCP(:,k),1,'last');
        lastNonZeroPo1 = find(itpoLHCP(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpoLHCP(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpoLHCP(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        dirFinal(1,k) = lastNonZero;
        deltaRay(1,k) = 0;
        for l = 2 : lastNonZero
            deltaRay(l,k) = norm([itpoLHCP(1,l,k),itpoLHCP(2,l,k),0]-[itpoLHCP(1,l-1,k),itpoLHCP(2,l-1,k),0]);
    
            chi(:,l,k) = ([itpoLHCP(1,l,k),itpoLHCP(2,l,k),0]-[itpoLHCP(1,l-1,k),itpoLHCP(2,l-1,k),0])/deltaRay(l,k);
            chi2(:,l,k) = ([itpoLHCP(1,l,k),itpoLHCP(2,l,k),0]-[itpoLHCP(1,l-1,k),itpoLHCP(2,l-1,k),0])/deltaRay(l,k)*itpoLHCP(4,l-1,k);
    
        end
       
    end
    
    
    %% Amplitude evolution along ray
    
     
     
     polarizationEvolutionTotal = zeros(1,maxangles);
     powerTransmittedBORAT8End = zeros(1,maxangles);
     powerMHD = zeros(maxsteps,maxangles);
     refractiveIndexEnd = zeros(1,maxangles);

     parfor k = 1: maxangles
        powerTransmittedBORATS = zeros(maxsteps,maxangles);
        powerTransmittedBORATP = zeros(maxsteps,maxangles);
        powerTransmittedBORAT8 = zeros(maxsteps,maxangles);
        polVector = zeros(2,maxsteps,maxangles);
        polVectorGlobal = zeros(3,maxsteps,maxangles);
        FarRot = zeros(maxsteps,maxangles);
        reflectionLossS = zeros(maxsteps,maxangles);
        reflectionLossP = zeros(maxsteps,maxangles);
        absorption = zeros(maxsteps,maxangles);
        phaseShift = zeros(maxsteps,maxangles);
        spreadFactor = zeros(maxsteps,maxangles);
        deltaRay = zeros(maxsteps,maxangles);
    
        itpos = itpoLHCP;
    
        lastNonZero = find(itdirLHCP(:,k),1,'last');
        lastNonZeroPo1 = find(itpos(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpos(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpos(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        
        polVector(1:2,1,k) = [sqrt(cosd(itdirLHCP(1,k)+90)^2 + sind(itdirLHCP(1,k)+90)^2),0];
        polVector(:,1,k) = 1/norm(polVector(:,1,k)) * polVector(:,1,k);
        polVectorGlobal(1:3,1,k) = [cosd(itdirLHCP(1,k)+90), sind(itdirLHCP(1,k)+90), 0];
        polVectorGlobal(:,1,k) = 1/norm(polVectorGlobal(:,1,k)) * polVectorGlobal(:,1,k);
    
        powerTransmittedBORAT8(1,k) = TxAntennaPower * (abs(dir1-dir2)/maxangles/360)* intensityAtPosTx(k).^2*length(TxAntenna.Pattern.Values(:,1))./sum(TxAntenna.Pattern.Values(:,1).^2);
        powerTransmittedBORATS(1,k) = powerTransmittedBORAT8(1,k) * polVector(2,1,k);
        powerTransmittedBORATP(1,k) = powerTransmittedBORAT8(1,k) * polVector(1,1,k);
        powerTransmittedBORAT8(1,k) = sqrt(powerTransmittedBORATP(1,k)^2 + powerTransmittedBORATS(1,k)^2);
    
        for l = 2 : lastNonZero
    
            if reflectionPoints(l,k) == 0
    
                FarRot(l,k) = (2.36*10^(4)/(f^2))*totalElectronCount1(l,k)*(B_average1(l,k));
                angleOutOfPlane = atan2(real(polVector(1,l-1,k)),real(polVector(2,l-1,k)))+FarRot(l,k);
                polVector(2,l,k) = sin(angleOutOfPlane);
                polVector(1,l,k) = cos(angleOutOfPlane);
                polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);
    
        
                if itdirLHCP(l-1,k) < itdirLHCP(l,k)
                    reflectionAngle1 = round(abs((itdirLHCP(l-1,k) + 180 - itdirLHCP(l,k)) / 2),1);
                elseif itdirLHCP(l-1,k) >= itdirLHCP(l,k)
                    reflectionAngle1 = round(abs((itdirLHCP(l-1,k) - 180 - itdirLHCP(l,k))) / 2,1);
                end
    
                reflectionCoeffS = ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle1)) - (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2)))) / ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle1)) + (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2))));
                reflectionCoeffP = ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle1)) - (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2)))) / ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle1)) + (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2))));
    
                if isnan(reflectionCoeffS)
                reflectionCoeffS = 0;
                end
                if isnan(reflectionCoeffP)
                    reflectionCoeffP = 0;
                end
    
                reflectionLossS(l,k) = (1 - abs(reflectionCoeffS)^2);
                reflectionLossP(l,k) = (1 - abs(reflectionCoeffP)^2);

                if round(abs(reflectionCoeffP)) == 1
                    reflectionLossP(l,k) =1;
                end
                if round(abs(reflectionCoeffS)) == 1
                    reflectionLossS(l,k) =1;
                end
                absorption(l,k) = exp(-abs((2*pi*f/physconst('LightSpeed'))*itpos(5,l,k))*arcLength(l,k));
                deltaRay(l,k) = norm([itpos(1,l,k),itpos(2,l,k),0]-[itpos(1,l-1,k),itpos(2,l-1,k),0]);
                phaseShift(l,k) = exp(-1i*(2*pi*f*(itpos(4,l,k)-1)*deltaRay(l,k)/physconst('LightSpeed')));
                spreadFactor(l,k) = sqrt((2*sqrt((1.25663706212*10^(-6))/(itpos(4,l,k)^2*(8.8541878128*10^(-12)))))/(2*sqrt((1.25663706212*10^(-6))/(itpos(4,l-1,k)^2*(8.8541878128*10^(-12))))) * (rayArea(l-1,k)./rayArea(l,k)));
    
                powerTransmittedBORAT8(l,k) = abs(powerTransmittedBORAT8(l-1,k) * absorption(l,k) * spreadFactor(l,k) * phaseShift(l,k));
    
                powerTransmittedBORATS(l,k) = powerTransmittedBORAT8(l,k) * polVector(2,l,k) * reflectionLossS(l,k);
                powerTransmittedBORATP(l,k) = powerTransmittedBORAT8(l,k) * polVector(1,l,k) * reflectionLossP(l,k);
    
                powerTransmittedBORAT8(l,k) = sqrt(powerTransmittedBORATP(l,k)^2 + powerTransmittedBORATS(l,k)^2);

                if powerTransmittedBORAT8(l,k) == 0 || isnan(powerTransmittedBORAT8(l,k))
                    hi=1;
                end
    
                polVector(:,l,k) = [powerTransmittedBORATP(l,k),powerTransmittedBORATS(l,k)];
                polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);
    
                polVectorGlobal(1,l,k) = powerTransmittedBORATP(l,k) * cosd(itdirLHCP(l,k)+90);
                polVectorGlobal(2,l,k) = powerTransmittedBORATP(l,k) * sind(itdirLHCP(l,k)+90);
                polVectorGlobal(3,l,k) = powerTransmittedBORATS(l,k);
                polVectorGlobal(:,l,k) = 1/norm(polVectorGlobal(:,l,k)) * polVectorGlobal(:,l,k);
    
            elseif reflectionPoints(l,k) ~= 0
    
                if itpos(4,l,k) > itpos(4,l-1,k)
    
                    if reflectionAngle1 < atand(real(itpos(4,l,k)/itpos(4,l-1,k)))
                        phaseShiftReflP1 = 1;
                        phaseShiftReflS1 = exp(1i*pi());
    
                    elseif reflectionAngle1 > atand(real(itpos(4,l,k)/itpos(4,l-1,k)))
    
                        phaseShiftReflP1 = exp(1i*pi());
                        phaseShiftReflS1 = exp(1i*pi());
    
                    end
    
                else
    
                    if reflectionAngle1 < atand(real(itpos(4,l,k)/itpos(4,l-1,k)))
    
                        phaseShiftReflP1 = exp(1i*pi());
                        phaseShiftReflS1 = 1;
    
                    elseif atand(real(itpos(4,l,k)/itpos(4,l-1,k))) < reflectionAngle1 && reflectionAngle1 < asind(real(itpos(4,l,k)/itpos(4,l-1,k)))
    
                        phaseShiftReflP1 = 1;
                        phaseShiftReflS1 = 1;
    
    
                    elseif reflectionAngle1 > asind(real(itpos(4,l,k)/itpos(4,l-1,k)))
    
                        phaseShiftReflP1 = exp(1i*2*(atan(itpos(4,l-1,k)^2/(itpos(4,l,k)^2*cosd(reflectionAngle1)))*sqrt((sind(reflectionAngle1))^2 - (itpos(4,l,k)/itpos(4,l-1,k)^2))));
                        phaseShiftReflS1 = exp(1i*2*(atan(1/(cosd(reflectionAngle1)))*sqrt((sind(reflectionAngle1))^2 - (itpos(4,l,k)/itpos(4,l-1,k)^2)))) ;
    
                    end
                end
    
    
                FarRot(l,k) = (2.36*10^(4)/(f^2))*totalElectronCount1(l,k)*(B_average1(l,k));
                angleOutOfPlane = atan2(real(polVector(1,l-1,k)),real(polVector(2,l-1,k)))+FarRot(l,k);
                polVector(2,l,k) = sin(angleOutOfPlane);
                polVector(1,l,k) = cos(angleOutOfPlane);
                polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);
    
        
                if itdirLHCP(l-1,k) < itdirLHCP(l,k)
                    reflectionAngle1 = round(abs((itdirLHCP(l-1,k) + 180 - itdirLHCP(l,k)) / 2),1);
                elseif itdirLHCP(l-1,k) >= itdirLHCP(l,k)
                    reflectionAngle1 = round(abs((itdirLHCP(l-1,k) - 180 - itdirLHCP(l,k))) / 2,1);
                end
    
                reflectionCoeffS = ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle1)) - (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2)))) / ((round(itpos(4,l-1,k),4) * cosd(reflectionAngle1)) + (1 * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2))));
                reflectionCoeffP = ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle1)) - (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2)))) / ((1 * round(itpos(4,l,k),4)^2 * cosd(reflectionAngle1)) + (round(itpos(4,l-1,k),4) * sqrt(round(itpos(4,l,k),4)^2 - (round(itpos(4,l-1,k),4)^2 * (sind(reflectionAngle1))^2))));
    
                if isnan(reflectionCoeffS)
                    reflectionCoeffS = 0;
                end
                if isnan(reflectionCoeffP)
                    reflectionCoeffP = 0;
                end
    
                reflectionLossS(l,k) = (1);
                reflectionLossP(l,k) = (1);
                absorption(l,k) = exp(-abs((2*pi*f/physconst('LightSpeed'))*itpos(5,l,k))*arcLength(l,k));
                deltaRay(l,k) = norm([itpos(1,l,k),itpos(2,l,k),0]-[itpos(1,l-1,k),itpos(2,l-1,k),0]);
                phaseShift(l,k) = exp(-1i*(2*pi*f*(itpos(4,l,k)-1)*deltaRay(l,k)/physconst('LightSpeed')));
                spreadFactor(l,k) = sqrt((2*sqrt((1.25663706212*10^(-6))/(itpos(4,l,k)^2*(8.8541878128*10^(-12)))))/(2*sqrt((1.25663706212*10^(-6))/(itpos(4,l-1,k)^2*(8.8541878128*10^(-12))))) * (rayArea(l-1,k)./rayArea(l,k)));
    
                powerTransmittedBORAT8(l,k) = abs(powerTransmittedBORAT8(l-1,k) * absorption(l,k) * spreadFactor(l,k) * phaseShift(l,k)); % losses from Point n-1 to Point n
    
                powerTransmittedBORATS(l,k) = powerTransmittedBORAT8(l,k) * polVector(2,l,k) * reflectionLossS(l,k) * phaseShiftReflS1; % losses at Point n perpendicular
                powerTransmittedBORATP(l,k) = powerTransmittedBORAT8(l,k) * polVector(1,l,k) * reflectionLossP(l,k) * phaseShiftReflP1; % losses at Point n parallel
    
                powerTransmittedBORAT8(l,k) = sqrt(powerTransmittedBORATP(l,k)^2 + powerTransmittedBORATS(l,k)^2); % total power after all losses at point n
    
                if powerTransmittedBORAT8(l,k) == 0 || isnan(powerTransmittedBORAT8(l,k))
                    hi=1;
                end

                polVector(:,l,k) = [powerTransmittedBORATP(l,k),powerTransmittedBORATS(l,k)]; % polarization vector local on ray in perpendicular (2) and parallel direction(1)
                polVector(:,l,k) = 1/norm(polVector(:,l,k)) * polVector(:,l,k);
    
                polVectorGlobal(1,l,k) = powerTransmittedBORATP(l,k) * cosd(itdirLHCP(l,k)+90); % polarization vector gobal
                polVectorGlobal(2,l,k) = powerTransmittedBORATP(l,k) * sind(itdirLHCP(l,k)+90);
                polVectorGlobal(3,l,k) = powerTransmittedBORATS(l,k);
                polVectorGlobal(:,l,k) = 1/norm(polVectorGlobal(:,l,k)) * polVectorGlobal(:,l,k);
    
    
    
    
    
            end
    
        end
        powerTransmittedBORAT8End(1,k) = powerTransmittedBORAT8(l,k);
        powerMHD(:,k) = powerTransmittedBORAT8(:,k);
        refractiveIndexEnd(1,k) = itpos(4,l,k);
        polarizationEvolutionTotal(1,k) = atan2d(real(polVector(1,l,k)),real(polVector(2,l,k)))-atan2d(real(polVector(1,1,k)),real(polVector(2,1,k)));
    end
    
    
end

if MagneticField==0
    for k = 1 : maxangles
        maxStepsOverAllRays(1,k) = nnz(powerOut(:,k));
    end
    
    powerNormalized = zeros(max(maxStepsOverAllRays),maxangles);
    for k = 1 : maxangles
        for l = 1 : max(maxStepsOverAllRays)
            
            powerNormalized(l,k) = powerOut(l,k)/max(powerOut(1,:));
        end
        powerLastValue(k) = powerOut(nnz(powerOut(:,k)),k);
        
      %  itpo(2,:,:)=itpo(2,:,:)*(-1);
    end
    

    save('MEESST_MHD_SigChar_power.mat', '-v7.3');

elseif MagneticField==1

    for k = 1 : maxangles
        maxStepsOverAllRays(1,k) = nnz(powerOut(:,k));
    end

    powerNormalized = zeros(max(maxStepsOverAllRays),maxangles);
    for k = 1 : maxangles
        for l = 1 : max(maxStepsOverAllRays)

            powerNormalized(l,k) = powerOut(l,k)/max(powerOut(1,:));
        end

        powerRayLastValue(k) = powerOut(nnz(powerOut(:,k)),k);
       % itpo(2,:,:)=itpo(2,:,:)*(-1);
       % itpoLHCP(2,:,:)=itpoLHCP(2,:,:)*(-1);
    end

    for k = 1 : maxangles
        maxStepsOverAllRays(1,k) = nnz(powerMHD(:,k));
    end
    powerNormalizedMHD = zeros(max(maxStepsOverAllRays),maxangles);
    for k = 1 : maxangles
        for l = 1 : max(maxStepsOverAllRays)

            powerNormalizedMHD(l,k) = powerMHD(l,k)/max(powerMHD(1,:));
        end

        powerRayLastValueMHD(k) = powerMHD(nnz(powerMHD(:,k)),k);
        %itpo(2,:,:)=itpo(2,:,:)*(-1);
    end

    save('MEESST_MHD_SigChar_power.mat', '-v7.3');
end

fprintf('\n Visualization finished. Exiting now.\n\n',NAMESHORT);
fprintf('-----------------------------------------------------------------------------------------\n');