%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Signal characterization of extraordinary rays
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load case
 clear all
 close all
 
 %load('MEESST_0T_0kW_34GHz.mat');
 load('MEESST_MHD_RTSparamO.mat');

% Transmitted (accepted) power
TxAntennaPower = 0.001; % 0.6*0.01; % [W]
antennaEfficiency = 1;


% Tx boresight direction
dirmainTrans =180;


% Antenna gain
if f == 34E9
    antennaGain = 14.89740976; % [dBi]
elseif f == 37E9
    antennaGain = 15.393065; % [dBi]
elseif f == 40E9
    antennaGain = 13.56515449; % [dBi]
else
    antennaGain = 15; % [dBi]
end

% MEESST VSWR antenna
VSWR1 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 1.38,1.48,2.33,3.83,6.00,2.55,1.22,1.35];
VSWR2 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.82,2.03,2.67,3.3,3.36,1.77,2.47,8.39];
VSWR3 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.25,1.27,1.44,1.74,1.33,1.36,1.41,1.51];
VSWR4 = [33e9,34e9,35e9,36e9,37e9,38e9,39e9,40e9; 2.41,1.24,1.86,1.5,1.56,1.42,2.18,2.08];

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Required for test case

Cablelength1= 6.0;% 3.0; % [m]
Cablelength2= 5.0;% 3.5; % [m]
AdaptorLoss = 0.4; % [dB]
CableLoss = (0.37*(f/(10^9))^0.5)+(0.0071*(f/(10^9))); % [dB/m]; f in GHz
DCBlockLoss = 0.75; % [dB]
AdditionalLoss = 0; % [dB]
Windows = 0;% 2.258; % [dB]
%Ptx = 10; % [dBm]

%%%%%%%%%%%%%%%%%%%%%%%%%%%% End required for test case

Gamma_r = (recAntennasPosition(:,5)-1)./(recAntennasPosition(:,5)+1);
Gamma_t = (txAntenna_VSWR-1)./(txAntenna_VSWR+1);

% Losses of components

Ltx = AdaptorLoss + (CableLoss*Cablelength1) + DCBlockLoss + AdditionalLoss;
Lrx = AdaptorLoss + (CableLoss*Cablelength2) + DCBlockLoss + AdditionalLoss + Windows;
TxAntennaPowerdB = 10*log10(TxAntennaPower);
TxAntennaPowerLtx = 10^((TxAntennaPowerdB-Ltx)/10);
Com.Losses=Lrx;


for i = 1: length(VSWR1)
    if VSWR1(1,i) == f
        txAntenna_VSWR = VSWR1(2,i); % from antenna, mean value
    end
end

%Antenna coordinates, main angle and aperture of each receiving antenna
antenna2_Xpos = 0.5105;
antenna2_Ypos = 0.15;
antenna2_dirmain = 340.47;
antenna2_antennaApertureY = 0.025;
antenna2_antennaApertureZ = 0.025;
for i = 1: length(VSWR2)
    if VSWR2(1,i) == f
        antenna2_VSWR = VSWR2(2,i); % from antenna, mean value
    end
end

antenna3_Xpos = 0.5135;
antenna3_Ypos = 0.155;
antenna3_dirmain = 360-20.256;
antenna3_antennaApertureY = 0.025;
antenna3_antennaApertureZ = 0.025;
for i = 1: length(VSWR3)
    if VSWR3(1,i) == f
        antenna3_VSWR = VSWR3(2,i); % from antenna, mean value
    end
end

antenna4_Xpos = 0.5135;
antenna4_Ypos = 0.295;
antenna4_dirmain = 360-35.08;
antenna4_antennaApertureY = 0.025;
antenna4_antennaApertureZ = 0.025;
for i = 1: length(VSWR4)
    if VSWR4(1,i) == f
        antenna4_VSWR = VSWR4(2,i); % from antenna, mean value
    end
end

recAntennasPosition = [antenna2_Xpos,antenna2_Ypos,antenna2_dirmain,antenna2_antennaApertureY,antenna2_VSWR,antenna2_antennaApertureZ;antenna3_Xpos,antenna3_Ypos,antenna3_dirmain,antenna3_antennaApertureY,antenna3_VSWR,antenna3_antennaApertureZ;antenna4_Xpos,antenna4_Ypos,antenna4_dirmain,antenna4_antennaApertureY,antenna4_VSWR,antenna4_antennaApertureZ];


%% TX antenna pattern

% Load radiation pattern
if f == 34e9 || f == 33e9 || f == 35e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_34GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_34GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 37e9 || f == 36e9 || f == 38e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_37GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_37GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 40e9 || f == 39e9
  %  patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_40GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/Radome_40GHZ.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
end

% Power pattern [db W/m^2]

rawDataPlotIni = abs(patternCoPlanarHorizontal);

rawDataPlotIni90 = abs(patternCoPlanarVertical);


%% Convert from dB to real valuse, rotate to boresight, save values for later and plot radaiaion patterns

% Convert dB to real values
patternValuesIni = [rawDataPlotIni(:,1),rawDataPlotIni(:,2)]; % now in real values

patternValuesIni90 = [rawDataPlotIni90(:,1),rawDataPlotIni90(:,2)]; % now in real values

% Rotate to antenna radiation direction
[~,maxIntensityIndex] = max(patternValuesIni(:,1));
[~,maxIntensityIndex90] = max(patternValuesIni90(:,1));

IniPatternAntDir = patternValuesIni(maxIntensityIndex,2);
IniPatternAntDir90 = patternValuesIni90(maxIntensityIndex90,2);
ThetaToAdd=dirmainTrans-IniPatternAntDir;
ThetaToAdd90=dirmainTrans-IniPatternAntDir90;

% Make sure angles are between 0 and 360
itdirAnt=patternValuesIni(:,2)+ThetaToAdd;
for i = 1 : length(itdirAnt)
    if itdirAnt(i) > 360
        itdirAnt(i) = itdirAnt(i)-360;
    end
end

itdirAnt90=patternValuesIni90(:,2)+ThetaToAdd90;
for i = 1 : length(itdirAnt90)
    if itdirAnt90(i) > 360
        itdirAnt90(i) = itdirAnt90(i)-360;
    end
end

% Final pattern values of the Tx antenna, normalized (independend from
% distance
patternValues = [patternValuesIni(:,1),itdirAnt ];%/maxIntensity
patternValues90 = [patternValuesIni90(:,1),itdirAnt90 ];%/maxIntensity90

[~,ia,~] = unique(patternValues(:,1),'rows');
patternValues = patternValues(ia,:);
[~,ia,~] = unique(patternValues(:,2),'rows');
patternValues = patternValues(ia,:);
[~,ia,~] = unique(patternValues90(:,1),'rows');
patternValues90 = patternValues90(ia,:);
[~,ia,~] = unique(patternValues90(:,2),'rows');
patternValues90 = patternValues90(ia,:);
if min(patternValues(:,2)) > 0
    patternValues = [patternValues(1,1),0;patternValues];
end
if max(patternValues(:,2)) < 360
    patternValues = [patternValues;patternValues(end,1),360];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get rays who leave domain
xComponent = zeros(1,maxangles);
yComponent = zeros(1,maxangles);
counter=0;
for i = 1:maxangles
    reflectionCeck = find(reflectionPoint(:,i),1,'last');
    if isempty(reflectionCeck)
        reflectionCeck = 0;
    end
    if outside(i)==1 || reflectionCeck >2 
         counter=counter+1;
         Pop1 = itdir(:,i);

         xComponent(i)=itpo(1,find(Pop1,1,'last'),i);
         yComponent(i)=itpo(2,find(Pop1,1,'last'),i);

     end
 end 

%% Get electric field values ray positions


% Ray directions and angular distance between rays
itdirIni=itdir(1,:);

deltaTheta = (max(itdirIni)-min(itdirIni))/(maxangles);

% Intensity values of rays at phi = 0
intensityAtPos = interp1(patternValues(:,2),patternValues(:,1),itdirIni);

% Intensity values of rays at phi = 90
intensityAtPos90 = interp1(patternValues90(:,2),patternValues90(:,1),itdirIni);

%Export Tx antenna radiation pattern values for later
TxAntenna.Pattern.Values90 = patternValues90;
TxAntenna.Pattern.Values = patternValues;

%% Assign transmitting antenna values to new rays


itdirIniTx=itdir(1,:);

deltaThetaTx = (max(itdirIniTx)-min(itdirIniTx))/(maxangles);


intensityAtPosTx = interp1(TxAntenna.Pattern.Values(:,2),TxAntenna.Pattern.Values(:,1),itdirIniTx);


%% RX antenna pattern

% Load radiation pattern
if f == 34e9 || f == 33e9 || f == 35e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_34GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/AC_without_34GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 37e9 || f == 36e9 || f == 38e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_37GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/AC_without_37GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 40e9 || f == 39e9
  %  patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_40GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/AC_without_40GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
end

% Power pattern [db W/m^2]

rawDataPlotIni = abs(patternCoPlanarHorizontal);

rawDataPlotIni90 = patternCoPlanarVertical;


%% Convert from dB to real valuse, rotate to boresight, save values for later and plot radaiaion patterns

% Convert dB to real values
patternValuesIni = [rawDataPlotIni(:,1),rawDataPlotIni(:,2)]; % now in real values

patternValuesIni90 = [rawDataPlotIni90(:,1),rawDataPlotIni90(:,2)]; % now in real values

% Rotate to antenna radiation direction
[~,maxIntensityIndex] = max(patternValuesIni(:,1));
[~,maxIntensityIndex90] = max(patternValuesIni90(:,1));

IniPatternAntDir = patternValuesIni(maxIntensityIndex,2);
IniPatternAntDir90 = patternValuesIni90(maxIntensityIndex90,2);
ThetaToAdd=dirmainTrans-IniPatternAntDir;
ThetaToAdd90=dirmainTrans-IniPatternAntDir90;

% Make sure angles are between 0 and 360
itdirAnt=patternValuesIni(:,2)+ThetaToAdd;
for i = 1 : length(itdirAnt)
    if itdirAnt(i) > 360
        itdirAnt(i) = itdirAnt(i)-360;
    end
end

itdirAnt90=patternValuesIni90(:,2)+ThetaToAdd90;
for i = 1 : length(itdirAnt90)
    if itdirAnt90(i) > 360
        itdirAnt90(i) = itdirAnt90(i)-360;
    end
end

% Final pattern values of the Tx antenna, normalized (independend from
% distance
patternValues = [patternValuesIni(:,1),itdirAnt ];%/maxIntensity
patternValues90 = [patternValuesIni90(:,1),itdirAnt90 ];%/maxIntensity90

[~,ia,~] = unique(patternValues(:,1),'rows');
patternValues = patternValues(ia,:);
[~,ia,~] = unique(patternValues(:,2),'rows');
patternValues = patternValues(ia,:);
[~,ia,~] = unique(patternValues90(:,1),'rows');
patternValues90 = patternValues90(ia,:);
[~,ia,~] = unique(patternValues90(:,2),'rows');
patternValues90 = patternValues90(ia,:);
if min(patternValues(:,2)) > 0
    patternValues = [patternValues(1,1),0;patternValues];
end
if max(patternValues(:,2)) < 360
    patternValues = [patternValues;patternValues(end,1),360];
end

if min(patternValues90(:,2)) > 0
    patternValues90 = [patternValues90(1,1),0;patternValues90];
end
if max(patternValues90(:,2)) < 360
    patternValues90 = [patternValues90;patternValues90(end,1),360];
end

%Export Tx antenna radiation pattern values for later
RxAntenna.Pattern.Values90 = patternValues90;
RxAntenna.Pattern.Values = patternValues;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% End loading antenna radiation patterns
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Signal caracterization

reflectionPoints = zeros(maxsteps,maxangles);
for k = 1 : maxangles
    reflectionPos = 0;
    for ii = 1:length(find(reflectionPoint(:,k)~=0))
        reflectionPos = reflectionPos+ reflectionPoint(ii,k);
        reflectionPoints(reflectionPos,k) = 1;
    end
end
domain.reflectionPoints = reflectionPoints;

itdirIniTx=itdir(1,:);
        
deltaThetaTx = (max(itdirIniTx)-min(itdirIniTx))/(maxangles);

% Arc length
arcLength = zeros(maxsteps,maxangles);
for k = 1: maxangles
    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);

    arcLength(1,k) = norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]);

    for l = 2 : lastNonZero
        arcLength(l,k) = norm([itpo(1,l,k),itpo(2,l,k),0]-[itpo(1,l-1,k),itpo(2,l-1,k),0]);
    end
end

% Ray distance/area
rayDistance = zeros(maxsteps,maxangles);
rayArea = zeros(maxsteps,maxangles);
rayDistanceEnd = zeros(1,maxangles);
for k = 1: maxangles-1
    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
    lastNonZeroPlus = find(itdir(:,k+1),1,'last');
    if sind(deltaThetaTx/2) < 0.0001
        rayDistance(1,k) = 2*(norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]));%*sind(deltaThetaTx/2);
        rayArea(1,k) = rayDistance(1,k)^2;
    else
    rayDistance(1,k) = 2*(norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]))*sind(deltaThetaTx/2);
    rayArea(1,k) = rayDistance(1,k)^2;
    end
    for l = 2 : lastNonZero
        if sind(abs(itdir(l,k)-itdir(l,k+1))) < 0.0001
            rayDistance(l,k) = rayDistance(l-1,k);
            rayArea(l,k) = rayDistance(l,k)^2;
        else
            rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(l,k+1)))*sum(arcLength(1:l,k));
            rayArea(l,k) = rayDistance(l,k)^2;
            if lastNonZero > lastNonZeroPlus
                rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(lastNonZeroPlus,k+1)))*sum(arcLength(1:l,k));
                rayArea(l,k) = rayDistance(l,k)^2;
            end
        end
    end
    rayDistanceEnd(1,k) = abs(rayDistance(lastNonZero,k));
end
rayArea(1,maxangles) = rayDistance(1,maxangles-1)^2;


for k = maxangles
    lastNonZero = find(itdir(:,k),1,'last');
    lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
    lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
    lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
    lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
    lastNonZeroPlus = find(itdir(:,k-1),1,'last');
    if sind(deltaThetaTx/2) < 0.0001
        rayDistance(1,k) = 2*(norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]));%*sind(deltaThetaTx/2);
        rayArea(1,k) = rayDistance(1,k)^2;
    else
        rayDistance(1,k) = 2*(norm([itpo(1,2,k),itpo(2,2,k),0]-[itpo(1,1,k),itpo(2,1,k),0]))*sind(deltaThetaTx/2);
        rayArea(1,k) = rayDistance(1,k)^2;
    end
    for l = 2 : lastNonZero
        if sind(abs(itdir(l,k)-itdir(l,k-1))) < 0.0001
            rayDistance(l,k) = rayDistance(l-1,k);
            rayArea(l,k) = rayDistance(l,k)^2;
        else
            rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(l,k-1)))*sum(arcLength(1:l,k));
            rayArea(l,k) = rayDistance(l,k)^2;
            if lastNonZero > lastNonZeroPlus
                rayDistance(l,k) = sind(abs(itdir(l,k)-itdir(lastNonZeroPlus,k-1)))*sum(arcLength(1:l,k));
                rayArea(l,k) = rayDistance(l,k)^2;
            end
        end
    end
    rayDistanceEnd(1,k) = abs(rayDistance(lastNonZero,k));
end


% Faraday rotation: total electron count and average B-field
% values

for zonesNumbers = 1 : domain.nozones
    if MagneticField==1 % Check if this works
        Bfield = [domain.(strcat('zone',num2str(zonesNumbers))).variables(3,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(4,:)',domain.(strcat('zone',num2str(zonesNumbers))).variables(5,:)'];
        B_vec_mag=zeros(domain.nozones,length(Bfield));
    
        for i=1:length(Bfield)
            B_vec_mag(zonesNumbers,i)= sqrt(Bfield(i,1)^2 +Bfield(i,2)^2 +Bfield(i,3)^2)+(50*10^(-6));
        end
    elseif MagneticField==0
        for i=1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables)
            B_vec_mag(zonesNumbers,i)= (50*10^(-6));
        end
    end
    
    domain.(strcat('zone',num2str(zonesNumbers))).variables(end+1,:)=B_vec_mag(zonesNumbers,1:length(domain.(strcat('zone',num2str(zonesNumbers))).variables));

end
B_average1 = zeros(maxsteps,maxangles);
N_average1 = zeros(maxsteps,maxangles);
totalElectronCount1 = zeros(maxsteps,maxangles);
if MagneticField==0
    parfor k = 1: maxangles  % parfor
        B_average1For = zeros(maxsteps,1);
        N_average1For = zeros(maxsteps,1);
        totalElectronCount1For = zeros(maxsteps,1);
        lastNonZero = find(itdir(:,k),1,'last');
        lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        for l = 1: lastNonZero
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova+1))
                B_average1For(l,1) = 0;
            else
                B_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova+3);
            end
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova-5))
                N_average1For(l,1) = 0;
            else
                N_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova-5);
            end
           
            totalElectronCount1For(l,1) = N_average1For(l,1) * arcLength(l,k);
        end
        B_average1(:,k) = B_average1For(:,1);
        N_average1(:,k) = N_average1For(:,1);
        totalElectronCount1(:,k) = totalElectronCount1For(:,1);
    end
elseif MagneticField==1
    parfor k = 1: maxangles % parfor
        B_average1For = zeros(maxsteps,1);
        N_average1For = zeros(maxsteps,1);
        totalElectronCount1For = zeros(maxsteps,1);
        lastNonZero = find(itdir(:,k),1,'last');
        lastNonZeroPo1 = find(itpo(1,:,k),1,'last');
        lastNonZeroPo2 = find(itpo(2,:,k),1,'last');
        lastNonZeroPo4 = find(itpo(4,:,k),1,'last');
        lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
        for l = 1: lastNonZero
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova+1))
                B_average1For(l,1) = 0;
            else
                B_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova+15);
            end
            if isempty(interpolation(domain,itpo(:,l,k)',domain.nova-5))
                N_average1For(l,1) = 0;
            else
                N_average1For(l,1) = interpolation(domain,itpo(:,l,k)',domain.nova-5);
            end
           
            totalElectronCount1For(l,1) = N_average1For(l,1) * arcLength(l,k);
        end
        B_average1(:,k) = B_average1For(:,1);
        N_average1(:,k) = N_average1For(:,1);
        totalElectronCount1(:,k) = totalElectronCount1For(:,1);
    end
end

S_x1=zeros(1,length(recAntennasPosition(:,1)));
S_x1_5=zeros(1,length(recAntennasPosition(:,1)));
S_x2=zeros(1,length(recAntennasPosition(:,1)));
S_x3=zeros(1,length(recAntennasPosition(:,1)));
S_x4=zeros(1,length(recAntennasPosition(:,1)));
for numA = 1:length(recAntennasPosition(:,1))

    
    alphaRxAntRange(1,1) = atan2d(norm(cross(recAntRightOrigin(numA,:),[1;0;0])),dot(recAntRightOrigin(numA,:),[1;0;0]));
    if recAntRightOrigin(numA,2) < 0
        alphaRxAntRange(1,1) = 360 - alphaRxAntRange(1,1);
    end
    alphaRxAntRange(1,2) = mod(atan2d(norm(cross(recAntLeftOrigin(numA,:),[1;0;0])),dot(recAntLeftOrigin(numA,:),[1;0;0])),360);
    if recAntLeftOrigin(numA,2) < 0
        alphaRxAntRange(1,2) = 360 - alphaRxAntRange(1,2);
    end
   

    raysReachingRx = zeros(length(recAntennasPosition(:,1)),1);
    counting = 1;
    for k = 1 : maxangles
        rayRx = find(itdir(:,k),1,'last');
        for l = 1: rayRx
            if itpo(1,l,k)<=max([antPosX1(numA,1),antPosX2(numA,1)]) && itpo(2,l,k)>=min([antPosY1(numA,1),antPosY2(numA,1)]) && itpo(2,l,k)<=max([antPosY1(numA,1),antPosY2(numA,1)]) %itpo(1,l,k)>=min([0.6*antPosX1(numA,1),0.6*antPosX2(numA,1)]) && itpo(1,l,k)<=max([1.4*antPosX1(numA,1),1.4*antPosX2(numA,1)]) && itpo(2,l,k)>=min([0.9*antPosY1(numA,1),0.9*antPosY2(numA,1)]) && itpo(2,l,k)<=max([1.1*antPosY1(numA,1),1.1*antPosY2(numA,1)])
                if itpo(1,l,k)>=min([antPosX1(numA,1),antPosX2(numA,1)])
                    raysReachingRx(numA,counting) = k; 
                    counting = counting+1;
                end                
            end
        end
    end
    if ( (raysReachingRx(numA,1)) == 0 && recAntennasPosition(numA,3) ==270) || ((raysReachingRx(numA,1)) == 0  && recAntennasPosition(numA,3) ==90)
        counting = 1;
        for k = 1 : maxangles
            rayRx = find(itdir(:,k),1,'last');
            if itpo(1,rayRx,k)>=min([antPosX1(numA,1),antPosX2(numA,1)]) && itpo(1,rayRx,k)<=max([antPosX1(numA,1),antPosX2(numA,1)])% && itpo(2,rayRx,k)>=min([antPosY1,antPosY2]) && itpo(2,rayRx,k)<=max([antPosY1,antPosY2])
                raysReachingRx(numA,counting) = k; 
                counting = counting+1;
            end
        end
    end
    if ((raysReachingRx(numA,1)) == 0 && recAntennasPosition(numA,3) ==180) || ((raysReachingRx(numA,1)) == 0  && recAntennasPosition(numA,3) ==0)|| ((raysReachingRx(numA,1)) == 0  && recAntennasPosition(numA,3) ==360)
        counting = 1;
        for k = 1 : maxangles
            rayRx = find(itdir(:,k),1,'last');
            if itpo(2,rayRx,k)>=min([antPosY1(numA,1),antPosY2(numA,1)]) && itpo(2,rayRx,k)<=max([antPosY1(numA,1),antPosY2(numA,1)])
                raysReachingRx(numA,counting) = k; 
                counting = counting+1;
            end
        end
    end
    
%     if (raysReachingRx(numA,1)) == 0
%         for ib = 1: numel(raysReachingRx(:,1))
%             for ia = 2:numel(raysReachingRx(1,:))
%                 if raysReachingRx1(ib,ia) == 0
%                     raysReachingRx1(ib,ia) = raysReachingRx1(ib,ia-1);
%                 end
%             end 
%         end
%         raysReachingRx = zeros(length(recAntennasPosition(:,1)),length(raysReachingRx1(1,:)));
%         raysReachingRx(numA,:) = raysReachingRx1(numA,:);
% 
%     end
    helper = unique(raysReachingRx(numA,:));
    helper = nonzeros(helper);

    if sum(helper) < 1

        S_x1(1,numA) = 0;
        S_x2(1,numA) = 0;
        S_x3(1,numA) = 0;
        S_x5(1,numA) = 0;

        fprintf('\n No rays reach Antenna.\n\n',numA);
    else

        xComponentReach = zeros(1,length(helper));
        yComponentReach = zeros(1,length(helper));
        
        for i = 1 : length(helper)
            index = helper(i);
            xComponentReach(i) = xComponent(index);
            yComponentReach(i) = yComponent(index);
        end
        %% Find intensity values at rx antenna
    
        ThetaEnd=zeros(1,maxangles);
        for i = 1:maxangles
        
            Pop1 = itdir(:,i);
            ThetaEnd(1,i) = Pop1(find(Pop1,1,'last'));
            if isnan(ThetaEnd(1,i))
                ThetaEnd(1,i) = Pop1(find(Pop1,1,'last')-1);
            end      
    
            if ThetaEnd(1,i) <0
                ThetaEnd(1,i)=ThetaEnd(1,i)+360;
            end
        end
    
        itdirRx = zeros(1,length(helper));
        for pwr_i=1:length(helper)
            indx = helper(pwr_i);
            itdirRx(pwr_i) = real(ThetaEnd(1,indx))+180;
    
            if itdirRx(pwr_i) > 360
            itdirRx(pwr_i)=itdirRx(pwr_i)-360;
            end
        end
        [~,idx] = sort(itdirRx);
        itdirRxSort = itdirRx(idx);
       
    
        intensityAtPosRxDensRef = interp1(real(patternValuesRx(:,2)),(patternValuesRx(:,1)),itdirRxSort);
    
        %% Calculate transmitted/received power
    
        TravelDist = zeros(1,length(helper));
        yMinus = zeros(1,length(helper));
        yPlus = zeros(1,length(helper));
        xMinus = zeros(1,length(helper));
        xPlus = zeros(1,length(helper));
        zMinus = zeros(1,length(helper));
        zPlus = zeros(1,length(helper));
        deltaAntR = zeros(1,length(helper));
        deltaZ = zeros(1,length(helper));
        Prad_r = zeros(1,length(helper));
        Prad_r2 = zeros(1,length(helper));
        Prad_r5 = zeros(1,length(helper));
        A_hitRay = zeros(1,length(helper));
        A_Ray = zeros(1,length(helper));
        deltaTravelDist = zeros(1,length(helper));
    
    
        % Transmitted power 
        polarizationEvolutionTotal = zeros(1,length(helper));
        powerTransmittedBORAT8End = zeros(1,length(helper));
        power = zeros(maxsteps,length(helper));
        refractiveIndexEnd = zeros(1,length(helper));
    
        for k = 1:length(helper)
            indx = unique(raysReachingRx(numA,k));
            TravelDist(1,k) = sum(arcLength(:,indx));
        end
        for k = 1:length(helper)
        deltaTravelDist(1,k) = max(TravelDist(1,:))-TravelDist(1,k);
        end
        
        parfor k = 1:length(helper) % parfor
            indx = unique(raysReachingRx(numA,k));
    
            powerTransmittedBORATS = zeros(maxsteps,maxangles);
            powerTransmittedBORATP = zeros(maxsteps,maxangles);
            powerTransmittedBORAT8 = zeros(maxsteps,maxangles);
            polVector = zeros(2,maxsteps,maxangles);
            polVectorGlobal = zeros(3,maxsteps,maxangles);
            FarRot = zeros(maxsteps,maxangles);
            reflectionLossS = zeros(maxsteps,maxangles);
            reflectionLossP = zeros(maxsteps,maxangles);
            absorption = zeros(maxsteps,maxangles);
            phaseShift = zeros(maxsteps,maxangles);
            spreadFactor = zeros(maxsteps,maxangles);
            deltaRay = zeros(maxsteps,maxangles);
            
            itpos = itpo;
            domains=domain;
            
            lastNonZero = find(itdir(:,indx),1,'last');
            lastNonZeroPo1 = find(itpos(1,:,indx),1,'last');
            lastNonZeroPo2 = find(itpos(2,:,indx),1,'last');
            lastNonZeroPo4 = find(itpos(4,:,indx),1,'last');
            lastNonZero = min([lastNonZero,lastNonZeroPo1,lastNonZeroPo2,lastNonZeroPo4]);
            
            polVector(1:2,1,indx) = [sqrt(cosd(itdir(1,indx)+90)^2 + sind(itdir(1,indx)+90)^2),0];
            polVector(:,1,indx) = 1/norm(polVector(:,1,indx)) * polVector(:,1,indx);
            polVectorGlobal(1:3,1,indx) = [cosd(itdir(1,indx)+90), sind(itdir(1,indx)+90), 0];
            polVectorGlobal(:,1,indx) = 1/norm(polVectorGlobal(:,1,indx)) * polVectorGlobal(:,1,indx);
            
            powerTransmittedBORAT8(1,indx) = TxAntennaPower;% * (abs(dir1-dir2)/maxangles/360);
            powerTransmittedBORATS(1,indx) = powerTransmittedBORAT8(1,indx) * polVector(2,1,indx);
            powerTransmittedBORATP(1,indx) = powerTransmittedBORAT8(1,indx) * polVector(1,1,indx);
            powerTransmittedBORAT8(1,indx) = sqrt(powerTransmittedBORATP(1,indx)^2 + powerTransmittedBORATS(1,indx)^2);
            
            for l = 2 : lastNonZero
            
                if domains.reflectionPoints(l,indx) == 0
            
                    FarRot(l,indx) = (2.36*10^(4)/(f^2))*totalElectronCount1(l,indx)*(B_average1(l,indx));
                    angleOutOfPlane = atan2(real(polVector(1,l-1,indx)),real(polVector(2,l-1,indx)))+FarRot(l,indx);
                    polVector(2,l,indx) = sin(angleOutOfPlane);
                    polVector(1,l,indx) = cos(angleOutOfPlane);
                    polVector(:,l,indx) = 1/norm(polVector(:,l,indx)) * polVector(:,l,indx);
            
            
                    surfaceangle=isolinefindingSignal(domains,itpo(:,l,k),arcLength(l,k),MagneticField);
                    if surfaceangle < itdir(l-1,k)
                        reflectionAngle =  surfaceangle + 270 - (180+round(abs(itdir(l-1,indx))));
                    else
                        reflectionAngle =  (180+round(abs(itdir(l-1,indx)))) - (surfaceangle + 90);
                    end
                    %if itdir(l-1,indx) < itdir(l,indx)
                    %    reflectionAngle = round(abs((itdir(l-1,indx) + 180 - itdir(l,indx)) / 2),1);
                    %elseif itdir(l-1,indx) >= itdir(l,indx)
                    %    reflectionAngle = round(abs((itdir(l-1,indx) - 180 - itdir(l,indx))) / 2,1);
                    %end
            
                    reflectionCoeffS = ( (round(itpos(4,l-1,indx),4) * cosd(reflectionAngle) ) - ( sqrt( ( round(itpos(4,l,indx),4)^2 ) - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) ) / ( (round(itpos(4,l-1,indx),4) * cosd(reflectionAngle) ) + ( sqrt( ( round(itpos(4,l,indx),4)^2 ) - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) );
                    reflectionCoeffP = ( ( round(itpos(4,l-1,indx),4) * sqrt( round(itpos(4,l,indx),4)^2 - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) - round(itpos(4,l,indx),4)^2  * cosd(reflectionAngle) ) / ( ( round(itpos(4,l-1,indx),4) * sqrt( round(itpos(4,l,indx),4)^2 - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) + round(itpos(4,l,indx),4)^2  * cosd(reflectionAngle) );
            
                    if isnan(reflectionCoeffS)
                    reflectionCoeffS = 0;
                    end
                    if isnan(reflectionCoeffP)
                        reflectionCoeffP = 0;
                    end
            
                    reflectionLossS(l,indx) = (1 - abs(reflectionCoeffS)^2);
                    reflectionLossP(l,indx) = (1 - abs(reflectionCoeffP)^2);
            
                    if round(abs(reflectionCoeffP)) >= 1 || isinf(reflectionLossP(l,indx))
                        reflectionLossP(l,indx) =1;
                    end
                    if round(abs(reflectionCoeffS)) >= 1 || isinf(reflectionLossS(l,indx))
                        reflectionLossS(l,indx) =1;
                    end
                    absorption(l,indx) = exp(-abs((2*pi*f/physconst('LightSpeed'))*itpos(5,l,indx))*arcLength(l,indx));
                    deltaRay(l,indx) = norm([itpos(1,l,indx),itpos(2,l,indx),0]-[itpos(1,l-1,indx),itpos(2,l-1,indx),0]);
                    phaseShift(l,indx) = exp(-1i*(2*pi*f*(itpos(4,l,indx)-1)*deltaRay(l,indx)/physconst('LightSpeed')));
                    spreadFactor(l,indx) = sqrt((2*sqrt((1.25663706212*10^(-6))/(itpos(4,l,indx)^2*(8.8541878128*10^(-12)))))/(2*sqrt((1.25663706212*10^(-6))/(itpos(4,l-1,indx)^2*(8.8541878128*10^(-12))))) * (rayArea(l-1,indx)./rayArea(l,indx)));
            
                    powerTransmittedBORAT8(l,indx) = abs(powerTransmittedBORAT8(l-1,indx) * absorption(l,indx) * spreadFactor(l,indx) * phaseShift(l,indx));
            
                    powerTransmittedBORATS(l,indx) = powerTransmittedBORAT8(l,indx) * polVector(2,l,indx) * reflectionLossS(l,indx);
                    powerTransmittedBORATP(l,indx) = powerTransmittedBORAT8(l,indx) * polVector(1,l,indx) * reflectionLossP(l,indx);
            
                    powerTransmittedBORAT8(l,indx) = sqrt(powerTransmittedBORATP(l,indx)^2 + powerTransmittedBORATS(l,indx)^2);
            
                    if powerTransmittedBORAT8(l,indx) == 0 || isnan(powerTransmittedBORAT8(l,indx))
                        hi=1;
                    end
            
                    polVector(:,l,indx) = [powerTransmittedBORATP(l,indx),powerTransmittedBORATS(l,indx)];
                    polVector(:,l,indx) = 1/norm(polVector(:,l,indx)) * polVector(:,l,indx);
            
                    polVectorGlobal(1,l,indx) = powerTransmittedBORATP(l,indx) * cosd(itdir(l,indx)+90);
                    polVectorGlobal(2,l,indx) = powerTransmittedBORATP(l,indx) * sind(itdir(l,indx)+90);
                    polVectorGlobal(3,l,indx) = powerTransmittedBORATS(l,indx);
                    polVectorGlobal(:,l,indx) = 1/norm(polVectorGlobal(:,l,indx)) * polVectorGlobal(:,l,indx);
            
                elseif domains.reflectionPoints(l,indx) ~= 0
                    surfaceangle=isolinefindingSignal(domains,itpo(:,l,k),arcLength(l,k),MagneticField);
                    if surfaceangle < itdir(l-1,k)
                        reflectionAngle =  surfaceangle + 270 - (180+round(abs(itdir(l-1,indx))));
                    else
                        reflectionAngle =  (180+round(abs(itdir(l-1,indx)))) - (surfaceangle + 90);
                    end
            
                    if itpos(4,l,indx) > itpos(4,l-1,indx)
            
                        if reflectionAngle < atand(real(itpos(4,l,indx)/itpos(4,l-1,indx)))
                            phaseShiftReflP1 = 1;
                            phaseShiftReflS1 = exp(1i*pi());
            
                        elseif reflectionAngle > atand(real(itpos(4,l,indx)/itpos(4,l-1,indx)))
            
                            phaseShiftReflP1 = exp(1i*pi());
                            phaseShiftReflS1 = exp(1i*pi());
            
                        end
            
                    else
            
                        if reflectionAngle < atand(real(itpos(4,l,indx)/itpos(4,l-1,indx)))
            
                            phaseShiftReflP1 = exp(1i*pi());
                            phaseShiftReflS1 = 1;
            
                        elseif atand(real(itpos(4,l,indx)/itpos(4,l-1,indx))) < reflectionAngle && reflectionAngle < asind(real(itpos(4,l,indx)/itpos(4,l-1,indx)))
            
                            phaseShiftReflP1 = 1;
                            phaseShiftReflS1 = 1;
            
            
                        elseif reflectionAngle > asind(real(itpos(4,l,indx)/itpos(4,l-1,indx)))
            
                            phaseShiftReflP1 = exp(1i*2*(atan(itpos(4,l-1,indx)^2/(itpos(4,l,indx)^2*cosd(reflectionAngle)))*sqrt((sind(reflectionAngle))^2 - (itpos(4,l,indx)/itpos(4,l-1,indx)^2))));
                            phaseShiftReflS1 = exp(1i*2*(atan(1/(cosd(reflectionAngle)))*sqrt((sind(reflectionAngle))^2 - (itpos(4,l,indx)/itpos(4,l-1,indx)^2)))) ;
            
                        end
                    end
            
            
                    FarRot(l,indx) = (2.36*10^(4)/(f^2))*totalElectronCount1(l,indx)*(B_average1(l,indx));
                    angleOutOfPlane = atan2(real(polVector(1,l-1,indx)),real(polVector(2,l-1,indx)))+FarRot(l,indx);
                    polVector(2,l,indx) = sin(angleOutOfPlane);
                    polVector(1,l,indx) = cos(angleOutOfPlane);
                    polVector(:,l,indx) = 1/norm(polVector(:,l,indx)) * polVector(:,l,indx);
            
            
                    if itdir(l-1,indx) < itdir(l,indx)
                        reflectionAngle = round(abs((itdir(l-1,indx) + 180 - itdir(l,indx)) / 2),1);
                    elseif itdir(l-1,indx) >= itdir(l,indx)
                        reflectionAngle = round(abs((itdir(l-1,indx) - 180 - itdir(l,indx))) / 2,1);
                    end
            
                    reflectionCoeffS = ( (round(itpos(4,l-1,indx),4) * cosd(reflectionAngle) ) - ( sqrt( ( round(itpos(4,l,indx),4)^2 ) - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) ) / ( (round(itpos(4,l-1,indx),4) * cosd(reflectionAngle) ) + ( sqrt( ( round(itpos(4,l,indx),4)^2 ) - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) );
                    reflectionCoeffP = ( ( round(itpos(4,l-1,indx),4) * sqrt( round(itpos(4,l,indx),4)^2 - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) - round(itpos(4,l,indx),4)^2  * cosd(reflectionAngle) ) / ( ( round(itpos(4,l-1,indx),4) * sqrt( round(itpos(4,l,indx),4)^2 - ( round(itpos(4,l-1,indx),4)^2 * sind(reflectionAngle)^2 ) ) ) + round(itpos(4,l,indx),4)^2  * cosd(reflectionAngle) );
                    
                    if isnan(reflectionCoeffS)
                        reflectionCoeffS = 0;
                    end
                    if isnan(reflectionCoeffP)
                        reflectionCoeffP = 0;
                    end
            
                    reflectionLossS(l,indx) = (1);
                    reflectionLossP(l,indx) = (1);
                    
                    absorption(l,indx) = exp(-abs((2*pi*f/physconst('LightSpeed'))*itpos(5,l,indx))*arcLength(l,indx));
                    deltaRay(l,indx) = norm([itpos(1,l,indx),itpos(2,l,indx),0]-[itpos(1,l-1,indx),itpos(2,l-1,indx),0]);
                    phaseShift(l,indx) = exp(-1i*(2*pi*f*(itpos(4,l,indx)-1)*deltaRay(l,indx)/physconst('LightSpeed')));
                    spreadFactor(l,indx) = sqrt((2*sqrt((1.25663706212*10^(-6))/(itpos(4,l,indx)^2*(8.8541878128*10^(-12)))))/(2*sqrt((1.25663706212*10^(-6))/(itpos(4,l-1,indx)^2*(8.8541878128*10^(-12))))) * (rayArea(l-1,indx)./rayArea(l,indx)));
            
                    powerTransmittedBORAT8(l,indx) = abs(powerTransmittedBORAT8(l-1,indx) * absorption(l,indx) * spreadFactor(l,indx) * phaseShift(l,indx)); % losses from Point n-1 to Point n
            
                    powerTransmittedBORATS(l,indx) = powerTransmittedBORAT8(l,indx) * polVector(2,l,indx) * reflectionLossS(l,indx) * phaseShiftReflS1; % losses at Point n perpendicular
                    powerTransmittedBORATP(l,indx) = powerTransmittedBORAT8(l,indx) * polVector(1,l,indx) * reflectionLossP(l,indx) * phaseShiftReflP1; % losses at Point n parallel
            
                    powerTransmittedBORAT8(l,indx) = sqrt(powerTransmittedBORATP(l,indx)^2 + powerTransmittedBORATS(l,indx)^2); % total power after all losses at point n
            
                    if powerTransmittedBORAT8(l,indx) == 0 || isnan(powerTransmittedBORAT8(l,indx))
                        hi=1;
                    end
            
                    polVector(:,l,indx) = [powerTransmittedBORATP(l,indx),powerTransmittedBORATS(l,indx)]; % polarization vector local on ray in perpendicular (2) and parallel direction(1)
                    polVector(:,l,indx) = 1/norm(polVector(:,l,indx)) * polVector(:,l,indx);
            
                    polVectorGlobal(1,l,indx) = powerTransmittedBORATP(l,indx) * cosd(itdir(l,indx)+90); % polarization vector gobal
                    polVectorGlobal(2,l,indx) = powerTransmittedBORATP(l,indx) * sind(itdir(l,indx)+90);
                    polVectorGlobal(3,l,indx) = powerTransmittedBORATS(l,indx);
                    polVectorGlobal(:,l,indx) = 1/norm(polVectorGlobal(:,l,indx)) * polVectorGlobal(:,l,indx);
            
            
            
            
            
                end
            
            end
            powerTransmittedBORAT8End(1,k) = powerTransmittedBORAT8(l,indx);
            power(:,k) = powerTransmittedBORAT8(:,indx);
            refractiveIndexEnd(1,k) = itpos(4,l,indx);
            polarizationEvolutionTotal(1,k) = atan2d(real(polVector(1,l,indx)),real(polVector(2,l,indx)))-atan2d(real(polVector(1,1,indx)),real(polVector(2,1,indx)));
    %     end
    %     
    %     for pwr_i=1:length(helper)
    %         indx = unique(raysReachingRx(numA,pwr_i));
            
            deltaR = abs(rayDistanceEnd(1,indx))/2;%sum(arcLength(:,indx))*tand(deltaThetaTx/2);
            deltaX = deltaR *cosd(ThetaEnd(1,indx)-90);
            deltaY = deltaR *sind(ThetaEnd(1,indx)-90);
    
            
    
            yMinus(k) = yComponentReach(k) - deltaY;
            yPlus(k) = yComponentReach(k) + deltaY;
            xMinus(k) = xComponentReach(k) - deltaX;
            xPlus(k) = xComponentReach(k) + deltaX;
            zMinus(k) = 0 - deltaR;
            zPlus(k) = 0 + deltaR;
    
            if recAntennasPosition(numA,3) == 180 || recAntennasPosition(numA,3) == 360
                if yMinus(k) < min ([antPosY1(numA,1),antPosY2(numA,1)])
                    yMinus(k) = min([antPosY1(numA,1),antPosY2(numA,1)]);
                end
                if yPlus(k) > max ([antPosY1(numA,1),antPosY2(numA,1)])
                    yPlus(k) = max([antPosY1(numA,1),antPosY2(numA,1)]);
                end
                deltaAntR(k) = max([yPlus(k),yMinus(k)])-min([yPlus(k),yMinus(k)]);
    
                if zMinus(k) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(k) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(k) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(k) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(k) = max([zPlus(k),zMinus(k)])-min([zPlus(k),zMinus(k)]);
            elseif recAntennasPosition(numA,3) == 90 || recAntennasPosition(numA,3) == 270
                if xMinus(k) < min ([antPosX1(numA,1),antPosX2(numA,1)])
                    xMinus(k) = min([antPosX1(numA,1),antPosX2(numA,1)]);
                end
                if xPlus(k) > max ([antPosX1(numA,1),antPosX2(numA,1)])
                    xPlus(k) = max([antPosX1(numA,1),antPosX2(numA,1)]);
                end
                deltaAntR(k) = max([xPlus(k),xMinus(k)])-min([xPlus(k),xMinus(k)]);
    
                if zMinus(k) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(k) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(k) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(k) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(k) = max([zPlus(k),zMinus(k)])-min([zPlus(k),zMinus(k)]);
            else
                if xPlus(k) > max ([antPosX1(numA,1),antPosX2(numA,1)]) 
                    xPlus(k) = max([antPosX1(numA,1),antPosX2(numA,1)]);
                   
                end
                if  yPlus(k) > max ([antPosY1(numA,1),antPosY2(numA,1)])
                    
                    yPlus(k) = max([antPosY1(numA,1),antPosY2(numA,1)]);
                end
                if yMinus(k) < min ([antPosY1(numA,1),antPosY2(numA,1)]) 
                    
                    yMinus(k) = min([antPosY1(numA,1),antPosY2(numA,1)]);
                end
                if xMinus(k) < min ([antPosX1(numA,1),antPosX2(numA,1)])
                    xMinus(k) = min([antPosX1(numA,1),antPosX2(numA,1)]);
                 
                end
                deltaAntR(k) = sqrt(yPlus(k)^2 + xPlus(k)^2) - sqrt(yMinus(k)^2 + xMinus(k)^2);
    
                if zMinus(k) < min ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zMinus(k) = min([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                if zPlus(k) > max ([-sqrt(A_wirk),sqrt(A_wirk)])
                    zPlus(k) = max([-sqrt(A_wirk),sqrt(A_wirk)]);
                end
                deltaZ(k) = max([zPlus(k),zMinus(k)])-min([zPlus(k),zMinus(k)]);
            end
    
            A_hitRay(k) = abs(deltaAntR(k));% * abs(deltaZ(k));
            A_Ray(k) = abs(rayDistanceEnd(1,indx));
            
            
    
    
            %% Friis with electric field
            
            Prad_r(k) =  powerTransmittedBORAT8End(1,k) * intensityAtPosTx(indx).^2*length(TxAntenna.Pattern.Values(:,1))./sum(TxAntenna.Pattern.Values(:,1).^2) * ((1-abs(Gamma_t)^2) * (1-abs(Gamma_r(numA))^2)) * intensityAtPosRxDensRef(k)^2 * length(patternValuesRx(:,1))./sum(patternValuesRx(:,1).^2)* antennaEfficiency^2 * (cosd(polarizationEvolutionTotal(1,k)))^2*cos((abs(deltaTravelDist(k))/wavelenght)*2*pi());% * (A_hitRay(k)/A_Ray(k));%* cos(sum(FarRot(:,indx)))^2* (wavelenght^2/(4* pi())) * antennaEfficiency
            
            Prad_r2(k) =  powerTransmittedBORAT8End(1,k) *360*maxangles/abs(dir1-dir2) * intensityAtPosTx(indx).^2*length(TxAntenna.Pattern.Values(:,1))./sum(TxAntenna.Pattern.Values(:,1).^2) * ((1-abs(Gamma_t)^2) * (1-abs(Gamma_r(numA))^2)) * intensityAtPosRxDensRef(k)^2 * length(patternValuesRx(:,1))./sum(patternValuesRx(:,1).^2)* antennaEfficiency^2 * (cosd(polarizationEvolutionTotal(1,k)))^2*cos((abs(deltaTravelDist(k))/wavelenght)*2*pi());% * (A_hitRay(k)/A_Ray(k));%* cos(sum(FarRot(:,indx)))^2* (wavelenght^2/(4* pi())) * antennaEfficiency
    
    
            %% Friis according to Balanis with directivities
    
            Prad_r5(k) = (wavelenght/(4* pi()*sum(arcLength(:,indx))))^2 * intensityAtPosTx(indx).^2*length(TxAntenna.Pattern.Values(:,1))./sum(TxAntenna.Pattern.Values(:,1).^2) * intensityAtPosRxDensRef(k)^2 * length(patternValuesRx(:,1))./sum(patternValuesRx(:,1).^2) * antennaEfficiency^2 * ((1-abs(Gamma_t)^2) * (1-abs(Gamma_r(numA))^2))* TxAntennaPowerLtx * (cosd(polarizationEvolutionTotal(1,k)))^2;% *A_hitRay(k)/A_Ray(k); %* cos(sum(FarRot(:,indx)))^2
            
        end
    
        Prad_rTotal = 10^((10*log10(sum(Prad_r)/length(Prad_r))-Com.Losses)/10);
        Prad_rTotal2 = 10^((10*log10(sum(Prad_r))-Com.Losses)/10);
        Prad_rTotal3 = 10^((10*log10(sum(Prad_r2))-Com.Losses)/10);
        Prad_rTotal5 = 10^((10*log10(sum(Prad_r5)/length(Prad_r5))-Com.Losses)/10);
    
        
    
        S_x1(1,numA) = 20*log10(sqrt(abs(Prad_rTotal/(TxAntennaPowerLtx))));
        S_x2(1,numA) = 20*log10(sqrt(abs(Prad_rTotal2/(TxAntennaPowerLtx))));
        S_x3(1,numA) = 20*log10(sqrt(abs(Prad_rTotal3/(TxAntennaPowerLtx))));
        S_x5(1,numA) = 20*log10(sqrt(abs(Prad_rTotal5/(TxAntennaPowerLtx))));
    end


end

Sparameters.S_x1 = S_x1;
Sparameters.S_x2 = S_x2;
Sparameters.S_x3 = S_x3;
Sparameters.S_x5 = S_x5;

Sparameters.rayPerDegree = maxangles/(dir1-dir2);

fprintf('\n S-parameter analysis O finished. Exiting now.\n\n',NAMESHORT);
fprintf('-----------------------------------------------------------------------------------------\n');


save('MEESST_MHD_SparamOrdinary.mat', '-v7.3');