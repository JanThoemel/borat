close all
clear all
master = 'MEESST_MHD_1T_200kW_34GHz_05rpd';

master1 = ['MHD_Solutions_noBfield\' master '_B0.mat'];
%master1 = ['MHD_Solutions\' master '_correct.mat'];

%master1 = ['NonMHD_Solutions\' master '.mat'];

load(master1);

if MagneticField==0
     % plot rays and spacecraft direction/direction range within refractive index contour plot

    itpo(2,:,:)=itpo(2,:,:)*(-1);
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;(-1)
    for z=1:domain.nozones
        %%plot flowfield with ri, raytraces and s/c direction/range
        
        %%plot ri contour plot
        if 0
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            [C,h]=tricontour(domain.( strcat('zone',num2str(z)) ).delaunay  ,squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),V);
        end
        %%plot ri surface plot
        if 1
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)));
            set(h, 'edgecolor','none');
        end
        maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        maxX = max(maxX);
        minX = min(minX);
        maxY = max(maxY);
        minY = min(minY);
        maxC = max(maxC);
        minC = min(minC);
    end
    
    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    
    %%plot rays in domain
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    for a=1:maxangles
        %!can they be colored according to attenuation?
        plot3(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpoz(1:nnz(itpo(1,:,a))),'k-','LineWidth',1,'color',[105/256 105/256 105/256]);
    end
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    else
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([minC maxC]);
    end
    
    hcb=colorbar;title(hcb,'\mu [-]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Arial', 'Fontweight','bold','Linewidth',2,'FontSize',24,'TickLength',[0.02, 0.002])
    xlabel('x [m]');
    ylabel('y [m]');
    hold off;
    colormap('gray');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end
    
    
    figure
    hold on
    for a=1:maxangles
        plot(itpo(3,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a))
    end
    xlabel('path length [m]');ylabel('refractive index [-]');axis([0 inf -0.05 1.05]);
    hold off
    if writefig
        savefig('path_mu')
        %print('-painters','path_mu','-depsc')
        print('-painters','path_mu','-dpng')
    end
    %% plot attenuation over path length
    if collisionmodel~=0 %% no plot if collisions/absorption was not accounted for
        figure
        eps = 2e-16;
        for a=1:maxangles
            semilogy(itpo(3,1:nnz(itpo(1,:,a)),a), max(eps, itpo(5,1:nnz(itpo(1,:,a)),a)));
            hold on
        end
        xlabel('path length [m]');ylabel('attenutation [dB]');axis([0 inf absorptionlimits]);
        %% absorption cut off
        semilogy([0 inf], [absorptionlimits(2)-10 absorptionlimits(2)-10]);
        if writefig
            savefig('path_kappa')
            %print('-painters','path_kappa','-depsc')
            print('-painters','path_kappa','-dpng')
        end
        hold off
    end
    
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    if domain.nozones<=2
        for z=1:domain.nozones
            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end
            maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);
        end
    elseif domain.nozones>2

            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.zoneX.variables(1,domain.zoneX.bound(:))  ,  domain.zoneX.variables(2,domain.zoneX.bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end
            maxX(z) = max(domain.zoneX.variables(1,:));
            minX(z) = min(domain.zoneX.variables(1,:));
            maxY(z) = max(domain.zoneX.variables(2,:));
            minY(z) = min(domain.zoneX.variables(2,:));
            maxC(z) = max(domain.zoneX.variables(domain.nova-1,:)  );
            minC(z) = min(domain.zoneX.variables(domain.nova-1,:)  );
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);
        end

    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    %% plot rays in domain
    
    for a=1:maxangles
        %!can they be colored according to attenuation?
        itpo(1,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(2,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(4,nnz(itpo(1,:,a))+1,a)=NaN;
        %itpoz(1,nnz(itpo(1,:,a))+1,a)=NaN;
        g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a),'EdgeColor','interp','LineWidth',1.5);
        %set(g, 'edgecolor','none');
    end
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    colorbar
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    %     if  minC == maxC
%         axis equal; xlim([minX maxX]); ylim ([minY maxY]); caxis([0 1]);
%     else
%         axis equal; xlim([minX maxX]); ylim ([minY maxY]); caxis([minC maxC]);
%     end
    axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    hcb=colorbar;title(hcb,'\mu [-]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
    xlabel('X [m]');
    ylabel('Y [m]');
   % clabel('\muc[m^(-3)');
   
    hold off;
    colormap('jet');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end

    
    master2 = ['Figures\' master '_B0.fig'];
    %master2 = ['Figures\' master '_correct.fig'];
    savefig(master2)

elseif MagneticField==1
    itpo(2,:,:)=itpo(2,:,:)*(-1);
    itpoLHCP(2,:,:)=itpoLHCP(2,:,:)*(-1);
    %    clear all
%    close all

   % load('Knapp_1T_50rays_Eikonal_3.mat')
%    load('MHD_testCase_Ri07_025T.mat') 

% plot rays and spacecraft direction/direction range within refractive index contour plot
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    for z=1:domain.nozones
        %%plot flowfield with ri, raytraces and s/c direction/range
        
        %%plot ri contour plot
        if 0
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            [C,h]=tricontour(domain.( strcat('zone',num2str(z)) ).delaunay  ,squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),V);
        end
        %%plot ri surface plot
        if 1
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)));
            set(h, 'edgecolor','none');
        end
        maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        maxX = max(maxX);
        minX = min(minX);
        maxY = max(maxY);
        minY = min(minY);
        maxC = max(maxC);
        minC = min(minC);
    end
    
    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    
    %%plot rays in domain
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    for a=1:maxangles
        %!can they be colored according to attenuation?
        plot3(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpoz(1:nnz(itpo(1,:,a))),'k-','LineWidth',1,'color',[105/256 105/256 105/256]);
    end
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    else
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([minC maxC]);
    end
    
    hcb=colorbar;title(hcb,'\mu [-]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Arial', 'Fontweight','bold','Linewidth',2,'FontSize',24,'TickLength',[0.02, 0.002])
    xlabel('x [m]');
    ylabel('y [m]');
    hold off;
    colormap('gray');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end
    
    
    figure
    hold on
    for a=1:maxangles
        plot(itpo(3,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a))
    end
    xlabel('path length [m]');ylabel('refractive index [-]');axis([0 inf -0.05 1.05]);
    hold off
    if writefig
        savefig('path_mu')
        %print('-painters','path_mu','-depsc')
        print('-painters','path_mu','-dpng')
    end
    %% plot attenuation over path length
    if collisionmodel~=0 %% no plot if collisions/absorption was not accounted for
        figure
        eps = 2e-16;
        for a=1:maxangles
            semilogy(itpo(3,1:nnz(itpo(1,:,a)),a), max(eps, itpo(5,1:nnz(itpo(1,:,a)),a)));
            hold on
        end
        xlabel('path length [m]');ylabel('attenutation [dB]');axis([0 inf absorptionlimits]);
        %% absorption cut off
        semilogy([0 inf], [absorptionlimits(2)-10 absorptionlimits(2)-10]);
        if writefig
            savefig('path_kappa')
            %print('-painters','path_kappa','-depsc')
            print('-painters','path_kappa','-dpng')
        end
        hold off
    end
    
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    if domain.nozones<=2
        for z=1:domain.nozones
            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end
            maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);
        end
    elseif domain.nozones>2

            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.zoneX.variables(1,domain.zoneX.bound(:))  ,  domain.zoneX.variables(2,domain.zoneX.bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end
            maxX(z) = max(domain.zoneX.variables(1,:));
            minX(z) = min(domain.zoneX.variables(1,:));
            maxY(z) = max(domain.zoneX.variables(2,:));
            minY(z) = min(domain.zoneX.variables(2,:));
            maxC(z) = max(domain.zoneX.variables(domain.nova-1,:)  );
            minC(z) = min(domain.zoneX.variables(domain.nova-1,:)  );
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);
        end

    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    %% plot rays in domain
    
    for a=1:maxangles
        %!can they be colored according to attenuation?
        itpo(1,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(2,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(4,nnz(itpo(1,:,a))+1,a)=NaN;

        itpoLHCP(1,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
        itpoLHCP(2,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
        itpoLHCP(4,nnz(itpoLHCP(1,:,a))+1,a)=NaN;

        %itpoz(1,nnz(itpo(1,:,a))+1,a)=NaN;
        g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a),'EdgeColor','interp','LineWidth',1.5);
        gg=patch(  itpoLHCP(1,1:nnz(itpoLHCP(1,:,a)),a)  ,  itpoLHCP(2,1:nnz(itpoLHCP(1,:,a)),a),itpoLHCP(4,1:nnz(itpoLHCP(1,:,a)),a),'EdgeColor','interp','LineWidth',1.5);
        
        %set(g, 'edgecolor','none');
    end
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    colorbar
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    else
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([minC maxC]);
    end
    hcb=colorbar;title(hcb,'\mu [-]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
    xlabel('X [m]');
    ylabel('Y [m]');
   % clabel('\muc[m^(-3)');
   
    hold off;
    colormap('jet');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end
    
    master2 = ['Figures\' master '_B0.fig'];
    %master2 = ['Figures\' master '_correct.fig'];
    savefig(master2)
end



%% Intensity/Electric field/Pattern (top MHD, bottom MHD B=0)
%clear all
%load("MHD_Intensity\MEESST_MHD_025T_125kW_34GHz_05rpd_Int.mat");
%master = 'MEESST_MHD_025T_125kW_34GHz_05rpd';

master4 = ['MHD_Intensity_noBfield\' master '_B0_Int.mat'];
%master4 = ['MHD_Intensity\' master '_Int.mat'];
%master4 = ['MHD_Intensity\' master '_Int_2.mat'];
load(master4);

if MagneticField==0
    itpo(2,:,:)=itpo(2,:,:)*(-1);
    
 % compute direction and range to space craft
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) ) %% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            for it=1:3
                scdir_x(it)=pooo1(1)+cos(scdir/180*pi)*(it-1)*3;                 scdir_y(it)=pooo1(2)+sin(scdir/180*pi)*(it-1)*3;
                scdirr1_x(it)=pooo1(1)+cos((scdir+scdir_range)/180*pi)*(it-1)*3; scdirr1_y(it)=pooo1(2)+sin((scdir+scdir_range)/180*pi)*(it-1)*3;
                scdirr2_x(it)=pooo1(1)+cos((scdir-scdir_range)/180*pi)*(it-1)*3;	scdirr2_y(it)=pooo1(2)+sin((scdir-scdir_range)/180*pi)*(it-1)*3;
            end
        end
    end
    % plot rays and spacecraft direction/direction range within refractive index contour plot
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    for z=1:domain.nozones
        %%plot flowfield with ri, raytraces and s/c direction/range
        
        %%plot ri contour plot
        if 0
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            [C,h]=tricontour(domain.( strcat('zone',num2str(z)) ).delaunay  ,squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),V);
        end
        %%plot ri surface plot
        if 1
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)));
            set(h, 'edgecolor','none');
        end
        maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        maxX = max(maxX);
        minX = min(minX);
        maxY = max(maxY);
        minY = min(minY);
        maxC = max(maxC);
        minC = min(minC);
    end
    
    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    
    %%plot rays in domain
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    for a=1:maxangles
        %!can they be colored according to attenuation?
        plot3(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpoz(1:nnz(itpo(1,:,a))),'k-','LineWidth',1,'color',[105/256 105/256 105/256]);
    end
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
        
  %       axis equal; xlim([minX maxX]); ylim ([minY maxY]); caxis([minC maxC]);
    
    hcb=colorbar;title(hcb,'\mu');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',12,'TickLength',[0.02, 0.002])
    hold off;
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end
    
    
    figure
    hold on
    for a=1:maxangles
        plot(itpo(3,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a))
    end
    xlabel('path length [m]');ylabel('refractive index [-]');axis([0 inf -0.05 1.05]);
    hold off
    if writefig
        savefig('path_mu')
        %print('-painters','path_mu','-depsc')
        print('-painters','path_mu','-dpng')
    end
    %% plot attenuation over path length
    if collisionmodel~=0 %% no plot if collisions/absorption was not accounted for
        figure
        eps = 2e-16;
        for a=1:maxangles
            semilogy(itpo(3,1:nnz(itpo(1,:,a)),a), max(eps, itpo(5,1:nnz(itpo(1,:,a)),a)));
            hold on
        end
        xlabel('path length [m]');ylabel('attenutation [dB]');axis([0 inf absorptionlimits]);
        %% absorption cut off
        semilogy([0 inf], [absorptionlimits(2)-10 absorptionlimits(2)-10]);
        if writefig
            savefig('path_kappa')
            %print('-painters','path_kappa','-depsc')
            print('-painters','path_kappa','-dpng')
        end
        hold off
    end
    %% Energy along ray normlaized
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    if domain.nozones<=2
        for z=1:domain.nozones
            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end
    elseif domain.nozones>2

            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.zoneX.variables(1,domain.zoneX.bound(:))  ,  domain.zoneX.variables(2,domain.zoneX.bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end

    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    %% plot rays in domain
    
    for a=1:maxangles
        %!can they be colored according to attenuation?
        itpo(1,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(2,nnz(itpo(1,:,a))+1,a)=NaN;
       % itpo(4,nnz(itpo(1,:,a))+1,a)=NaN;
       % energyRay(7,nnz()+1,a)=NaN;
        energyNormalized(nnz(energyNormalized(:,a))+1,a)=NaN;

        if domain.nozones<=2

            maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
           % maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
           % minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            minC(z) = min(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        elseif domain.nozones>2

            maxX(z) = max(domain.zoneX.variables(1,:));
            minX(z) = min(domain.zoneX.variables(1,:));
            maxY(z) = max(domain.zoneX.variables(2,:));
            minY(z) = min(domain.zoneX.variables(2,:));
            %maxC(z) = max(domain.zoneX.variables(domain.nova-1,:)  );
           % minC(z) = min(domain.zoneX.variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            minC(z) = min(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        end
       % g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a),'EdgeColor','interp','LineWidth',1);
        g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),10*log10(energyNormalized(1:nnz(itpo(1,:,a)),a)),'EdgeColor','interp','LineWidth',1.5);
        %set(g, 'edgecolor','none');
    end
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    colorbar
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    else
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([minC maxC]);
    end
    hcb=colorbar;title(hcb,'E/E_{max} [dB]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
    xlabel('X [m]');
    ylabel('Y [m]');
   % clabel('\muc[m^(-3)');
   
    hold off;
    colormap('jet');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end

    %% Intensity along rays

    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    if domain.nozones<=2
        for z=1:domain.nozones
            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end
    elseif domain.nozones>2

            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.zoneX.variables(1,domain.zoneX.bound(:))  ,  domain.zoneX.variables(2,domain.zoneX.bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end

    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    %% plot rays in domain
    
    for a=1:maxangles
        %!can they be colored according to attenuation?
        itpo(1,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(2,nnz(itpo(1,:,a))+1,a)=NaN;
       % itpo(4,nnz(itpo(1,:,a))+1,a)=NaN;
       intensityNormalized(nnz(intensityNormalized(:,a))+1,a)=NaN;
        

        if domain.nozones<=2

            maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
           % maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
           % minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            minC(z) = min(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        elseif domain.nozones>2

            maxX(z) = max(domain.zoneX.variables(1,:));
            minX(z) = min(domain.zoneX.variables(1,:));
            maxY(z) = max(domain.zoneX.variables(2,:));
            minY(z) = min(domain.zoneX.variables(2,:));
            %maxC(z) = max(domain.zoneX.variables(domain.nova-1,:)  );
           % minC(z) = min(domain.zoneX.variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            minC(z) = min(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        end
        helper4 = real(intensityRay(1:nnz(itpo(1,:,a)),a))/max(real(intensityRay(1:nnz(itpo(1,:,a)),a)));
       % g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a),'EdgeColor','interp','LineWidth',1);
        g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),10*log10(intensityNormalized(1:nnz(itpo(1,:,a)),a)),'EdgeColor','interp','LineWidth',1.5);
        %set(g, 'edgecolor','none');
    end
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    colorbar
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    else
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([minC maxC]);
    end
    hcb=colorbar;title(hcb,'I/I_{max} [dB]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
    xlabel('X [m]');
    ylabel('Y [m]');
   % clabel('\muc[m^(-3)');
   
    hold off;
    colormap('jet');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end

    master3 = ['Figures\' master '_B0_Int.fig'];
    %master3 = ['Figures\' master '_Int.fig'];
    %master3 = ['Figures\' master '_Int_2.fig'];
    savefig(master3)

    %% Power pattern
   
    for k = 1 :maxangles
        itdirFinal(k) = itdir(dirFinal(k),k);
      %  itdirLHCPFinal(k) = itdirLHCP(dirFinalLHCP(k),k);
    end
    [itdirFinalSort(1,:),IndexSort]=sort(itdirFinal);
    intensityRayLastValueSorted = intensityRayLastValue(IndexSort);

   % [itdirFinalLHCPSort(1,:),IndexSortMHD]=sort(itdirLHCPFinal);
   % intensityRayLastValueMHDSorted = intensityRayLastValueMHD(IndexSortMHD);
    
    figure;
    plot(itdir(1,:),10*log10(intensityRay(1,:)./max(intensityRay(1,:))),'Linewidth',1.5);
    hold on
    plot(itdirFinalSort,10*log10(intensityRayLastValue./max(intensityRay(1,:))),'Linewidth',1.5);
   % plot(itdirFinalLHCPSort,10*log10(intensityRayLastValueMHDSorted));
    hold off
   % set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1.5,'FontSize',32,'TickLength',[0.02, 0.002])
    set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1.5,'FontSize',24,'TickLength',[0.02, 0.002])
    xlim([260 280]);
    ylim([-109 5]);
    xlabel('Radiaton angle \Theta [{\circ}]');
    ylabel('Intensity [dB]');

%     figure;
%     plot(itdir(1,:),10*log10(electricField(1,:).^2./max(electricField(1,:).^2)),'Linewidth',1.5);
%     hold on
%     plot(itdirFinalSort,10*log10(energyEnd.^2./max(electricField(1,:).^2)),'Linewidth',1.5);
%    % plot(itdirFinalLHCPSort,10*log10(intensityRayLastValueMHDSorted));
%     hold off
%    % set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1.5,'FontSize',32,'TickLength',[0.02, 0.002])
%     set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1.5,'FontSize',12,'TickLength',[0.02, 0.002])
%     xlim([90 270]);
%     ylim([-115 5]);
%     xlabel('Radiaton angle \Theta [{\circ}]');
%     ylabel('Electric field [dB]');

elseif MagneticField==1
    itpo(2,:,:)=itpo(2,:,:)*(-1);
    itpoLHCP(2,:,:)=itpoLHCP(2,:,:)*(-1);
%figure;
%    plot(itpo(3,1:nnz(itpo(1,:,1)),1),energyRay(6,1:nnz(itpo(1,:,1)),1))

 %   figure;
  %  quiver(itpo(1,1:nnz(itpo(1,:,1)),1),itpo(2,1:nnz(itpo(1,:,1)),1),polVector(1,1:nnz(itpo(1,:,1)),1),polVector(2,1:nnz(itpo(1,:,1)),1),0)

   % compute direction and range to space craft
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) ) %% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            for it=1:3
                scdir_x(it)=pooo1(1)+cos(scdir/180*pi)*(it-1)*3;                 scdir_y(it)=pooo1(2)+sin(scdir/180*pi)*(it-1)*3;
                scdirr1_x(it)=pooo1(1)+cos((scdir+scdir_range)/180*pi)*(it-1)*3; scdirr1_y(it)=pooo1(2)+sin((scdir+scdir_range)/180*pi)*(it-1)*3;
                scdirr2_x(it)=pooo1(1)+cos((scdir-scdir_range)/180*pi)*(it-1)*3;	scdirr2_y(it)=pooo1(2)+sin((scdir-scdir_range)/180*pi)*(it-1)*3;
            end
        end
    end
    % plot rays and spacecraft direction/direction range within refractive index contour plot
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    for z=1:domain.nozones
        %%plot flowfield with ri, raytraces and s/c direction/range
        
        %%plot ri contour plot
        if 0
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            [C,h]=tricontour(domain.( strcat('zone',num2str(z)) ).delaunay  ,squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:)),squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),V);
        end
        %%plot ri surface plot
        if 1
            %% plot boundary
            plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',2)
            %% plot ri
            h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)));
            set(h, 'edgecolor','none');
        end
        maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
        maxX = max(maxX);
        minX = min(minX);
        maxY = max(maxY);
        minY = min(minY);
        maxC = max(maxC);
        minC = min(minC);
    end
    
    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    
    %%plot rays in domain
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    for a=1:maxangles
        %!can they be colored according to attenuation?
        plot3(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpoz(1:nnz(itpo(1,:,a))),'k-','LineWidth',1,'color',[105/256 105/256 105/256]);
    end
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
        
  %       axis equal; xlim([minX maxX]); ylim ([minY maxY]); caxis([minC maxC]);
    
    hcb=colorbar;title(hcb,'\mu');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',12,'TickLength',[0.02, 0.002])
    hold off;
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end
    
    
    figure
    hold on
    for a=1:maxangles
        plot(itpo(3,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a))
    end
    xlabel('path length [m]');ylabel('refractive index [-]');axis([0 inf -0.05 1.05]);
    hold off
    if writefig
        savefig('path_mu')
        %print('-painters','path_mu','-depsc')
        print('-painters','path_mu','-dpng')
    end
    %% plot attenuation over path length
    if collisionmodel~=0 %% no plot if collisions/absorption was not accounted for
        figure
        eps = 2e-16;
        for a=1:maxangles
            semilogy(itpo(3,1:nnz(itpo(1,:,a)),a), max(eps, itpo(5,1:nnz(itpo(1,:,a)),a)));
            hold on
        end
        xlabel('path length [m]');ylabel('attenutation [dB]');axis([0 inf absorptionlimits]);
        %% absorption cut off
        semilogy([0 inf], [absorptionlimits(2)-10 absorptionlimits(2)-10]);
        if writefig
            savefig('path_kappa')
            %print('-painters','path_kappa','-depsc')
            print('-painters','path_kappa','-dpng')
        end
        hold off
    end
    %% Energy along ray normlaized
    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    if domain.nozones<=2
        for z=1:domain.nozones
            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end
    elseif domain.nozones>2

            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.zoneX.variables(1,domain.zoneX.bound(:))  ,  domain.zoneX.variables(2,domain.zoneX.bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end

    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    %% plot rays in domain
    
    for a=1:maxangles
        %!can they be colored according to attenuation?
        itpo(1,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(2,nnz(itpo(1,:,a))+1,a)=NaN;
       % itpo(4,nnz(itpo(1,:,a))+1,a)=NaN;
       % energyRay(7,nnz()+1,a)=NaN;
        energyNormalized(nnz(energyNormalized(:,a))+1,a)=NaN;

       itpoLHCP(1,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
       itpoLHCP(2,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
       %itpoLHCP(4,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
       energyNormalizedMHD(nnz(energyNormalizedMHD(:,a))+1,a)=NaN;

        if domain.nozones<=2

            maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
           % maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
           % minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            minC(z) = min(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        elseif domain.nozones>2

            maxX(z) = max(domain.zoneX.variables(1,:));
            minX(z) = min(domain.zoneX.variables(1,:));
            maxY(z) = max(domain.zoneX.variables(2,:));
            minY(z) = min(domain.zoneX.variables(2,:));
            %maxC(z) = max(domain.zoneX.variables(domain.nova-1,:)  );
           % minC(z) = min(domain.zoneX.variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            minC(z) = min(10*log(energyNormalized(1:nnz(energyNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        end
       % g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a),'EdgeColor','interp','LineWidth',1);
        g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),10*log10(energyNormalized(1:nnz(itpo(1,:,a)),a)),'EdgeColor','interp','LineWidth',1.5);
        gg=patch(  itpoLHCP(1,1:nnz(itpoLHCP(1,:,a)),a)  ,  itpoLHCP(2,1:nnz(itpoLHCP(1,:,a)),a),10*log10(energyNormalizedMHD(1:nnz(itpoLHCP(1,:,a)),a)),'EdgeColor','interp','LineWidth',1.5);
        %set(g, 'edgecolor','none');
    end
    itpoz=z_max*ones(   size( itpo(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    colorbar
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    else
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([minC maxC]);
    end
    hcb=colorbar;title(hcb,'E/E_{max} [dB]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
    xlabel('X [m]');
    ylabel('Y [m]');
   % clabel('\muc[m^(-3)');
   
    hold off;
    colormap('jet');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end

    %% Intensity along rays

    figure
    hold on;
    V=[1e-17,1e-16,1e-15,1e-14,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6,1e-5,1e-4,1e-3,1e-3:0.02:1-1e-3,1-1e-3,1-1e-4,1-1e-5,1-1e-6,1-1e-7,1-1e-8,1-1e-9,1-1e-10,1-1e-11,1-1e-12,1-1e-13,1-1e-14,1-1e-15,1-1e-16,1-1e-17,1];
    %V=[0:0.1:0.9,0.9:0.01:1];
    %V=[0.09:0.01:0.99];
    %axis equal;
    if domain.nozones<=2
        for z=1:domain.nozones
            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end
    elseif domain.nozones>2

            %%plot flowfield with ri, raytraces and s/c direction/range
            
          
            %% plot ri surface plot
            if 1
                %% plot boundary
                plot(      domain.zoneX.variables(1,domain.zoneX.bound(:))  ,  domain.zoneX.variables(2,domain.zoneX.bound(:))  ,  'k-','LineWidth',1)
                %% plot ri
               % h=trisurf(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)),domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:));
                %set(h, 'edgecolor','none');
            end

        end

    z_max = max(max(get(h,'Zdata')));
    scdir_z=[z_max,z_max,z_max];
    %% plot rays in domain
    
    for a=1:maxangles
        %!can they be colored according to attenuation?
        itpo(1,nnz(itpo(1,:,a))+1,a)=NaN;
        itpo(2,nnz(itpo(1,:,a))+1,a)=NaN;
       % itpo(4,nnz(itpo(1,:,a))+1,a)=NaN;
       intensityNormalized(nnz(intensityNormalized(:,a))+1,a)=NaN;

       itpoLHCP(1,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
       itpoLHCP(2,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
       %itpoLHCP(4,nnz(itpoLHCP(1,:,a))+1,a)=NaN;
       intensityNormalizedMHD(nnz(intensityNormalizedMHD(:,a))+1,a)=NaN;
        

        if domain.nozones<=2

            maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
            maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
            minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
           % maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
           % minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            minC(z) = min(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        elseif domain.nozones>2

            maxX(z) = max(domain.zoneX.variables(1,:));
            minX(z) = min(domain.zoneX.variables(1,:));
            maxY(z) = max(domain.zoneX.variables(2,:));
            minY(z) = min(domain.zoneX.variables(2,:));
            %maxC(z) = max(domain.zoneX.variables(domain.nova-1,:)  );
           % minC(z) = min(domain.zoneX.variables(domain.nova-1,:)  );
            maxC(z) = max(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            minC(z) = min(10*log(intensityNormalized(1:nnz(intensityNormalized(:,a)),a)));
            maxX = max(maxX);
            minX = min(minX);
            maxY = max(maxY);
            minY = min(minY);
            maxC = max(maxC);
            minC = min(minC);

        end
        helper4 = real(intensityRay(1:nnz(itpo(1,:,a)),a))/max(real(intensityRay(1:nnz(itpo(1,:,a)),a)));
       % g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),itpo(4,1:nnz(itpo(1,:,a)),a),'EdgeColor','interp','LineWidth',1);
        g=patch(  itpo(1,1:nnz(itpo(1,:,a)),a)  ,  itpo(2,1:nnz(itpo(1,:,a)),a),10*log10(intensityNormalized(1:nnz(itpo(1,:,a)),a)),'EdgeColor','interp','LineWidth',1.5);
        gg=patch(  itpoLHCP(1,1:nnz(itpoLHCP(1,:,a)),a)  ,  itpoLHCP(2,1:nnz(itpoLHCP(1,:,a)),a),10*log10(intensityNormalizedMHD(1:nnz(itpoLHCP(1,:,a)),a)),'EdgeColor','interp','LineWidth',1.5);
        %set(g, 'edgecolor','none');
    end
    itpoz=z_max*ones(   size( itdirLHCP(1,:,1),2)   ,1);%z coordinates of lines to be plotted
    colorbar
    %%plot s/c direction and direction range
    if plotscdir
        if ( pooo1(1)==pooo2(1) && pooo1(2)==pooo2(2) )%% compute and show spacecraft direction and range only if raytracing start from antenna location i.e. pooo1=pooo2
            plot3(scdir_x,scdir_y,scdir_z,'k-.','color',[20/256 20/256 20/256]);
            %plot3(scdirr1_x,scdirr1_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
            %plot3(scdirr2_x,scdirr2_y,scdir_z,'k--','color',[20/256 20/256 20/256]);
        end
    end
    text(1.5,3.1,z_max+1,'direction to TGO');
    set(h, 'edgecolor','none');
    set(gcf, 'Position', [10, 10, 1100, 800]);
    % xlim([-0.17 6]);ylim([0 5.185]);caxis([0 1])
    if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([0 1]);
    else
        axis equal; xlim([minX maxX]); ylim ([minY 0]); caxis([minC maxC]);
    end
    hcb=colorbar;title(hcb,'I/I_{max} [dB]');
    box off;grid off;
    set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
    xlabel('X [m]');
    ylabel('Y [m]');
   % clabel('\muc[m^(-3)');
   
    hold off;
    colormap('jet');
    if writefig
        savefig('raytracing')
        %print('-painters','raytracing','-depsc')
        print('-painters','raytracing','-dpng')
    end
    for k = 1: maxangles
        lastNonZero = find(itdirLHCP(:,k),1,'last');
        dirFinalLHCP(1,k) = lastNonZero;
       
    end
    for k = 1: maxangles
        lastNonZero = find(itdir(:,k),1,'last');
        dirFinal(1,k) = lastNonZero;
       
    end

    for k = 1 :maxangles
        itdirFinal(k) = itdir(dirFinal(k),k);
        itdirLHCPFinal(k) = itdirLHCP(dirFinalLHCP(k),k);
    end
    [itdirFinalSort(1,:),IndexSort]=sort(itdirFinal);
    intensityRayLastValueSorted = intensityRayLastValue(IndexSort);

    [itdirFinalLHCPSort(1,:),IndexSortMHD]=sort(itdirLHCPFinal);
    intensityRayLastValueMHDSorted = intensityRayLastValueMHD(IndexSortMHD);

    intensityTogether = [itdirFinalLHCPSort(1,:),itdirFinalSort(1,:);intensityRayLastValueMHDSorted,zeros(1,length(intensityRayLastValue));zeros(1,length(intensityRayLastValueMHDSorted)),intensityRayLastValue];
    [~,Sorter] = sort(intensityTogether(1,:));
    intensityTogetherSorted = intensityTogether(:,Sorter);

    for gg = 2:3
        if intensityTogetherSorted(gg,1) == 0
            intensityTogetherSorted(gg,1) = intensityTogetherSorted(gg,2);
        end
        if intensityTogetherSorted(gg,end-1) ==0 && intensityTogetherSorted(gg,end) == 0
            intensityTogetherSorted(gg,end) = intensityTogetherSorted(gg,end-2);
            intensityTogetherSorted(gg,end-1) = intensityTogetherSorted(gg,end-2);    
        end
        if intensityTogetherSorted(gg,end) == 0
            intensityTogetherSorted(gg,end) = intensityTogetherSorted(gg,end-1);

        end
    end

    for gg = 2:3

        for hh = 2: length(intensityTogetherSorted(1,:))-1
            if intensityTogetherSorted(gg,hh) ==0 && intensityTogetherSorted(gg,hh+1) ==0
                intensityTogetherSorted(gg,hh) = (intensityTogetherSorted(gg,hh-1));%+intensityTogetherSorted(gg,hh+1))/2;
            end
            if intensityTogetherSorted(gg,hh) ==0 && intensityTogetherSorted(gg,hh+1) ~=0
                intensityTogetherSorted(gg,hh) = (intensityTogetherSorted(gg,hh-1)+intensityTogetherSorted(gg,hh+1))/2;
            end
        end
    end

    for hh = 1: length(intensityTogetherSorted(1,:))
        intensityTogetherSortedSummed(1,hh) = intensityTogetherSorted(1,hh);
        intensityTogetherSortedSummedHalf(1,hh) = intensityTogetherSorted(1,hh);
        intensityTogetherSortedSummed(2,hh) = intensityTogetherSorted(2,hh) + intensityTogetherSorted(3,hh);
        intensityTogetherSortedSummedHalf(2,hh) = (intensityTogetherSorted(2,hh) + intensityTogetherSorted(3,hh))/2;
    end
    master3 = ['Figures\' master '_B0_Int.fig'];
    %master3 = ['Figures\' master '_Int.fig'];
    %master3 = ['Figures\' master '_Int_2.fig'];
    savefig(master3)

    
    figure;
    plot(itdir(1,:),10*log10(intensityAtPos(1,:)),'Linewidth',1.5);
    hold on
    %plot(itdirFinalSort,10*log10(intensityRayLastValue),'Linewidth',1.5);
    %plot(itdirFinalLHCPSort,10*log10(intensityRayLastValueMHDSorted),'Linewidth',1.5);
    plot(intensityTogetherSortedSummed(1,:),10*log10(intensityTogetherSortedSummed(2,:)),'Linewidth',1.5);
    %plot(intensityTogetherSortedSummedHalf(1,:),10*log10(intensityTogetherSortedSummedHalf(2,:)),'Linewidth',1.5);
    hold off
   % set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1.5,'FontSize',32,'TickLength',[0.02, 0.002])
    set(gca, 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',1.5,'FontSize',24,'TickLength',[0.02, 0.002])
    xlabel('Radiaton angle \Theta [{\circ}]');
    ylabel('Intensity [dB]');
    xlim([90 180]);
    legend('Initial radiation pattern','With plasma, 6 magnets')

end
