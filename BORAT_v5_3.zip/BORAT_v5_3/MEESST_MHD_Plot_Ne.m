close all
clear all
master = 'MEESST_MHD_1T_200kW_40GHz_05rpd';

master1 = ['MHD_Intensity\' master '_Int.mat'];
load(master1);

if MagneticField==0
    itpo(2,:,:)=itpo(2,:,:)*(-1);

    figure
    hold on
    
    VD=[criticaldensity criticaldensity];
    
    
    for z=1:domain.nozones
        % plot boundary
        plot( domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:)) , ...
            domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:)) , ...
            'k-','LineWidth',2)
        
        
        % plot electrondensity countours
        %                [C,h]=tricontour(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ),nb_lines);
        %[C,h]=tricontour(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ),VE);
        %[C,h]=tricontour(    domain.( strcat('zone',num2str(1)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(1)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(1)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(1)) ).variables(domain.nova-5,:)  ),VE);
        %VE=[1e13,1e14,1e15,1e16,1e17,1e18];
        
        
        h=trisurf( domain.( strcat('zone',num2str(z))).delaunay     , ...
            squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  , ...
            squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  , ...
            squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ) );
        
        xlabel('X [m]');ylabel('Y [m]');zlabel('Z');
        set(h, 'edgecolor','none');
        set(gcf, 'Position', [10, 10, 1100, 800]);
        
        
        %   xlim([-0.17 6]);ylim([0 5.185]);caxis([1e16 1e17]);
        maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  );
        minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  );
        maxX = max(maxX);
        minX = min(minX);
        maxY = max(maxY);
        minY = min(minY);
        maxC = max(maxC);
        minC = min(minC);
        if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([0 maxY]); caxis([0 1]);
        else
            axis equal; xlim([minX maxX]); ylim ([0 maxY]); caxis([minC criticaldensity]);
        end
        
        %h.Fill='on'
        % %plot critical electrondensity, Davis page 61, eq. 2.54 and k of page 71
        %{
                if max_edensity > criticaldensity
                    [D,i]=tricontour(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ));
                    i(1).LineWidth=2;
                    i(1).EdgeColor='k';
                    %text(0,5,strcat('critical density=',num2str(criticaldensity,'%1.1e')));
                end
        %}
        
        hcb=colorbar;title(hcb,'N_e [m^{-3}]          ');
        box off;grid off;
        set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
        xlabel('X [m]');
        ylabel('Y [m]');
        colormap('gray');
        
    end
    hold off







    master2 = ['Figures\' master '_Ne.fig'];
    savefig(master2)


elseif MagneticField==1
    itpo(2,:,:)=itpo(2,:,:)*(-1);
    itpoLHCP(2,:,:)=itpoLHCP(2,:,:)*(-1);

    figure
    hold on
    
    VD=[criticaldensity criticaldensity];
    
    
    for z=1:domain.nozones
        % plot boundary
        plot( domain.( strcat('zone',num2str(z)) ).variables(1,domain.( strcat('zone',num2str(z)) ).bound(:)) , ...
            domain.( strcat('zone',num2str(z)) ).variables(2,domain.( strcat('zone',num2str(z)) ).bound(:)) , ...
            'k-','LineWidth',2)
        
        
        % plot electrondensity countours
        %                [C,h]=tricontour(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ),nb_lines);
        %[C,h]=tricontour(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ),VE);
        %[C,h]=tricontour(    domain.( strcat('zone',num2str(1)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(1)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(1)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(1)) ).variables(domain.nova-5,:)  ),VE);
        %VE=[1e13,1e14,1e15,1e16,1e17,1e18];
        
        
        h=trisurf( domain.( strcat('zone',num2str(z))).delaunay     , ...
            squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  , ...
            squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  , ...
            squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ) );
        
        xlabel('X [m]');ylabel('Y [m]');zlabel('Z');
        set(h, 'edgecolor','none');
        set(gcf, 'Position', [10, 10, 1100, 800]);
        
        
        %   xlim([-0.17 6]);ylim([0 5.185]);caxis([1e16 1e17]);
        maxX(z) = max(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        minX(z) = min(domain.( strcat('zone',num2str(z)) ).variables(1,:));
        maxY(z) = max(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        minY(z) = min(domain.( strcat('zone',num2str(z)) ).variables(2,:));
        maxC(z) = max(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  );
        minC(z) = min(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  );
        maxX = max(maxX);
        minX = min(minX);
        maxY = max(maxY);
        minY = min(minY);
        maxC = max(maxC);
        minC = min(minC);
        if  minC == maxC
        axis equal; xlim([minX maxX]); ylim ([0 maxY]); caxis([0 1]);
        else
            axis equal; xlim([minX maxX]); ylim ([0 maxY]); caxis([minC criticaldensity]);
        end
        
        %h.Fill='on'
        % %plot critical electrondensity, Davis page 61, eq. 2.54 and k of page 71
        %{
                if max_edensity > criticaldensity
                    [D,i]=tricontour(    domain.( strcat('zone',num2str(z)) ).delaunay    ,   squeeze(domain.( strcat('zone',num2str(z)) ).variables(1,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(2,:))  ,  squeeze(domain.( strcat('zone',num2str(z)) ).variables(domain.nova-5,:)  ));
                    i(1).LineWidth=2;
                    i(1).EdgeColor='k';
                    %text(0,5,strcat('critical density=',num2str(criticaldensity,'%1.1e')));
                end
        %}
        
        hcb=colorbar;title(hcb,'N_e [m^{-3}]          ');
        box off;grid off;
        set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',32,'TickLength',[0.02, 0.002])
        xlabel('X [m]');
        ylabel('Y [m]');
        colormap('gray');
        
    end
    hold off





    master2 = ['Figures\' master '_Ne.fig'];
    savefig(master2)
end