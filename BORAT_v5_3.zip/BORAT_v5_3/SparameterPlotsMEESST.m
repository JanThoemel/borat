%% S_parameter_Validation
clear all
close all
x = [125, 150, 175, 200];
%% S21
a = [-87.22,	-58.19,	-54.54,	-95.12];
aerr = [4.214,	0.009,	0.004,	11.036];
b = [-38.96,	-40.06,	-45.73,	-67.80];
berr = [0.000,	0.000,	0.001,	0.093];
c = [-67.83,	-65.24,	-89.47,	-69.85];
cerr = [0.081,	0.047,	6.062,	0.148];
aa = [-42.88,	-43.41,	-47.81,	-46.97];
aaerr = [1.520367761,2.053260796,1.901722846,2.200374146];
bb = [-41.89,	-44.91,	-46.85,	-43.83];
bberr = [1.796800474,1.410948587,1.366508963,1.448139281];
cc = [-40.94,	-42.86,	-45.43,	-43.90];
ccerr = [1.380001614,1.181243485,1.272074253,1.394760041];

figure;
errorbar(x,a,aerr,"r",'Linewidth',2)
hold on
errorbar(x,b,berr,"--g",'Linewidth',2)
errorbar(x,c,cerr,"-.b",'Linewidth',2)

% figure;
% plot(x,a,"r",'Linewidth',2)
% hold on
% plot(x,b,"--g",'Linewidth',2)
% plot(x,c,"-.b",'Linewidth',2)
% 
%  plot(x,aa,'Linewidth',2)
%  patch([x; flip(x)], [aa-aaerr; flip(aa+aaerr)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
%  plot(x,bb,'Linewidth',2)
%  patch([x; flip(x)], [bb-bberr; flip(bb+bberr)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%  plot(x,cc,'Linewidth',2)
%  patch([x; flip(x)], [cc-ccerr; flip(cc+ccerr)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x,aa,aaerr,'Linewidth',2)
errorbar(x,bb,bberr,'Linewidth',2)
errorbar(x,cc,ccerr,'Linewidth',2)

hold off
box off;grid off;
xlim([120 205]); ylim ([-100 30]);
xlabel('Power [kW]');ylabel('S_{21,t} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('0 T - num.', '0.25 T - num.', '0.41 T - num.','0 T - exp.', '0.25 T - exp.', '0.41 T - exp.', 'Location','NorthEast');

master3a = ['MEESST_Plot_Sparameter\S21_34GHz.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

%% S31
d = [-90.08,	-67.65,	-56.16,	-86.63];
derr = [6.125,	0.080,	0.006,	4.177];
e = [-38.55,	-39.58,	-45.83,	-67.53];
eerr = [0.000,	0.000,	0.001,	0.086];
f = [-61.74,	-64.20,	-90.84,	-38.03];
ferr = [0.020,	0.036,	7.045,	0.000];
dd = [-46.63273117,	-48.90388427,	-49.75105417,	-49.70329017];
dderr = [2.297669354,2.065481352,1.843460523,2.245285077];
ee = [-45.50780322,	-50.60250134,	-50.68039088,	-47.91381717];

eeerr = [1.804180816,2.011118098,1.781833951,2.007273984];
ff = [-46.24026762,	-50.14256443,	-51.01493001,	-48.39632378];
fferr = [1.207238195,1.25566958,1.499945454,1.730077157];


figure;
errorbar(x,d,derr,"r",'Linewidth',2)
hold on
errorbar(x,e,eerr,"--g",'Linewidth',2)
errorbar(x,f,ferr,"-.b",'Linewidth',2)

% figure;
% plot(x,d,"r",'Linewidth',2)
% hold on
% plot(x,e,"--g",'Linewidth',2)
% plot(x,f,"-.b",'Linewidth',2)

%  plot(x,dd,'Linewidth',2)
%  patch([x; flip(x)], [dd-dderr; flip(dd+dderr)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
%  plot(x,ee,'Linewidth',2)
%  patch([x; flip(x)], [ee-eeerr; flip(ee+eeerr)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%  plot(x,ff,'Linewidth',2)
%  patch([x; flip(x)], [ff-fferr; flip(ff+fferr)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')
errorbar(x,dd,dderr,'Linewidth',2)
errorbar(x,ee,eeerr,'Linewidth',2)
errorbar(x,ff,fferr,'Linewidth',2)

hold off
box off;grid off;
xlim([120 205]); ylim ([-100 30]);
xlabel('Power [kW]');ylabel('S_{31,t} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('0 T - num.', '0.25 T - num.', '0.41 T - num.','0 T - exp.', '0.25 T - exp.', '0.41 T - exp.', 'Location','NorthEast');

master3a = ['MEESST_Plot_Sparameter\S31_34GHz.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

%% S41
g = [-90.44,	-76.80,	-68.20,	-67.37];
gerr = [5.281,	0.444,	0.067,	0.058];
h = [-33.46,	-58.38,	-54.18,	-65.84];
herr = [0.000,	0.007,	0.003,	0.041];
i = [-56.38,	-52.14,	-48.07,	-54.39];
ierr = [0.004,	0.002,	0.001,	0.003];
gg = [-47.07155446,	-51.4148985,	-52.90405673,	-51.87591945];
ggerr = [1.613897436,1.895230694,2.249243727,2.316490413];
hh = [-47.70472078,	-50.90448975,	-51.09820967,	-50.95754503];
hherr = [1.834258056,1.968951046,1.490427445,1.944659282];
ii = [-48.03676412,	-51.91858927,	-51.39823651,	-51.02541704];
iierr = [1.273865078,1.403017643,1.333959164,1.405624649];

figure;
errorbar(x,g,gerr,"r",'Linewidth',2)
hold on
errorbar(x,h,herr,"--g",'Linewidth',2)
errorbar(x,i,ierr,"-.b",'Linewidth',2)


% figure;
% plot(x,g,"r",'Linewidth',2)
% hold on
% plot(x,h,"--g",'Linewidth',2)
% plot(x,i,"-.b",'Linewidth',2)
% 
%  plot(x,gg,'Linewidth',2)
%  patch([x; flip(x)], [gg-ggerr; flip(gg+ggerr)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
%  plot(x,hh,'Linewidth',2)
%  patch([x; flip(x)], [hh-hherr; flip(hh+hherr)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%  plot(x,ii,'Linewidth',2)
%  patch([x; flip(x)], [ii-iierr; flip(ii+iierr)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x,gg,ggerr,'Linewidth',2)
errorbar(x,hh,hherr,'Linewidth',2)
errorbar(x,ii,iierr,'Linewidth',2)

hold off
box off;grid off;
xlim([120 205]); ylim ([-100 30]);
xlabel('Power [kW]');ylabel('S_{41,t} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('0 T - num.', '0.25 T - num.', '0.41 T - num.','0 T - exp.', '0.25 T - exp.', '0.41 T - exp.', 'Location','NorthEast');

master3a = ['MEESST_Plot_Sparameter\S41_34GHz.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)





Cases_0T = readtable('SparameterMEESST3Power.xlsx','Sheet','0T');
Cases_025T = readtable('SparameterMEESST3Power.xlsx','Sheet','025T');
Cases_041T = readtable('SparameterMEESST3Power.xlsx','Sheet','041T');

Cases_Num0T = readtable('SparameterMEESST3Power.xlsx','Sheet','Num0T');
Cases_Num025T = readtable('SparameterMEESST3Power.xlsx','Sheet','Num025T');
Cases_Num041T = readtable('SparameterMEESST3Power.xlsx','Sheet','Num041T');

Cases_Err0T = readtable('SparameterMEESST3Power.xlsx','Sheet','Err0T');
Cases_Err025T = readtable('SparameterMEESST3Power.xlsx','Sheet','Err025T');
Cases_Err041T = readtable('SparameterMEESST3Power.xlsx','Sheet','Err041T');


x= table2array(Cases_0T(1:201,1));
x2 = [34;37;40];
ant2_0kW_exp_0T = table2array(Cases_0T(1:201,2));
ant3_0kW_exp_0T = table2array(Cases_0T(1:201,3));
ant4_0kW_exp_0T = table2array(Cases_0T(1:201,4));

ant2_125kW_exp_0T = table2array(Cases_0T(1:201,5));
ant3_125kW_exp_0T = table2array(Cases_0T(1:201,6));
ant4_125kW_exp_0T = table2array(Cases_0T(1:201,7));

ant2_150kW_exp_0T = table2array(Cases_0T(1:201,8));
ant3_150kW_exp_0T = table2array(Cases_0T(1:201,9));
ant4_150kW_exp_0T = table2array(Cases_0T(1:201,10));

ant2_175kW_exp_0T = table2array(Cases_0T(1:201,11));
ant3_175kW_exp_0T = table2array(Cases_0T(1:201,12));
ant4_175kW_exp_0T = table2array(Cases_0T(1:201,13));

ant2_200kW_exp_0T = table2array(Cases_0T(1:201,14));
ant3_200kW_exp_0T = table2array(Cases_0T(1:201,15));
ant4_200kW_exp_0T = table2array(Cases_0T(1:201,16));


ant2_0kW_exp_025T = table2array(Cases_025T(1:201,2));
ant3_0kW_exp_025T = table2array(Cases_025T(1:201,3));
ant4_0kW_exp_025T = table2array(Cases_025T(1:201,4));

ant2_125kW_exp_025T = table2array(Cases_025T(1:201,5));
ant3_125kW_exp_025T = table2array(Cases_025T(1:201,6));
ant4_125kW_exp_025T = table2array(Cases_025T(1:201,7));

ant2_150kW_exp_025T = table2array(Cases_025T(1:201,8));
ant3_150kW_exp_025T = table2array(Cases_025T(1:201,9));
ant4_150kW_exp_025T = table2array(Cases_025T(1:201,10));

ant2_175kW_exp_025T = table2array(Cases_025T(1:201,11));
ant3_175kW_exp_025T = table2array(Cases_025T(1:201,12));
ant4_175kW_exp_025T = table2array(Cases_025T(1:201,13));

ant2_200kW_exp_025T = table2array(Cases_025T(1:201,14));
ant3_200kW_exp_025T = table2array(Cases_025T(1:201,15));
ant4_200kW_exp_025T = table2array(Cases_025T(1:201,16));



ant2_0kW_exp_041T = table2array(Cases_041T(1:201,2));
ant3_0kW_exp_041T = table2array(Cases_041T(1:201,3));
ant4_0kW_exp_041T = table2array(Cases_041T(1:201,4));

ant2_125kW_exp_041T = table2array(Cases_041T(1:201,5));
ant3_125kW_exp_041T = table2array(Cases_041T(1:201,6));
ant4_125kW_exp_041T = table2array(Cases_041T(1:201,7));

ant2_150kW_exp_041T = table2array(Cases_041T(1:201,8));
ant3_150kW_exp_041T = table2array(Cases_041T(1:201,9));
ant4_150kW_exp_041T = table2array(Cases_041T(1:201,10));

ant2_175kW_exp_041T = table2array(Cases_041T(1:201,11));
ant3_175kW_exp_041T = table2array(Cases_041T(1:201,12));
ant4_175kW_exp_041T = table2array(Cases_041T(1:201,13));

ant2_200kW_exp_041T = table2array(Cases_041T(1:201,14));
ant3_200kW_exp_041T = table2array(Cases_041T(1:201,15));
ant4_200kW_exp_041T = table2array(Cases_041T(1:201,16));







ant2_0kW_num_0T = table2array(Cases_Num0T(:,2));
ant3_0kW_num_0T = table2array(Cases_Num0T(:,3));
ant4_0kW_num_0T = table2array(Cases_Num0T(:,4));

ant2_125kW_num_0T = table2array(Cases_Num0T(:,5));
ant3_125kW_num_0T = table2array(Cases_Num0T(:,6));
ant4_125kW_num_0T = table2array(Cases_Num0T(:,7));

ant2_150kW_num_0T = table2array(Cases_Num0T(:,8));
ant3_150kW_num_0T = table2array(Cases_Num0T(:,9));
ant4_150kW_num_0T = table2array(Cases_Num0T(:,10));

ant2_175kW_num_0T = table2array(Cases_Num0T(:,11));
ant3_175kW_num_0T = table2array(Cases_Num0T(:,12));
ant4_175kW_num_0T = table2array(Cases_Num0T(:,13));

ant2_200kW_num_0T = table2array(Cases_Num0T(:,14));
ant3_200kW_num_0T = table2array(Cases_Num0T(:,15));
ant4_200kW_num_0T = table2array(Cases_Num0T(:,16));


ant2_0kW_num_025T = table2array(Cases_Num025T(:,2));
ant3_0kW_num_025T = table2array(Cases_Num025T(:,3));
ant4_0kW_num_025T = table2array(Cases_Num025T(:,4));

ant2_125kW_num_025T = table2array(Cases_Num025T(:,5));
ant3_125kW_num_025T = table2array(Cases_Num025T(:,6));
ant4_125kW_num_025T = table2array(Cases_Num025T(:,7));

ant2_150kW_num_025T = table2array(Cases_Num025T(:,8));
ant3_150kW_num_025T = table2array(Cases_Num025T(:,9));
ant4_150kW_num_025T = table2array(Cases_Num025T(:,10));

ant2_175kW_num_025T = table2array(Cases_Num025T(:,11));
ant3_175kW_num_025T = table2array(Cases_Num025T(:,12));
ant4_175kW_num_025T = table2array(Cases_Num025T(:,13));

ant2_200kW_num_025T = table2array(Cases_Num025T(:,14));
ant3_200kW_num_025T = table2array(Cases_Num025T(:,15));
ant4_200kW_num_025T = table2array(Cases_Num025T(:,16));



ant2_0kW_num_041T = table2array(Cases_Num041T(:,2));
ant3_0kW_num_041T = table2array(Cases_Num041T(:,3));
ant4_0kW_num_041T = table2array(Cases_Num041T(:,4));

ant2_125kW_num_041T = table2array(Cases_Num041T(:,5));
ant3_125kW_num_041T = table2array(Cases_Num041T(:,6));
ant4_125kW_num_041T = table2array(Cases_Num041T(:,7));

ant2_150kW_num_041T = table2array(Cases_Num041T(:,8));
ant3_150kW_num_041T = table2array(Cases_Num041T(:,9));
ant4_150kW_num_041T = table2array(Cases_Num041T(:,10));

ant2_175kW_num_041T = table2array(Cases_Num041T(:,11));
ant3_175kW_num_041T = table2array(Cases_Num041T(:,12));
ant4_175kW_num_041T = table2array(Cases_Num041T(:,13));

ant2_200kW_num_041T = table2array(Cases_Num041T(:,14));
ant3_200kW_num_041T = table2array(Cases_Num041T(:,15));
ant4_200kW_num_041T = table2array(Cases_Num041T(:,16));





ant2_0kW_exp_0T_err = table2array(Cases_0T(1:201,2+15));
ant3_0kW_exp_0T_err = table2array(Cases_0T(1:201,3+15));
ant4_0kW_exp_0T_err = table2array(Cases_0T(1:201,4+15));

ant2_125kW_exp_0T_err = table2array(Cases_0T(1:201,5+15));
ant3_125kW_exp_0T_err = table2array(Cases_0T(1:201,6+15));
ant4_125kW_exp_0T_err = table2array(Cases_0T(1:201,7+15));

ant2_150kW_exp_0T_err = table2array(Cases_0T(1:201,8+15));
ant3_150kW_exp_0T_err = table2array(Cases_0T(1:201,9+15));
ant4_150kW_exp_0T_err = table2array(Cases_0T(1:201,10+15));

ant2_175kW_exp_0T_err = table2array(Cases_0T(1:201,11+15));
ant3_175kW_exp_0T_err = table2array(Cases_0T(1:201,12+15));
ant4_175kW_exp_0T_err = table2array(Cases_0T(1:201,13+15));

ant2_200kW_exp_0T_err = table2array(Cases_0T(1:201,14+15));
ant3_200kW_exp_0T_err = table2array(Cases_0T(1:201,15+15));
ant4_200kW_exp_0T_err = table2array(Cases_0T(1:201,16+15));


ant2_0kW_exp_025T_err = table2array(Cases_025T(1:201,2+15));
ant3_0kW_exp_025T_err = table2array(Cases_025T(1:201,3+15));
ant4_0kW_exp_025T_err = table2array(Cases_025T(1:201,4+15));

ant2_125kW_exp_025T_err = table2array(Cases_025T(1:201,5+15));
ant3_125kW_exp_025T_err = table2array(Cases_025T(1:201,6+15));
ant4_125kW_exp_025T_err = table2array(Cases_025T(1:201,7+15));

ant2_150kW_exp_025T_err = table2array(Cases_025T(1:201,8+15));
ant3_150kW_exp_025T_err = table2array(Cases_025T(1:201,9+15));
ant4_150kW_exp_025T_err = table2array(Cases_025T(1:201,10+15));

ant2_175kW_exp_025T_err = table2array(Cases_025T(1:201,11+15));
ant3_175kW_exp_025T_err = table2array(Cases_025T(1:201,12+15));
ant4_175kW_exp_025T_err = table2array(Cases_025T(1:201,13+15));

ant2_200kW_exp_025T_err = table2array(Cases_025T(1:201,14+15));
ant3_200kW_exp_025T_err = table2array(Cases_025T(1:201,15+15));
ant4_200kW_exp_025T_err = table2array(Cases_025T(1:201,16+15));



ant2_0kW_exp_041T_err = table2array(Cases_041T(1:201,2+15));
ant3_0kW_exp_041T_err = table2array(Cases_041T(1:201,3+15));
ant4_0kW_exp_041T_err = table2array(Cases_041T(1:201,4+15));

ant2_125kW_exp_041T_err = table2array(Cases_041T(1:201,5+15));
ant3_125kW_exp_041T_err = table2array(Cases_041T(1:201,6+15));
ant4_125kW_exp_041T_err = table2array(Cases_041T(1:201,7+15));

ant2_150kW_exp_041T_err = table2array(Cases_041T(1:201,8+15));
ant3_150kW_exp_041T_err = table2array(Cases_041T(1:201,9+15));
ant4_150kW_exp_041T_err = table2array(Cases_041T(1:201,10+15));

ant2_175kW_exp_041T_err = table2array(Cases_041T(1:201,11+15));
ant3_175kW_exp_041T_err = table2array(Cases_041T(1:201,12+15));
ant4_175kW_exp_041T_err = table2array(Cases_041T(1:201,13+15));

ant2_200kW_exp_041T_err = table2array(Cases_041T(1:201,14+15));
ant3_200kW_exp_041T_err = table2array(Cases_041T(1:201,15+15));
ant4_200kW_exp_041T_err = table2array(Cases_041T(1:201,16+15));


%% Error in numerical simulations due to thermal noise


ant2_0kW_err_0T = table2array(Cases_Err0T(:,2));
ant3_0kW_err_0T = table2array(Cases_Err0T(:,3));
ant4_0kW_err_0T = table2array(Cases_Err0T(:,4));

ant2_125kW_err_0T = table2array(Cases_Err0T(:,5));
ant3_125kW_err_0T = table2array(Cases_Err0T(:,6));
ant4_125kW_err_0T = table2array(Cases_Err0T(:,7));

ant2_150kW_err_0T = table2array(Cases_Err0T(:,8));
ant3_150kW_err_0T = table2array(Cases_Err0T(:,9));
ant4_150kW_err_0T = table2array(Cases_Err0T(:,10));

ant2_175kW_err_0T = table2array(Cases_Err0T(:,11));
ant3_175kW_err_0T = table2array(Cases_Err0T(:,12));
ant4_175kW_err_0T = table2array(Cases_Err0T(:,13));

ant2_200kW_err_0T = table2array(Cases_Err0T(:,14));
ant3_200kW_err_0T = table2array(Cases_Err0T(:,15));
ant4_200kW_err_0T = table2array(Cases_Err0T(:,16));


ant2_0kW_err_025T = table2array(Cases_Err025T(:,2));
ant3_0kW_err_025T = table2array(Cases_Err025T(:,3));
ant4_0kW_err_025T = table2array(Cases_Err025T(:,4));

ant2_125kW_err_025T = table2array(Cases_Err025T(:,5));
ant3_125kW_err_025T = table2array(Cases_Err025T(:,6));
ant4_125kW_err_025T = table2array(Cases_Err025T(:,7));

ant2_150kW_err_025T = table2array(Cases_Err025T(:,8));
ant3_150kW_err_025T = table2array(Cases_Err025T(:,9));
ant4_150kW_err_025T = table2array(Cases_Err025T(:,10));

ant2_175kW_err_025T = table2array(Cases_Err025T(:,11));
ant3_175kW_err_025T = table2array(Cases_Err025T(:,12));
ant4_175kW_err_025T = table2array(Cases_Err025T(:,13));

ant2_200kW_err_025T = table2array(Cases_Err025T(:,14));
ant3_200kW_err_025T = table2array(Cases_Err025T(:,15));
ant4_200kW_err_025T = table2array(Cases_Err025T(:,16));



ant2_0kW_err_041T = table2array(Cases_Err041T(:,2));
ant3_0kW_err_041T = table2array(Cases_Err041T(:,3));
ant4_0kW_err_041T = table2array(Cases_Err041T(:,4));

ant2_125kW_err_041T = table2array(Cases_Err041T(:,5));
ant3_125kW_err_041T = table2array(Cases_Err041T(:,6));
ant4_125kW_err_041T = table2array(Cases_Err041T(:,7));

ant2_150kW_err_041T = table2array(Cases_Err041T(:,8));
ant3_150kW_err_041T = table2array(Cases_Err041T(:,9));
ant4_150kW_err_041T = table2array(Cases_Err041T(:,10));

ant2_175kW_err_041T = table2array(Cases_Err041T(:,11));
ant3_175kW_err_041T = table2array(Cases_Err041T(:,12));
ant4_175kW_err_041T = table2array(Cases_Err041T(:,13));

ant2_200kW_err_041T = table2array(Cases_Err041T(:,14));
ant3_200kW_err_041T = table2array(Cases_Err041T(:,15));
ant4_200kW_err_041T = table2array(Cases_Err041T(:,16));







figure;


% plot(x,ant2_0kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant2_0kW_exp_0T-ant2_0kW_exp_0T_err; flip(ant2_0kW_exp_0T+ant2_0kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x:,ant2_0kW_exp_025T:,'Linewidth',2)
patch([x; flip(x)], [ant2_0kW_exp_025T-ant2_0kW_exp_025T_err; flip(ant2_0kW_exp_025T+ant2_0kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x:,ant2_0kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant2_0kW_exp_041T-ant2_0kW_exp_041T_err; flip(ant2_0kW_exp_041T+ant2_0kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant2_0kW_num_0T,ant2_0kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant2_0kW_num_025T,ant2_0kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant2_0kW_num_041T,ant2_0kW_err_041T,"b+",'Linewidth',2)


% plot(x,ant2_0kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant2_0kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant2_0kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])




hold off
box off;grid off;
xlim([32 41]); ylim ([-60 0]);
xlabel('Frequency [GHz]');ylabel('S_{21,t} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('0 kW, 0 T - exp.', '0 kW, 0.25 T - exp.', '0 kW, 0.41 T - exp.', '0 kW, 0 T - num.', '0 kW, 0.25 T - num.', '0 kW, 0.41 T - num.', 'Location','northeast');

master3a = ['MEESST_Plot_Sparameter\attenuation21_0kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)



figure;


% plot(x,ant3_0kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant3_0kW_exp_0T-ant3_0kW_exp_0T_err; flip(ant3_0kW_exp_0T+ant3_0kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant3_0kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant3_0kW_exp_025T-ant3_0kW_exp_025T_err; flip(ant3_0kW_exp_025T+ant3_0kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant3_0kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant3_0kW_exp_041T-ant3_0kW_exp_041T_err; flip(ant3_0kW_exp_041T+ant3_0kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant3_0kW_num_0T,ant3_0kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant3_0kW_num_025T,ant3_0kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant3_0kW_num_041T,ant3_0kW_err_041T,"b+",'Linewidth',2)

% plot(x,ant3_0kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant3_0kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant3_0kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-60 0]);
xlabel('Frequency [GHz]');ylabel('S_{31,t} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('0 kW, 0 T - exp.', '0 kW, 0.25 T - exp.', '0 kW, 0.41 T - exp.', '0 kW, 0 T - num.', '0 kW, 0.25 T - num.', '0 kW, 0.41 T - num.', 'Location','northeast');

master3a = ['MEESST_Plot_Sparameter\attenuation31_0kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)



figure;


% plot(x,ant4_0kW_exp_0T,'Linewidth',2)
% hold on

patch([x; flip(x)], [ant4_0kW_exp_0T-ant4_0kW_exp_0T_err; flip(ant4_0kW_exp_0T+ant4_0kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant4_0kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant4_0kW_exp_025T-ant4_0kW_exp_025T_err; flip(ant4_0kW_exp_025T+ant4_0kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant4_0kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant4_0kW_exp_041T-ant4_0kW_exp_041T_err; flip(ant4_0kW_exp_041T+ant4_0kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant4_0kW_num_0T,ant4_0kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant4_0kW_num_025T,ant4_0kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant4_0kW_num_041T,ant4_0kW_err_041T,"b+",'Linewidth',2)


% plot(x,ant4_0kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant4_0kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant4_0kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-60 0]);
xlabel('Frequency [GHz]');ylabel('S_{41,t} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('0 kW, 0 T - exp.', '0 kW, 0.25 T - exp.', '0 kW, 0.41 T - exp.', '0 kW, 0 T - num.', '0 kW, 0.25 T - num.', '0 kW, 0.41 T - num.', 'Location','southeastoutside');













figure;


% plot(x,ant2_125kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant2_125kW_exp_0T-ant2_0kW_exp_0T-ant2_125kW_exp_0T_err; flip(ant2_125kW_exp_0T-ant2_0kW_exp_0T+ant2_125kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant2_125kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant2_125kW_exp_025T-ant2_0kW_exp_025T-ant2_125kW_exp_025T_err; flip(ant2_125kW_exp_025T-ant2_0kW_exp_025T+ant2_125kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant2_125kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant2_125kW_exp_041T-ant2_0kW_exp_041T-ant2_125kW_exp_041T_err; flip(ant2_125kW_exp_041T-ant2_0kW_exp_041T+ant2_125kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant2_125kW_num_0T-ant2_0kW_num_0T,ant2_125kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant2_125kW_num_025T-ant2_0kW_num_025T,ant2_125kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant2_125kW_num_041T-ant2_0kW_num_041T,ant2_125kW_err_041T,"b+",'Linewidth',2)


% plot(x,ant2_125kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant2_125kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant2_125kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{21} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('125 kW, 0 T - exp.', '125 kW, 0.25 T - exp.', '125 kW, 0.41 T - exp.', '125 kW, 0 T - num.', '125 kW, 0.25 T - num.', '125 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation21_125kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)



figure;


% plot(x,ant3_125kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant3_125kW_exp_0T-ant3_0kW_exp_0T-ant3_125kW_exp_0T_err; flip(ant3_125kW_exp_0T-ant3_0kW_exp_0T+ant3_125kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant3_125kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant3_125kW_exp_025T-ant3_0kW_exp_025T-ant3_125kW_exp_025T_err; flip(ant3_125kW_exp_025T-ant3_0kW_exp_025T+ant3_125kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant3_125kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant3_125kW_exp_041T-ant3_0kW_exp_041T-ant3_125kW_exp_041T_err; flip(ant3_125kW_exp_041T-ant3_0kW_exp_041T+ant3_125kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant3_125kW_num_0T-ant3_0kW_num_0T,ant3_125kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant3_125kW_num_025T-ant3_0kW_num_025T,ant3_125kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant3_125kW_num_041T-ant3_0kW_num_041T,ant3_125kW_err_041T,"b+",'Linewidth',2)

% plot(x,ant3_125kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant3_125kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant3_125kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{31} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('125 kW, 0 T - exp.', '125 kW, 0.25 T - exp.', '125 kW, 0.41 T - exp.', '125 kW, 0 T - num.', '125 kW, 0.25 T - num.', '125 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation31_125kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

figure;

% plot(x,ant4_125kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant4_125kW_exp_0T-ant4_0kW_exp_0T-ant4_125kW_exp_0T_err; flip(ant4_125kW_exp_0T-ant4_0kW_exp_0T+ant4_125kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant4_125kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant4_125kW_exp_025T-ant4_0kW_exp_025T-ant4_125kW_exp_025T_err; flip(ant4_125kW_exp_025T-ant4_0kW_exp_025T+ant4_125kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant4_125kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant4_125kW_exp_041T-ant4_0kW_exp_041T-ant4_125kW_exp_041T_err; flip(ant4_125kW_exp_041T-ant4_0kW_exp_041T+ant4_125kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant4_125kW_num_0T-ant4_0kW_num_0T,ant4_125kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant4_125kW_num_025T-ant4_0kW_num_025T,ant4_125kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant4_125kW_num_041T-ant4_0kW_num_041T,ant4_125kW_err_041T,"b+",'Linewidth',2)



% plot(x,ant4_125kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant4_125kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant4_125kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{41} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('125 kW, 0 T - exp.', '125 kW, 0.25 T - exp.', '125 kW, 0.41 T - exp.', '125 kW, 0 T - num.', '125 kW, 0.25 T - num.', '125 kW, 0.41 T - num.', 'Location','southeastoutside');

















figure;


% plot(x,ant2_150kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant2_150kW_exp_0T-ant2_0kW_exp_0T-ant2_150kW_exp_0T_err; flip(ant2_150kW_exp_0T-ant2_0kW_exp_0T+ant2_150kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant2_150kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant2_150kW_exp_025T-ant2_0kW_exp_025T-ant2_150kW_exp_025T_err; flip(ant2_150kW_exp_025T-ant2_0kW_exp_025T+ant2_150kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant2_150kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant2_150kW_exp_041T-ant2_0kW_exp_041T-ant2_150kW_exp_041T_err; flip(ant2_150kW_exp_041T-ant2_0kW_exp_041T+ant2_150kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant2_150kW_num_0T-ant2_0kW_num_0T,ant2_150kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant2_150kW_num_025T-ant2_0kW_num_025T,ant2_150kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant2_150kW_num_041T-ant2_0kW_num_041T,ant2_150kW_err_041T,"b+",'Linewidth',2)


% plot(x,ant2_150kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant2_150kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant2_150kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{21} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('150 kW, 0 T - exp.', '150 kW, 0.25 T - exp.', '150 kW, 0.41 T - exp.', '150 kW, 0 T - num.', '150 kW, 0.25 T - num.', '150 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation21_150kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

figure;


% plot(x,ant3_150kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant3_150kW_exp_0T-ant3_0kW_exp_0T-ant3_150kW_exp_0T_err; flip(ant3_150kW_exp_0T-ant3_0kW_exp_0T+ant3_150kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant3_150kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant3_150kW_exp_025T-ant3_0kW_exp_025T-ant3_150kW_exp_025T_err; flip(ant3_150kW_exp_025T-ant3_0kW_exp_025T+ant3_150kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant3_150kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant3_150kW_exp_041T-ant3_0kW_exp_041T-ant3_150kW_exp_041T_err; flip(ant3_150kW_exp_041T-ant3_0kW_exp_041T+ant3_150kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant3_150kW_num_0T-ant3_0kW_num_0T,ant3_150kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant3_150kW_num_025T-ant3_0kW_num_025T,ant3_150kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant3_150kW_num_041T-ant3_0kW_num_041T,ant3_150kW_err_041T,"b+",'Linewidth',2)

% plot(x,ant3_150kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant3_150kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant3_150kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{31} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('150 kW, 0 T - exp.', '150 kW, 0.25 T - exp.', '150 kW, 0.41 T - exp.', '150 kW, 0 T - num.', '150 kW, 0.25 T - num.', '150 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation31_150kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

figure;

% plot(x,ant4_150kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant4_150kW_exp_0T-ant4_0kW_exp_0T-ant4_150kW_exp_0T_err; flip(ant4_150kW_exp_0T-ant4_0kW_exp_0T+ant4_150kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant4_150kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant4_150kW_exp_025T-ant4_0kW_exp_025T-ant4_150kW_exp_025T_err; flip(ant4_150kW_exp_025T-ant4_0kW_exp_025T+ant4_150kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant4_150kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant4_150kW_exp_041T-ant4_0kW_exp_041T-ant4_150kW_exp_041T_err; flip(ant4_150kW_exp_041T-ant4_0kW_exp_041T+ant4_150kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant4_150kW_num_0T-ant4_0kW_num_0T,ant4_150kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant4_150kW_num_025T-ant4_0kW_num_025T,ant4_150kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant4_150kW_num_041T-ant4_0kW_num_041T,ant4_150kW_err_041T,"b+",'Linewidth',2)



% plot(x,ant4_150kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant4_150kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant4_150kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{41} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('150 kW, 0 T - exp.', '150 kW, 0.25 T - exp.', '150 kW, 0.41 T - exp.', '150 kW, 0 T - num.', '150 kW, 0.25 T - num.', '150 kW, 0.41 T - num.', 'Location','southeastoutside');
















figure;


% plot(x,ant2_175kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant2_175kW_exp_0T-ant2_0kW_exp_0T-ant2_175kW_exp_0T_err; flip(ant2_175kW_exp_0T-ant2_0kW_exp_0T+ant2_175kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant2_175kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant2_175kW_exp_025T-ant2_0kW_exp_025T-ant2_175kW_exp_025T_err; flip(ant2_175kW_exp_025T-ant2_0kW_exp_025T+ant2_175kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant2_175kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant2_175kW_exp_041T-ant2_0kW_exp_041T-ant2_175kW_exp_041T_err; flip(ant2_175kW_exp_041T-ant2_0kW_exp_041T+ant2_175kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant2_175kW_num_0T-ant2_0kW_num_0T,ant2_175kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant2_175kW_num_025T-ant2_0kW_num_025T,ant2_175kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant2_175kW_num_041T-ant2_0kW_num_041T,ant2_175kW_err_041T,"b+",'Linewidth',2)


% plot(x,ant2_175kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant2_175kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant2_175kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{21} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('175 kW, 0 T - exp.', '175 kW, 0.25 T - exp.', '175 kW, 0.41 T - exp.', '175 kW, 0 T - num.', '175 kW, 0.25 T - num.', '175 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation21_175kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

figure;


% plot(x,ant3_175kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant3_175kW_exp_0T-ant3_0kW_exp_0T-ant3_175kW_exp_0T_err; flip(ant3_175kW_exp_0T-ant3_0kW_exp_0T+ant3_175kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant3_175kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant3_175kW_exp_025T-ant3_0kW_exp_025T-ant3_175kW_exp_025T_err; flip(ant3_175kW_exp_025T-ant3_0kW_exp_025T+ant3_175kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant3_175kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant3_175kW_exp_041T-ant3_0kW_exp_041T-ant3_175kW_exp_041T_err; flip(ant3_175kW_exp_041T-ant3_0kW_exp_041T+ant3_175kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant3_175kW_num_0T-ant3_0kW_num_0T,ant3_175kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant3_175kW_num_025T-ant3_0kW_num_025T,ant3_175kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant3_175kW_num_041T-ant3_0kW_num_041T,ant3_175kW_err_041T,"b+",'Linewidth',2)

% plot(x,ant3_175kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant3_175kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant3_175kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{31} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('175 kW, 0 T - exp.', '175 kW, 0.25 T - exp.', '175 kW, 0.41 T - exp.', '175 kW, 0 T - num.', '175 kW, 0.25 T - num.', '175 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation31_175kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

figure;

% plot(x,ant4_175kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant4_175kW_exp_0T-ant4_0kW_exp_0T-ant4_175kW_exp_0T_err; flip(ant4_175kW_exp_0T-ant4_0kW_exp_0T+ant4_175kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant4_175kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant4_175kW_exp_025T-ant4_0kW_exp_025T-ant4_175kW_exp_025T_err; flip(ant4_175kW_exp_025T-ant4_0kW_exp_025T+ant4_175kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant4_175kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant4_175kW_exp_041T-ant4_0kW_exp_041T-ant4_175kW_exp_041T_err; flip(ant4_175kW_exp_041T-ant4_0kW_exp_041T+ant4_175kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant4_175kW_num_0T-ant4_0kW_num_0T,ant4_175kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant4_175kW_num_025T-ant4_0kW_num_025T,ant4_175kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant4_175kW_num_041T-ant4_0kW_num_041T,ant4_175kW_err_041T,"b+",'Linewidth',2)



% plot(x,ant4_175kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant4_175kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant4_175kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{41} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('175 kW, 0 T - exp.', '175 kW, 0.25 T - exp.', '175 kW, 0.41 T - exp.', '175 kW, 0 T - num.', '175 kW, 0.25 T - num.', '175 kW, 0.41 T - num.', 'Location','southeastoutside');


















figure;


% plot(x,ant2_200kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant2_200kW_exp_0T-ant2_0kW_exp_0T-ant2_200kW_exp_0T_err; flip(ant2_200kW_exp_0T-ant2_0kW_exp_0T+ant2_200kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant2_200kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant2_200kW_exp_025T-ant2_0kW_exp_025T-ant2_200kW_exp_025T_err; flip(ant2_200kW_exp_025T-ant2_0kW_exp_025T+ant2_200kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant2_200kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant2_200kW_exp_041T-ant2_0kW_exp_041T-ant2_200kW_exp_041T_err; flip(ant2_200kW_exp_041T-ant2_0kW_exp_041T+ant2_200kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant2_200kW_num_0T-ant2_0kW_num_0T,ant2_200kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant2_200kW_num_025T-ant2_0kW_num_025T,ant2_200kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant2_200kW_num_041T-ant2_0kW_num_041T,ant2_200kW_err_041T,"b+",'Linewidth',2)


% plot(x,ant2_200kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant2_200kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant2_200kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{21} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('200 kW, 0 T - exp.', '200 kW, 0.25 T - exp.', '200 kW, 0.41 T - exp.', '200 kW, 0 T - num.', '200 kW, 0.25 T - num.', '200 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation21_200kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)

figure;


% plot(x,ant3_200kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant3_200kW_exp_0T-ant3_0kW_exp_0T-ant3_200kW_exp_0T_err; flip(ant3_200kW_exp_0T-ant3_0kW_exp_0T+ant3_200kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant3_200kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant3_200kW_exp_025T-ant3_0kW_exp_025T-ant3_200kW_exp_025T_err; flip(ant3_200kW_exp_025T-ant3_0kW_exp_025T+ant3_200kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant3_200kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant3_200kW_exp_041T-ant3_0kW_exp_041T-ant3_200kW_exp_041T_err; flip(ant3_200kW_exp_041T-ant3_0kW_exp_041T+ant3_200kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant3_200kW_num_0T-ant3_0kW_num_0T,ant3_200kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant3_200kW_num_025T-ant3_0kW_num_025T,ant3_200kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant3_200kW_num_041T-ant3_0kW_num_041T,ant3_200kW_err_041T,"b+",'Linewidth',2)

% plot(x,ant3_200kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant3_200kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant3_200kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');ylabel('Attenuation_{31} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
%legend('200 kW, 0 T - exp.', '200 kW, 0.25 T - exp.', '200 kW, 0.41 T - exp.', '200 kW, 0 T - num.', '200 kW, 0.25 T - num.', '200 kW, 0.41 T - num.', 'Location','SouthEast');

master3a = ['MEESST_Plot_Sparameter\attenuation21_200kW.png'];
plotToSave = gca;

exportgraphics(plotToSave,master3a)


figure;

% plot(x,ant4_200kW_exp_0T,'Linewidth',2)
% hold on
patch([x; flip(x)], [ant4_200kW_exp_0T-ant4_0kW_exp_0T-ant4_200kW_exp_0T_err; flip(ant4_200kW_exp_0T-ant4_0kW_exp_0T+ant4_200kW_exp_0T_err)], 'r', 'FaceAlpha',0.25, 'EdgeColor','none')
hold on
%plot(x,ant4_200kW_exp_025T,'Linewidth',2)
patch([x; flip(x)], [ant4_200kW_exp_025T-ant4_0kW_exp_025T-ant4_200kW_exp_025T_err; flip(ant4_200kW_exp_025T-ant4_0kW_exp_025T+ant4_200kW_exp_025T_err)], 'g', 'FaceAlpha',0.25, 'EdgeColor','none')
%plot(x,ant4_200kW_exp_041T,'Linewidth',2)
patch([x; flip(x)], [ant4_200kW_exp_041T-ant4_0kW_exp_041T-ant4_200kW_exp_041T_err; flip(ant4_200kW_exp_041T-ant4_0kW_exp_041T+ant4_200kW_exp_041T_err)], 'b', 'FaceAlpha',0.25, 'EdgeColor','none')

errorbar(x2,ant4_200kW_num_0T-ant4_0kW_num_0T,ant4_200kW_err_0T,"r*",'Linewidth',2)

errorbar(x2,ant4_200kW_num_025T-ant4_0kW_num_025T,ant4_200kW_err_025T,"go",'Linewidth',2)
errorbar(x2,ant4_200kW_num_041T-ant4_0kW_num_041T,ant4_200kW_err_041T,"b+",'Linewidth',2)



% plot(x,ant4_200kW_exp_0T,'Linewidth',2,'Color',[1, 0, 0, 0.2])
% plot(x,ant4_200kW_exp_025T,'Linewidth',2,'Color',[0, 1, 0, 0.2])
% plot(x,ant4_200kW_exp_041T,'Linewidth',2,'Color',[0, 0, 1, 0.2])


hold off
box off;grid off;
xlim([32 41]); ylim ([-110 30]);
xlabel('Frequency [GHz]');
ylabel('Attenuation_{41} [dB]');
set(gca,'XMinorTick','on','YMinorTick','on', 'FontName','Times New Roman', 'Fontweight','bold','Linewidth',2,'FontSize',18,'TickLength',[0.02, 0.002])
legend('200 kW, 0 T - exp.', '200 kW, 0.25 T - exp.', '200 kW, 0.41 T - exp.', '200 kW, 0 T - num.', '200 kW, 0.25 T - num.', '200 kW, 0.41 T - num.', 'Location','southeastoutside');