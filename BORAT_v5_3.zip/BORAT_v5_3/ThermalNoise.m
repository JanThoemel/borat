%% Thermal noise due to plasma

clear all; clc;format long;close all; initime=cputime;
pause('off'); %there are pause points in the script, enable this option and they won't be active

%frequ = [34E9,37E9,40E9];



f=34E9;
%% Load antenna data

if f == 34E9
    antennaGain = 14.89740976; % [dBi]
elseif f == 37E9
    antennaGain = 15.393065; % [dBi]
elseif f == 40E9
    antennaGain = 13.56515449; % [dBi]
else
    antennaGain = 15; % [dBi]
end



% Load radiation pattern
if f == 34e9 || f == 33e9 || f == 35e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_34GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/AC_without_34GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 37e9 || f == 36e9 || f == 38e9
   % patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_37GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/AC_without_37GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
elseif f == 40e9 || f == 39e9
  %  patternRawData = readmatrix('C:/Work/OneDrive/OneDrive - University of Luxembourg/Work/21_MEESST_Data_Partners/VKI_Experiments/ExperimentalData/AntennaPatternMEasruements/AC_without_40GHzRaw.txt');
    patternRawData = readmatrix('inputPattern/AC_without_40GHzRaw.txt');
    patternCoPlanarHorizontal = [(patternRawData(:,2)),patternRawData(:,1)];%[abs(patternRawData(:,2)).^2*length(patternRawData)/(sum(abs(patternRawData(:,2)).^2)),patternRawData(:,1)];
    patternCoPlanarVertical = [(patternRawData(:,4)),patternRawData(:,1)];%[abs(patternRawData(:,4)).^2*length(patternRawData)/(sum(abs(patternRawData(:,4)).^2)),patternRawData(:,1)];
    for i = 1 : length(patternCoPlanarHorizontal)
        if patternCoPlanarHorizontal(i,2) <0
            patternCoPlanarHorizontal(i,2) = patternCoPlanarHorizontal(i,2)+360;
        end
    end
    for i = 1 : length(patternCoPlanarVertical)
        if patternCoPlanarVertical(i,2) <0
            patternCoPlanarVertical(i,2) = patternCoPlanarVertical(i,2)+360;
        end
    end
    Split = round(length(patternCoPlanarHorizontal)/2,-1)+1;
    patternCoPlanarHorizontalSort = [patternCoPlanarHorizontal(Split:end,:);patternCoPlanarHorizontal(1:Split,:)];
    patternCoPlanarHorizontalSort(end,:) = [];
    patternCoPlanarHorizontal = [ abs(patternCoPlanarHorizontalSort(:,1)).*10^(antennaGain/10),patternCoPlanarHorizontalSort(:,2)];
    
    Split = round(length(patternCoPlanarVertical)/2,-1)+1;
    patternCoPlanarVerticalSort = [patternCoPlanarVertical(Split:end,:);patternCoPlanarVertical(1:Split,:)];
    patternCoPlanarVerticalSort(end,:) = [];
    patternCoPlanarVertical = [ abs(patternCoPlanarVerticalSort(:,1)).*10^(antennaGain/10),patternCoPlanarVerticalSort(:,2)];
end

[~,ia,~] = unique(patternCoPlanarHorizontal(:,1),'rows');
patternCoPlanarHorizontal = patternCoPlanarHorizontal(ia,:);
[~,ia,~] = unique(patternCoPlanarHorizontal(:,2),'rows');
patternCoPlanarHorizontal = patternCoPlanarHorizontal(ia,:);
[~,ia,~] = unique(patternCoPlanarVertical(:,1),'rows');
patternCoPlanarVertical = patternCoPlanarVertical(ia,:);
[~,ia,~] = unique(patternCoPlanarVertical(:,2),'rows');
patternCoPlanarVertical = patternCoPlanarVertical(ia,:);
if min(patternCoPlanarHorizontal(:,2)) > 0
    patternCoPlanarHorizontal = [patternCoPlanarHorizontal(1,1),0;patternCoPlanarHorizontal];
end
if max(patternCoPlanarHorizontal(:,2)) < 360
    patternCoPlanarHorizontal = [patternCoPlanarHorizontal;patternCoPlanarHorizontal(end,1),360];
end

if min(patternCoPlanarVertical(:,2)) > 0
    patternCoPlanarVertical = [patternCoPlanarVertical(1,1),0;patternCoPlanarVertical];
end
if max(patternCoPlanarVertical(:,2)) < 360
    patternCoPlanarVertical = [patternCoPlanarVertical;patternCoPlanarVertical(end,1),360];
end

%Export Tx antenna radiation pattern values for later
RxAntenna.Pattern.Values90 = patternCoPlanarVertical;
RxAntenna.Pattern.Values = patternCoPlanarHorizontal;














wavelenght = physconst('LightSpeed')/f;

boltsmannConst = 1.38*10^(-23);
bandwidthAntenna = 5.5*10^9;
%temperaturePlasma = [300,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,14000];
%temperaturePlasma = [7597.7,4841.034,5347.75,5481.8,5370.6]; %125 kW
%temperaturePlasma = [8267.3,5812.044,5799.8,5719.36,5569.12]; %150 kW
%temperaturePlasma = [9055.49,6712.62,6239.98,5957.70,5770.99]; % 175 kW
temperaturePlasma = [9606.5,7754.064,6703.9,6194.48,5966.16]; % 200 kW

PLF = 0.5;


pNoise = boltsmannConst * temperaturePlasma * bandwidthAntenna * PLF;

x = 0.5:0.1:0.9435;
y = [0,0,0,0,0];

%% Antenna 2

antenna2_Xpos = 0.5105;
antenna2_Ypos = 0.15;
antenna2_dirmain = 340.47;

for k = 1: length(y)
    distanceToAntenna2(k) = sqrt(abs(antenna2_Xpos - x(k)).^2 + abs(antenna2_Ypos - y(k)).^2);
    angleToAntenna2(k) = atan2d(antenna2_Ypos - y(k),antenna2_Xpos - x(k));
    angleAntennaFromBoresight2(k) = antenna2_dirmain - (angleToAntenna2(k)+180);

    intensityAtPosRxDensRef2(k) = interp1(real(patternCoPlanarHorizontal(:,2)),(patternCoPlanarHorizontal(:,1)),angleAntennaFromBoresight2(k));
    directivity2(k) = intensityAtPosRxDensRef2(k)^2 * length(patternCoPlanarHorizontal(:,1))./sum(patternCoPlanarHorizontal(:,1).^2);

    lossNoise2(k) = wavelenght / (4 * pi()^2 * distanceToAntenna2(k)) * directivity2(k);
end


%% Antenna 3

antenna3_Xpos = 0.5135;
antenna3_Ypos = 0.155;
antenna3_dirmain = 360-20.256;

for k = 1: length(y)
    distanceToAntenna3(k) = sqrt(abs(antenna3_Xpos - x(k)).^2 + abs(antenna3_Ypos - y(k)).^2);
    angleToAntenna3(k) = atan2d(antenna3_Ypos - y(k),antenna3_Xpos - x(k));
    angleAntennaFromBoresight3(k) = antenna3_dirmain - (angleToAntenna3(k)+180);

    intensityAtPosRxDensRef3(k) = interp1(real(patternCoPlanarHorizontal(:,2)),(patternCoPlanarHorizontal(:,1)),angleAntennaFromBoresight3(k));
    directivity3(k) = intensityAtPosRxDensRef3(k)^2 * length(patternCoPlanarHorizontal(:,1))./sum(patternCoPlanarHorizontal(:,1).^2);

    lossNoise3(k) = wavelenght / (4 * pi()^2 * distanceToAntenna3(k)) * directivity3(k);
end



%% Antenna 4

antenna4_Xpos = 0.5135;
antenna4_Ypos = 0.295;
antenna4_dirmain = 360-35.08;

for k = 1: length(y)
    distanceToAntenna4(k) = sqrt(abs(antenna4_Xpos - x(k)).^2 + abs(antenna4_Ypos - y(k)).^2);
    angleToAntenna4(k) = atan2d(antenna4_Ypos - y(k),antenna4_Xpos - x(k));
    angleAntennaFromBoresight4(k) = antenna4_dirmain - (angleToAntenna4(k)+180);

    intensityAtPosRxDensRef4(k) = interp1(real(patternCoPlanarHorizontal(:,2)),(patternCoPlanarHorizontal(:,1)),angleAntennaFromBoresight4(k));
    directivity4(k) = intensityAtPosRxDensRef4(k)^2 * length(patternCoPlanarHorizontal(:,1))./sum(patternCoPlanarHorizontal(:,1).^2);

    lossNoise4(k) = wavelenght / (4 * pi()^2 * distanceToAntenna4(k)) * directivity4(k);
end

for ii = 1: length(pNoise)

    powerNoiseRx2(ii) = pNoise(ii) * lossNoise2(ii);
    powerNoiseRx3(ii) = pNoise(ii) * lossNoise3(ii);
    powerNoiseRx4(ii) = pNoise(ii) * lossNoise4(ii);

    powerNoiseRx21(ii) = pNoise(ii) * 75/5/360 *(1/distanceToAntenna2(ii))*directivity2(ii) ;
    powerNoiseRx31(ii) = pNoise(ii) * 75/5/360 *(1/distanceToAntenna3(ii))*directivity3(ii) ;
    powerNoiseRx41(ii) = pNoise(ii) * 75/5/360 *(1/distanceToAntenna4(ii))*directivity4(ii) ;

end

powerNoiseRx2dB = 10*log10(sum(powerNoiseRx2));
powerNoiseRx3dB = 10*log10(sum(powerNoiseRx3));
powerNoiseRx4dB = 10*log10(sum(powerNoiseRx4));

powerNoiseRx21dB = 10*log10(sum(powerNoiseRx21));
powerNoiseRx31dB = 10*log10(sum(powerNoiseRx31));
powerNoiseRx41dB = 10*log10(sum(powerNoiseRx41));




fprintf('\n Thank you for calculating the noise power. Exiting now.');
fprintf('-----------------------------------------------------------------------------------------\n');

%% --------------------------------------------------------------------------

save('MEESST_MHD_Noise_34Ghz_200kW.mat', '-v7.3');%,'Y_int_1','Y_int_2','Y_int_3','YY','-append'); 

